#ifndef COSTMAP_2D_COORDINATE_TRANSFORM_H_
#define COSTMAP_2D_COORDINATE_TRANSFORM_H_

#include <string>

namespace costmap_2d
{

/**
 * @struct TransformBuffer
 * @brief 坐标变换缓冲区（简化版）
 *
 * 用途：替代 tf2_ros::Buffer，用于存储和查询坐标变换关系。
 * 当前版本为空实现，未来在障碍物层需要实时传感器数据时再扩展。
 *
 * 设计思路：
 * 1. 当前：仅存储机器人当前位置（世界坐标）
 * 2. 未来扩展：添加坐标系变换、传感器数据时间同步等功能
 */
struct TransformBuffer
{
  /**
   * @brief 默认构造函数
   */
  TransformBuffer() : robot_pose_x_(0.0), robot_pose_y_(0.0), robot_pose_theta_(0.0) {}

  /**
   * @brief 更新机器人位置
   * @param x 世界坐标X（米）
   * @param y 世界坐标Y（米）
   * @param theta 航向角（弧度）
   */
  void updateRobotPose(double x, double y, double theta)
  {
    robot_pose_x_ = x;
    robot_pose_y_ = y;
    robot_pose_theta_ = theta;
  }

  double robot_pose_x_;   ///< 机器人当前位置X（世界坐标，米）
  double robot_pose_y_;   ///< 机器人当前位置Y（世界坐标，米）
  double robot_pose_theta_; ///< 机器人当前航向角（弧度）
};

}  // namespace costmap_2d

#endif  // COSTMAP_2D_COORDINATE_TRANSFORM_H_
