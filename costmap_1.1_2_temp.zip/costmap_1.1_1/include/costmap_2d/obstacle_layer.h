/**
 * @file obstacle_layer.h
 * @brief 障碍物层头文件 - 动态障碍物感知与更新的核心组件
 *
 * ObstacleLayer 是代价地图分层架构中的关键图层，负责：
 * 1. 订阅激光雷达（LaserScan）、点云（PointCloud/PointCloud2）等传感器话题
 * 2. 将传感器检测到的障碍物标记到代价地图中（标记为 LETHAL_OBSTACLE）
 * 3. 通过射线追踪（Raytracing）技术清除不再存在的障碍物
 * 4. 将障碍物层数据融合到全局代价地图
 *
 * 核心数据流：
 * 传感器消息 → 观测缓冲区 → 障碍物标记/自由空间清除 → 代价融合
 *
 * @author ROS Navigation Stack contributors
 */

#ifndef COSTMAP_2D_OBSTACLE_LAYER_H_
#define COSTMAP_2D_OBSTACLE_LAYER_H_

#include <ros/ros.h>
#include <costmap_2d/costmap_layer.h>
#include <costmap_2d/layered_costmap.h>
#include <costmap_2d/observation_buffer.h>
#include <nav_msgs/OccupancyGrid.h>
#include <sensor_msgs/LaserScan.h>
#include <laser_geometry/laser_geometry.h>
#include <sensor_msgs/PointCloud.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/point_cloud_conversion.h>
#include <tf2_ros/message_filter.h>
#include <message_filters/subscriber.h>
#include <dynamic_reconfigure/server.h>
#include <costmap_2d/ObstaclePluginConfig.h>
#include <costmap_2d/footprint.h>

namespace costmap_2d
{

/**
 * @class ObstacleLayer
 * @brief 障碍物层类 - 处理动态障碍物的检测与更新
 *
 * 继承自 CostmapLayer，实现了以下核心功能：
 * 1. 多传感器数据融合（支持 LaserScan、PointCloud、PointCloud2）
 * 2. 观测数据缓存与管理
 * 3. 基于射线追踪的自由空间清除
 * 4. 灵活的代价融合策略
 *
 * 配置参数说明：
 * - observation_sources: 传感器源列表（空格分隔）
 * - obstacle_range: 障碍物检测范围（米）
 * - raytrace_range: 射线追踪范围（米）
 * - min_obstacle_height: 最小障碍物高度（米）
 * - max_obstacle_height: 最大障碍物高度（米）
 * - marking: 是否用于标记障碍物
 * - clearing: 是否用于清除自由空间
 * - inf_is_valid: 无穷远值是否有效（仅对 LaserScan）
 */
class ObstacleLayer : public CostmapLayer
{
public:
  /**
   * @brief 默认构造函数
   * 
   * 初始化代价地图指针为 NULL，其他成员变量在 onInitialize() 中初始化。
   */
  ObstacleLayer()
  {
    costmap_ = NULL;  // 父类 Costmap2D 的 unsigned char* 成员
  }

  /**
   * @brief 析构函数
   * 
   * 清理动态重配置服务和其他资源。
   */
  virtual ~ObstacleLayer();

  /**
   * @brief 初始化函数
   * 
   * 从 ROS 参数服务器读取配置，创建观测缓冲区和传感器订阅器，
   * 支持 LaserScan、PointCloud、PointCloud2 三种数据类型。
   */
  virtual void onInitialize();

  /**
   * @brief 更新边界函数
   * 
   * 收集需要更新的区域边界，执行射线追踪清除自由空间，并标记新检测到的障碍物。
   * 
   * @param robot_x 机器人 X 坐标（世界坐标）
   * @param robot_y 机器人 Y 坐标（世界坐标）
   * @param robot_yaw 机器人大航向角（弧度）
   * @param min_x 更新区域最小 X 坐标（输出参数）
   * @param min_y 更新区域最小 Y 坐标（输出参数）
   * @param max_x 更新区域最大 X 坐标（输出参数）
   * @param max_y 更新区域最大 Y 坐标（输出参数）
   */
  virtual void updateBounds(double robot_x, double robot_y, double robot_yaw, double* min_x, double* min_y,
                            double* max_x, double* max_y);

  /**
   * @brief 更新代价函数
   * 
   * 将障碍物层的代价数据融合到主代价地图中，支持两种融合策略：
   * - Overwrite（覆盖）：直接替换主地图值
   * - Maximum（取最大）：取障碍物层与主地图的最大值
   * 
   * @param master_grid 主代价地图
   * @param min_i 更新区域最小栅格 X 索引
   * @param min_j 更新区域最小栅格 Y 索引
   * @param max_i 更新区域最大栅格 X 索引
   * @param max_j 更新区域最大栅格 Y 索引
   */
   
  virtual void updateCosts(costmap_2d::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);

  /**
   * @brief 激活障碍物层
   * 
   * 重新订阅传感器话题并重置观测缓冲区的时间戳。
   */
  virtual void activate();

  /**
   * @brief 停用障碍物层
   * 
   * 取消订阅所有传感器话题，停止接收传感器数据。
   */
  virtual void deactivate();

  /**
   * @brief 重置障碍物层
   * 
   * 调用 deactivate() 停用层，重置地图，然后调用 activate() 重新激活。
   */
  virtual void reset();

  /**
   * @brief 激光雷达消息回调函数
   * 
   * 将激光扫描数据转换为点云，并存储到观测缓冲区中。
   * 使用 laser_geometry::LaserProjection 进行坐标变换。
   * 
   * @param message 激光扫描消息（LaserScan）
   * @param buffer 观测缓冲区指针
   */
  void laserScanCallback(const sensor_msgs::LaserScanConstPtr& message,
                         const boost::shared_ptr<costmap_2d::ObservationBuffer>& buffer);

  /**
   * @brief 支持无穷远值的激光雷达消息回调函数
   * 
   * 与 laserScanCallback 类似，但会先将激光扫描中的正无穷远值（+Inf）
   * 替换为最大量程值（range_max - epsilon），然后再转换为点云。
   * 
   * @param message 激光扫描消息（LaserScan）
   * @param buffer 观测缓冲区指针
   */
  void laserScanValidInfCallback(const sensor_msgs::LaserScanConstPtr& message,
                                 const boost::shared_ptr<costmap_2d::ObservationBuffer>& buffer);

  /**
   * @brief PointCloud 消息回调函数
   * 
   * 将 PointCloud 消息转换为 PointCloud2 格式后，存储到观测缓冲区中。
   * 
   * @param message PointCloud 消息
   * @param buffer 观测缓冲区指针
   */
  void pointCloudCallback(const sensor_msgs::PointCloudConstPtr& message,
                          const boost::shared_ptr<costmap_2d::ObservationBuffer>& buffer);

  /**
   * @brief PointCloud2 消息回调函数
   * 
   * 直接将 PointCloud2 消息存储到观测缓冲区中。
   * 
   * @param message PointCloud2 消息
   * @param buffer 观测缓冲区指针
   */
  void pointCloud2Callback(const sensor_msgs::PointCloud2ConstPtr& message,
                           const boost::shared_ptr<costmap_2d::ObservationBuffer>& buffer);

  /**
   * @brief 添加静态观测数据（仅用于测试）
   * 
   * 允许手动添加观测数据，用于测试障碍物层的功能。
   * 
   * @param obs 观测数据
   * @param marking 是否用于标记障碍物
   * @param clearing 是否用于清除自由空间
   */
  void addStaticObservation(costmap_2d::Observation& obs, bool marking, bool clearing);

  /**
   * @brief 清除静态观测数据（仅用于测试）
   * 
   * 清除之前添加的静态观测数据。
   * 
   * @param marking 是否清除标记观测数据
   * @param clearing 是否清除清除观测数据
   */
  void clearStaticObservations(bool marking, bool clearing);

protected:
  /**
   * @brief 设置动态重配置服务
   * 
   * 创建动态重配置服务器，注册回调函数处理参数变化。
   * 
   * @param nh ROS 节点句柄
   */
  virtual void setupDynamicReconfigure(ros::NodeHandle& nh);

  /**
   * @brief 获取用于标记障碍物的观测数据
   * 
   * 从所有标记缓冲区中收集观测数据，包括动态传感器数据和静态观测数据。
   * 
   * @param marking_observations 输出参数：观测数据列表
   * @return true 如果所有观测缓冲区都是最新的，false 否则
   */
  bool getMarkingObservations(std::vector<costmap_2d::Observation>& marking_observations) const;

  /**
   * @brief 获取用于清除自由空间的观测数据
   * 
   * 从所有清除缓冲区中收集观测数据，包括动态传感器数据和静态观测数据。
   * 
   * @param clearing_observations 输出参数：观测数据列表
   * @return true 如果所有观测缓冲区都是最新的，false 否则
   */
  bool getClearingObservations(std::vector<costmap_2d::Observation>& clearing_observations) const;

  /**
   * @brief 射线追踪清除自由空间
   * 
   * 使用 Bresenham 算法从传感器原点到每个检测点画射线，
   * 将射线上的栅格标记为自由空间（FREE_SPACE）。
   * 
   * @param clearing_observation 清除观测数据（包含传感器原点和点云）
   * @param min_x 更新区域最小 X 坐标（输出参数）
   * @param min_y 更新区域最小 Y 坐标（输出参数）
   * @param max_x 更新区域最大 X 坐标（输出参数）
   * @param max_y 更新区域最大 Y 坐标（输出参数）
   */
  virtual void raytraceFreespace(const costmap_2d::Observation& clearing_observation, double* min_x, double* min_y,
                                 double* max_x, double* max_y);

  /**
   * @brief 更新射线追踪边界
   * 
   * 根据传感器原点和检测点坐标，扩展更新边界以包含射线追踪范围。
   * 
   * @param ox 传感器原点 X 坐标
   * @param oy 传感器原点 Y 坐标
   * @param wx 检测点 X 坐标
   * @param wy 检测点 Y 坐标
   * @param range 射线追踪范围
   * @param min_x 更新区域最小 X 坐标（输出参数）
   * @param min_y 更新区域最小 Y 坐标（输出参数）
   * @param max_x 更新区域最大 X 坐标（输出参数）
   * @param max_y 更新区域最大 Y 坐标（输出参数）
   */
  void updateRaytraceBounds(double ox, double oy, double wx, double wy, double range, double* min_x, double* min_y,
                            double* max_x, double* max_y);

  /**
   * @brief 更新机器人足迹边界
   * 
   * 将机器人足迹转换到全局坐标系，并更新更新边界。
   * 如果启用了足迹清除，机器人位置会被标记为自由空间。
   * 
   * @param robot_x 机器人 X 坐标（世界坐标）
   * @param robot_y 机器人 Y 坐标（世界坐标）
   * @param robot_yaw 机器人大航向角（弧度）
   * @param min_x 更新区域最小 X 坐标（输出参数）
   * @param min_y 更新区域最小 Y 坐标（输出参数）
   * @param max_x 更新区域最大 X 坐标（输出参数）
   * @param max_y 更新区域最大 Y 坐标（输出参数）
   */
  void updateFootprint(double robot_x, double robot_y, double robot_yaw, double* min_x, double* min_y, 
                       double* max_x, double* max_y);

  // ===== 成员变量 =====

  std::vector<geometry_msgs::Point> transformed_footprint_;  ///< 转换到全局坐标系的机器人足迹
  bool footprint_clearing_enabled_;                           ///< 是否启用机器人足迹清除

  std::string global_frame_;     ///< 全局坐标系名称
  double max_obstacle_height_;   ///< 最大障碍物高度（超过此高度的障碍物被忽略）

  laser_geometry::LaserProjection projector_;  ///< 激光扫描到点云的投影器

  /// @brief 传感器话题订阅器列表
  std::vector<boost::shared_ptr<message_filters::SubscriberBase> > observation_subscribers_;

  /// @brief TF 消息过滤器列表（确保坐标变换可用）
  std::vector<boost::shared_ptr<tf2_ros::MessageFilterBase> > observation_notifiers_;

  /// @brief 所有观测缓冲区（存储所有传感器数据）
  std::vector<boost::shared_ptr<costmap_2d::ObservationBuffer> > observation_buffers_;

  /// @brief 用于标记障碍物的观测缓冲区
  std::vector<boost::shared_ptr<costmap_2d::ObservationBuffer> > marking_buffers_;

  /// @brief 用于清除自由空间的观测缓冲区
  std::vector<boost::shared_ptr<costmap_2d::ObservationBuffer> > clearing_buffers_;

  // 仅用于测试的静态观测数据
  std::vector<costmap_2d::Observation> static_clearing_observations_;  ///< 静态清除观测数据
  std::vector<costmap_2d::Observation> static_marking_observations_;   ///< 静态标记观测数据

  bool rolling_window_;  ///< 是否启用滚动窗口模式（局部代价地图常用）

  dynamic_reconfigure::Server<costmap_2d::ObstaclePluginConfig> *dsrv_;  ///< 动态重配置服务器

  int combination_method_;  ///< 代价融合方法：0=覆盖，1=取最大值

private:
  /**
   * @brief 动态重配置回调函数
   * 
   * 处理动态重配置参数变化，更新障碍物层的运行时参数。
   * 
   * @param config 配置参数
   * @param level 重配置级别
   */
  void reconfigureCB(costmap_2d::ObstaclePluginConfig &config, uint32_t level);
};

}  // namespace costmap_2d

#endif  // COSTMAP_2D_OBSTACLE_LAYER_H_