/**
 * @file grid_map.h
 * @brief 独立的栅格地图数据结构
 * 
 * 提供不依赖ROS的静态栅格地图表示，用于机器人导航和路径规划。
 * 支持坐标转换、栅格访问、地图查询等核心功能。
 */

#ifndef GRID_MAP_H
#define GRID_MAP_H

#include <vector>
#include <stdexcept>
#include <cmath>

namespace grid_map {

/**
 * @brief 2D坐标点结构
 */
struct Point2D {
    double x;
    double y;
    
    Point2D() : x(0.0), y(0.0) {}
    Point2D(double x_, double y_) : x(x_), y(y_) {}
    
    Point2D operator+(const Point2D& other) const {
        return Point2D(x + other.x, y + other.y);
    }
    
    Point2D operator-(const Point2D& other) const {
        return Point2D(x - other.x, y - other.y);
    }
    
    Point2D operator*(double scalar) const {
        return Point2D(x * scalar, y * scalar);
    }
};

/**
 * @brief 2D整数坐标（栅格索引）
 */
struct GridIndex {
    int x;
    int y;
    
    GridIndex() : x(0), y(0) {}
    GridIndex(int x_, int y_) : x(x_), y(y_) {}
    
    bool operator==(const GridIndex& other) const {
        return x == other.x && y == other.y;
    }
    
    bool operator!=(const GridIndex& other) const {
        return !(*this == other);
    }
};

/**
 * @brief 地图原点信息（位置和朝向）
 */
struct MapOrigin {
    Point2D position;    // 原点在世界坐标系中的位置
    double yaw;          // 原点的偏航角（弧度）
    
    MapOrigin() : position(0.0, 0.0), yaw(0.0) {}
    MapOrigin(double x, double y, double yaw_) 
        : position(x, y), yaw(yaw_) {}
};

/**
 * @brief 栅格地图数据结构
 * 
 * 存储静态环境的占用栅格地图，每个栅格表示一个区域的占用状态：
 * - 0: 自由空间
 * - 1-99: 占用概率（数值越大，占用概率越高）
 * - 100: 障碍物
 * - -1: 未知区域
 * - 255: 特殊标记（如地图边界）
 */
class GridMap {
public:
    // 栅格值常量
    static const int8_t FREE_SPACE = 0;
    static const int8_t OCCUPIED = 100;
    static const int8_t UNKNOWN = -1;
    static const int8_t MARKER = 255;
    
    /**
     * @brief 构造函数
     */
    GridMap();
    
    /**
     * @brief 构造函数
     * @param width 地图宽度（栅格数）
     * @param height 地图高度（栅格数）
     * @param resolution 分辨率（米/栅格）
     * @param origin 地图原点
     */
    GridMap(int width, int height, double resolution, const MapOrigin& origin);
    
    /**
     * @brief 析构函数
     */
    ~GridMap();
    
    /**
     * @brief 初始化地图
     * @param width 地图宽度（栅格数）
     * @param height 地图高度（栅格数）
     * @param resolution 分辨率（米/栅格）
     * @param origin 地图原点
     */
    void initialize(int width, int height, double resolution, const MapOrigin& origin);
    
    /**
     * @brief 重置地图（所有栅格设为未知）
     */
    void reset();
    
    /**
     * @brief 调整地图大小
     * @param new_width 新宽度
     * @param new_height 新高度
     * @param keep_data 是否保留原有数据
     */
    void resize(int new_width, int new_height, bool keep_data = true);
    
    // ===== 地图信息访问 =====
    
    /**
     * @brief 获取地图宽度
     */
    int getWidth() const { return width_; }
    
    /**
     * @brief 获取地图高度
     */
    int getHeight() const { return height_; }
    
    /**
     * @brief 获取地图分辨率
     */
    double getResolution() const { return resolution_; }
    
    /**
     * @brief 获取地图原点
     */
    const MapOrigin& getOrigin() const { return origin_; }
    
    /**
     * @brief 设置地图原点
     */
    void setOrigin(const MapOrigin& origin) { origin_ = origin; }
    
    /**
     * @brief 获取栅格总数
     */
    size_t getSize() const { return data_.size(); }
    
    /**
     * @brief 检查地图是否已初始化
     */
    bool isInitialized() const { return width_ > 0 && height_ > 0; }
    
    // ===== 栅格访问 =====
    
    /**
     * @brief 获取栅格值
     * @param index 栅格索引
     * @return 栅格值
     */
    int8_t getCell(const GridIndex& index) const;
    
    /**
     * @brief 设置栅格值
     * @param index 栅格索引
     * @param value 栅格值
     */
    void setCell(const GridIndex& index, int8_t value);
    
    /**
     * @brief 获取栅格值（带边界检查）
     * @param index 栅格索引
     * @param default_value 超出边界时的默认值
     * @return 栅格值
     */
    int8_t getCellSafe(const GridIndex& index, int8_t default_value = UNKNOWN) const;
    
    /**
     * @brief 直接访问栅格数据
     */
    std::vector<int8_t>& getData() { return data_; }
    
    /**
     * @brief 直接访问栅格数据（只读）
     */
    const std::vector<int8_t>& getData() const { return data_; }
    
    // ===== 坐标转换 =====
    
    /**
     * @brief 世界坐标转栅格索引
     * @param world_point 世界坐标点
     * @return 栅格索引
     */
    GridIndex worldToGrid(const Point2D& world_point) const;
    
    /**
     * @brief 栅格索引转世界坐标
     * @param grid_index 栅格索引
     * @return 世界坐标点（栅格中心）
     */
    Point2D gridToWorld(const GridIndex& grid_index) const;
    
    /**
     * @brief 检查栅格索引是否在地图范围内
     */
    bool isInside(const GridIndex& index) const;
    
    /**
     * @brief 检查世界坐标是否在地图范围内
     */
    bool isInside(const Point2D& world_point) const;
    
    // ===== 地图查询 =====
    
    /**
     * @brief 检查栅格是否为自由空间
     */
    bool isFree(const GridIndex& index) const;
    
    /**
     * @brief 检查栅格是否为障碍物
     */
    bool isOccupied(const GridIndex& index) const;
    
    /**
     * @brief 检查栅格是否为未知区域
     */
    bool isUnknown(const GridIndex& index) const;
    
    /**
     * @brief 获取指定半径内的自由栅格
     * @param center 中心栅格
     * @param radius 半径（栅格数）
     * @return 自由栅格列表
     */
    std::vector<GridIndex> getFreeNeighbors(const GridIndex& center, int radius = 1) const;
    
    /**
     * @brief 计算两点之间的曼哈顿距离
     */
    static int manhattanDistance(const GridIndex& a, const GridIndex& b);
    
    /**
     * @brief 计算两点之间的欧几里得距离（考虑分辨率，返回实际米数）
     */
    double euclideanDistance(const GridIndex& a, const GridIndex& b) const;
    
    /**
     * @brief 计算两点之间的欧几里得距离（世界坐标）
     */
    static double euclideanDistance(const Point2D& a, const Point2D& b);
    
    // ===== 地图统计 =====
    
    /**
     * @brief 统计自由栅格数量
     */
    int countFreeCells() const;
    
    /**
     * @brief 统计障碍物栅格数量
     */
    int countOccupiedCells() const;
    
    /**
     * @brief 统计未知栅格数量
     */
    int countUnknownCells() const;
    
    /**
     * @brief 计算地图覆盖率（自由栅格占比）
     */
    double getCoverage() const;
    
    /**
     * @brief 计算地图占用率（障碍物栅格占比）
     */
    double getOccupancyRate() const;
    
    // ===== 地图操作 =====
    
    /**
     * @brief 清除指定区域
     * @param center 中心栅格
     * @param radius 半径（栅格数）
     */
    void clearArea(const GridIndex& center, int radius);
    
    /**
     * @brief 标记障碍物
     * @param center 中心栅格
     * @param radius 半径（栅格数）
     */
    void markObstacle(const GridIndex& center, int radius);
    
private:
    /**
     * @brief 计算线性索引
     * @param index 栅格索引
     * @return 线性索引
     */
    size_t toLinearIndex(const GridIndex& index) const;
    
    /**
     * @brief 线性索引转栅格索引
     * @param linear_index 线性索引
     * @return 栅格索引
     */
    GridIndex fromLinearIndex(size_t linear_index) const;
    
private:
    int width_;                    // 地图宽度（栅格数）
    int height_;                   // 地图高度（栅格数）
    double resolution_;            // 分辨率（米/栅格）
    MapOrigin origin_;             // 地图原点
    std::vector<int8_t> data_;     // 栅格数据（一维数组存储）
};

} // namespace grid_map

#endif // GRID_MAP_H