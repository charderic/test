/*********************************************************************
 *
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2008, 2013, Willow Garage, Inc.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of Willow Garage, Inc. nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 * Author: Eitan Marder-Eppstein
 *         David V. Lu!!
 *********************************************************************/
#ifndef COSTMAP_2D_STATIC_LAYER_H_
#define COSTMAP_2D_STATIC_LAYER_H_

#include <ros/ros.h>
#include <costmap_2d/costmap_layer.h>
#include <costmap_2d/layered_costmap.h>
#include <nav_msgs/OccupancyGrid.h>
#include <map_msgs/OccupancyGridUpdate.h>
#include <message_filters/subscriber.h>

namespace costmap_2d
{

class StaticLayer : public CostmapLayer
{
public:
  StaticLayer();
  virtual ~StaticLayer();
  virtual void onInitialize();
  virtual void activate();
  virtual void deactivate();
  virtual void reset();

  virtual void updateBounds(double robot_x, double robot_y, double robot_yaw, double* min_x, double* min_y,
                            double* max_x, double* max_y);
  virtual void updateCosts(costmap_2d::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);

  virtual void matchSize();

private:
  /**
   * @brief  Callback to update the costmap's map from the map_server
   * @param new_map The map to put into the costmap. The origin of the new
   * map along with its size will determine what parts of the costmap's
   * static map are overwritten.
   */
  void incomingMap(const nav_msgs::OccupancyGridConstPtr& new_map);
  void incomingUpdate(const map_msgs::OccupancyGridUpdateConstPtr& update);

  /**
   * @brief 将地图像素值转换为代价地图值
   *
   * 根据配置参数，将 OccupancyGrid 的像素值（0-100, -1）转换为代价地图值。
   *
   * @param value 地图像素原始值
   * @return 代价地图代价值（0-255）
   */
  unsigned char interpretValue(unsigned char value);

  // ==================== 坐标系参数 ====================

  /**
   * @brief 全局坐标系名称
   *
   * 代价地图使用的全局坐标系，通常为 "map"。
   * 从 LayeredCostmap 获取，用于滚动窗口模式下的坐标变换。
   */
  std::string global_frame_;

  /**
   * @brief 地图坐标系名称
   *
   * 地图数据所在的坐标系，从地图消息的 header.frame_id 获取。
   * 在滚动窗口模式下，需要通过 TF 将地图坐标系转换到全局坐标系。
   */
  std::string map_frame_;

  // ==================== 订阅控制参数 ====================

  /**
   * @brief 是否订阅地图增量更新
   *
   * 参数名: subscribe_to_updates
   * 默认值: false
   *
   * true: 订阅 map_updates 话题，只更新变化区域，提高效率。
   * false: 只订阅完整地图，不接收增量更新。
   */
  bool subscribe_to_updates_;

  /**
   * @brief 是否已收到第一张地图
   *
   * 标志位，用于阻塞等待地图数据到达。
   * 在 onInitialize() 中等待此标志变为 true。
   */
  bool map_received_;

  /**
   * @brief 是否有新数据需要更新
   *
   * 标志位，在收到新地图或地图更新时设为 true。
   * updateBounds() 检查此标志决定是否更新边界。
   */
  bool has_updated_data_;

  // ==================== 更新区域参数 ====================

  /**
   * @brief 更新区域的左上角列索引
   *
   * 定义需要更新到主代价地图的矩形区域。
   * 在 incomingMap() 中设为整个地图范围。
   * 在 incomingUpdate() 中设为增量更新区域。
   */
  unsigned int x_;

  /**
   * @brief 更新区域的左上角行索引
   */
  unsigned int y_;

  /**
   * @brief 更新区域的宽度（像素）
   */
  unsigned int width_;

  /**
   * @brief 更新区域的高度（像素）
   */
  unsigned int height_;

  // ==================== 地图转换参数 ====================

  /**
   * @brief 是否跟踪未知空间
   *
   * 参数名: track_unknown_space
   * 默认值: true
   *
   * true: 未知区域(-1)转换为 NO_INFORMATION(255)
   * false: 未知区域(-1)转换为 FREE_SPACE(0)
   *
   * 影响 interpretValue() 的转换逻辑。
   */
  bool track_unknown_space_;

  /**
   * @brief 融合时是否取最大值
   *
   * 参数名: use_maximum
   * 默认值: false
   *
   * true: 融合到主代价地图时，取静态层和主代价地图的最大值。
   * false: 静态层直接覆盖主代价地图。
   *
   * 在 updateCosts() 中影响融合策略。
   */
  bool use_maximum_;

  /**
   * @brief 是否只使用第一张地图
   *
   * 参数名: first_map_only
   * 默认值: false
   *
   * true: 收到第一张地图后关闭 map_sub_ 订阅器，节省资源。
   *       在 reset() 时不会重新订阅。
   * false: 持续监听地图话题，支持动态更新。
   */
  bool first_map_only_;

  /**
   * @brief 是否使用三值化模式
   *
   * 参数名: trinary_costmap
   * 默认值: true
   *
   * true: 只有三种值：FREE_SPACE(0), LETHAL_OBSTACLE(254), NO_INFORMATION(255)
   * false: SCALE模式，支持 1~99 的中间代价值（线性插值）
   *
   * 影响 interpretValue() 的转换逻辑。
   */
  bool trinary_costmap_;

  // ==================== ROS 订阅器 ====================

  /**
   * @brief 地图话题订阅器
   *
   * 订阅 /map 话题（latched 模式），接收完整地图数据。
   * 回调函数: incomingMap()
   */
  ros::Subscriber map_sub_;

  /**
   * @brief 地图增量更新订阅器
   *
   * 订阅 /map_updates 话题，接收地图的增量更新。
   * 仅在 subscribe_to_updates_ 为 true 时启用。
   * 回调函数: incomingUpdate()
   */
  ros::Subscriber map_update_sub_;

  // ==================== 阈值参数 ====================

  /**
   * @brief 障碍物阈值
   *
   * 参数名: lethal_cost_threshold
   * 默认值: 100
   * 范围: [0, 100]
   *
   * 地图原始值 >= 此阈值时，转换为 LETHAL_OBSTACLE(254)。
   * 用于 interpretValue() 的障碍物判定。
   */
  unsigned char lethal_threshold_;

  /**
   * @brief 未知区域原始值
   *
   * 参数名: unknown_cost_value
   * 默认值: -1
   *
   * 地图中表示未知区域的原始值。
   * 通常为 -1（ROS OccupancyGrid 的标准未知值）。
   * 用于 interpretValue() 的未知区域判定。
   */
  unsigned char unknown_cost_value_;
};

}  // namespace costmap_2d

#endif  // COSTMAP_2D_STATIC_LAYER_H_
