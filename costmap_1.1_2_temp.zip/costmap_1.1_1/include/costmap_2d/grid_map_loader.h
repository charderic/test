/**
 * @file grid_map_loader.h
 * @brief 从图像文件加载GridMap的加载器
 * 
 * 替代原来的ROS map_server功能，提供独立的地图加载能力。
 * 支持PGM、PNG等图像格式，转换为GridMap数据结构。
 */

#ifndef GRID_MAP_LOADER_H
#define GRID_MAP_LOADER_H

#include "grid_map.h"
#include <string>
#include <stdexcept>

// 使用SDL_image库加载图像
#include <SDL/SDL_image.h>

namespace grid_map {

/**
 * @brief 地图模式枚举
 * 
 * TRINARY - 三值模式（0=自由，100=障碍，-1=未知）
 * SCALE   - 线性缩放模式（1-99之间的值）
 * RAW     - 原始像素值模式
 */
enum MapMode { TRINARY, SCALE, RAW };

/**
 * @brief 地图配置结构
 */
struct MapConfig {
    std::string image_file;      // 图像文件路径
    double resolution;           // 分辨率（米/像素）
    MapOrigin origin;            // 地图原点
    bool negate;                 // 是否反转颜色
    double occupied_thresh;      // 障碍物阈值（0.0~1.0）
    double free_thresh;          // 自由空间阈值（0.0~1.0）
    MapMode mode;                // 地图模式
    
    MapConfig()
        : resolution(0.05),
          origin(0.0, 0.0, 0.0),
          negate(false),
          occupied_thresh(0.65),
          free_thresh(0.196),
          mode(TRINARY) {}
};

/**
 * @brief 从YAML文件加载地图配置
 * 
 * @param yaml_file YAML文件路径
 * @param config 输出配置结构
 * @throws std::runtime_error 文件读取失败时抛出异常
 */
void loadMapConfig(const std::string& yaml_file, MapConfig& config);

/**
 * @brief 从图像文件加载地图
 * 
 * @param image_file 图像文件路径
 * @param config 地图配置
 * @param map 输出的GridMap对象
 * @throws std::runtime_error 图像加载失败时抛出异常
 */
void loadMapFromImage(const std::string& image_file, const MapConfig& config, GridMap& map);

/**
 * @brief 从YAML配置文件加载完整地图
 * 
 * @param yaml_file YAML配置文件路径
 * @param map 输出的GridMap对象
 * @throws std::runtime_error 加载失败时抛出异常
 */
void loadMap(const std::string& yaml_file, GridMap& map);

/**
 * @brief 保存地图为PGM图像文件
 * 
 * @param map GridMap对象
 * @param pgm_file 输出的PGM文件路径
 * @throws std::runtime_error 保存失败时抛出异常
 */
void saveMapToPGM(const GridMap& map, const std::string& pgm_file);

/**
 * @brief 保存地图配置为YAML文件
 * 
 * @param map GridMap对象
 * @param yaml_file 输出的YAML文件路径
 * @throws std::runtime_error 保存失败时抛出异常
 */
void saveMapConfig(const GridMap& map, const std::string& yaml_file);

/**
 * @brief 保存完整地图（PGM + YAML）
 * 
 * @param map GridMap对象
 * @param base_path 基础路径（不含扩展名）
 * @throws std::runtime_error 保存失败时抛出异常
 */
void saveMap(const GridMap& map, const std::string& base_path);

} // namespace grid_map

#endif // GRID_MAP_LOADER_H