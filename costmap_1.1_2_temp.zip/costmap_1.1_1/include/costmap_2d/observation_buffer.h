#ifndef COSTMAP_2D_OBSERVATION_BUFFER_H_
#define COSTMAP_2D_OBSERVATION_BUFFER_H_

// ROS 标准头文件
#include <vector>
#include <list>
#include <string>
#include <ros/time.h>

// 代价地图相关头文件
#include <costmap_2d/observation.h>

// TF2 坐标变换库
#include <tf2_ros/buffer.h>

// 传感器消息类型
#include <sensor_msgs/PointCloud2.h>

// 线程支持
#include <boost/thread.hpp>

namespace costmap_2d
{

/**
 * @class ObservationBuffer
 * @brief 观测缓冲区类，负责接收传感器点云数据、进行坐标变换并存储
 * 
 * 该类是代价地图障碍层（ObstacleLayer）的核心组件，主要功能包括：
 * 1. 接收来自激光雷达、深度相机等传感器的 PointCloud2 数据
 * 2. 将点云从传感器坐标系变换到全局坐标系
 * 3. 根据高度阈值过滤无效点
 * 4. 维护观测数据的时间窗口，自动清理过期数据
 * 5. 提供线程安全的数据访问接口
 */
class ObservationBuffer
{
public:
  /**
   * @brief 构造函数，初始化观测缓冲区
   * 
   * @param topic_name        观测数据的话题名称，用于错误和警告消息标识
   * @param observation_keep_time 观测数据的持久化时间（秒），0表示只保留最新数据
   * @param expected_update_rate 期望的更新频率（秒），0表示无限制
   * @param min_obstacle_height 障碍物点的最小高度阈值（米）
   * @param max_obstacle_height 障碍物点的最大高度阈值（米）
   * @param obstacle_range    用于插入障碍物的传感器信任范围（米）
   * @param raytrace_range    用于射线追踪清除空间的传感器信任范围（米）
   * @param tf2_buffer        TF2 缓冲区引用，用于坐标变换
   * @param global_frame      点云需要变换到的目标全局坐标系
   * @param sensor_frame      传感器所在的坐标系，为空时从消息头读取
   * @param tf_tolerance      设置新全局坐标系时等待变换的容忍时间（秒）
   */
  ObservationBuffer(std::string topic_name, double observation_keep_time, double expected_update_rate,
                    double min_obstacle_height, double max_obstacle_height, double obstacle_range,
                    double raytrace_range, tf2_ros::Buffer& tf2_buffer, std::string global_frame,
                    std::string sensor_frame, double tf_tolerance);

  /**
   * @brief 析构函数，清理资源
   */
  ~ObservationBuffer();

  /**
   * @brief 设置新的全局坐标系，并将所有缓存的观测数据变换到新坐标系
   * 
   * @param new_global_frame 新的全局坐标系名称
   * @return 变换成功返回true，失败返回false
   */
  bool setGlobalFrame(const std::string new_global_frame);

  /**
   * @brief 将点云变换到全局坐标系并缓存
   * 
   * 注意：调用者需要确保变换可用（建议使用 MessageNotifier）
   * 
   * @param cloud 需要缓存的点云数据
   */
  void bufferCloud(const sensor_msgs::PointCloud2& cloud);

  /**
   * @brief 将所有当前观测数据的副本填充到传入的向量中
   * 
   * @param observations 用于接收观测数据的向量引用
   */
  void getObservations(std::vector<Observation>& observations);

  /**
   * @brief 检查观测缓冲区是否按预期频率更新
   * 
   * @return 如果按预期频率更新返回true，否则返回false并发出警告
   */
  bool isCurrent() const;

  /**
   * @brief 加锁，保护观测缓冲区数据
   * 
   * 在多线程环境中，访问 observation_list_ 前应调用此方法
   */
  inline void lock()
  {
    lock_.lock();
  }

  /**
   * @brief 解锁，释放观测缓冲区数据保护
   * 
   * 在完成对 observation_list_ 的访问后应调用此方法
   */
  inline void unlock()
  {
    lock_.unlock();
  }

  /**
   * @brief 重置最后更新时间戳
   * 
   * 用于在需要时强制标记缓冲区为最新状态
   */
  void resetLastUpdated();

private:
  /**
   * @brief 从缓冲区列表中移除过期的观测数据
   * 
   * 根据 observation_keep_time_ 设置的时间窗口，清理超出时间范围的观测
   */
  void purgeStaleObservations();

  // ========== 成员变量 ==========
  
  tf2_ros::Buffer& tf2_buffer_;          ///< TF2 坐标变换缓冲区引用
  const ros::Duration observation_keep_time_;   ///< 观测数据的保留时间
  const ros::Duration expected_update_rate_;    ///< 期望的更新频率
  ros::Time last_updated_;               ///< 最后一次更新的时间戳
  std::string global_frame_;             ///< 目标全局坐标系名称
  std::string sensor_frame_;             ///< 传感器坐标系名称（可为空）
  std::list<Observation> observation_list_;     ///< 观测数据列表（按时间顺序存储）
  std::string topic_name_;               ///< 话题名称，用于日志输出
  double min_obstacle_height_;           ///< 障碍物点的最小高度阈值
  double max_obstacle_height_;           ///< 障碍物点的最大高度阈值
  boost::recursive_mutex lock_;          ///< 递归互斥锁，确保线程安全
  double obstacle_range_;                ///< 障碍物检测范围
  double raytrace_range_;                ///< 射线追踪范围
  double tf_tolerance_;                  ///< TF变换等待容忍时间
};

}  // namespace costmap_2d

#endif  // COSTMAP_2D_OBSERVATION_BUFFER_H_
