/**
 * @file inflation_layer.h
 * @brief 膨胀层头文件 - 对障碍物进行膨胀处理，创建安全缓冲区
 *
 * InflationLayer 是代价地图分层架构中的关键图层，负责：
 * 1. 将障碍物周围一定范围内的区域标记为高代价
 * 2. 代价随距离呈指数衰减
 * 3. 为路径规划提供安全距离保障
 *
 * @author Eitan Marder-Eppstein, David V. Lu!!
 */

#ifndef COSTMAP_2D_INFLATION_LAYER_H_
#define COSTMAP_2D_INFLATION_LAYER_H_

#include <costmap_2d/layer.h>
#include <costmap_2d/layered_costmap.h>
#include <boost/thread.hpp>

namespace costmap_2d
{

/**
 * @class CellData
 * @brief 膨胀单元数据结构 - 存储膨胀过程中待处理栅格的信息
 *用途 ：在膨胀过程中存储待处理的栅格信息，记录每个栅格及其对应的最近障碍物位置。
 * 在膨胀算法中，每个待处理的栅格需要记录：
 * - 栅格索引和坐标
 * - 最近障碍物的坐标（用于距离计算）
 */
class CellData
{
public:
  /**
   * @brief 构造函数
   * @param i  栅格在代价地图中的线性索引
   * @param x  栅格的X坐标
   * @param y  栅格的Y坐标
   * @param sx 最近障碍物的X坐标（源坐标）
   * @param sy 最近障碍物的Y坐标（源坐标）
   */
  CellData(double i, unsigned int x, unsigned int y, unsigned int sx, unsigned int sy) :
      index_(i), x_(x), y_(y), src_x_(sx), src_y_(sy)
  {
  }

  unsigned int index_;      ///< 栅格线性索引
  unsigned int x_, y_;      ///< 当前栅格坐标
  unsigned int src_x_, src_y_;  ///< 源障碍物坐标（最近障碍物位置）
};

/**
 * @class InflationLayer
 * @brief 膨胀层 - 对障碍物进行膨胀处理的图层
 *
 * 核心功能：
 * 1. 接收来自其他图层的致命障碍物（254）
 * 2. 在障碍物周围膨胀半径范围内计算衰减的代价值
 * 3. 将膨胀后的代价写入主代价地图
 *
 * 膨胀代价模型：
 * - 距离=0：LETHAL_OBSTACLE（254）- 致命障碍
 * - 距离≤内切圆半径：INSCRIBED_INFLATED_OBSTACLE（253）- 内切圆内
 * - 距离>内切圆半径：指数衰减，从252降到1
 */
class InflationLayer : public Layer
{
public:
  /**
   * @brief 默认构造函数
   * 
   * 使用默认预设参数值：
   * - inflation_radius: 0.55 米
   * - cost_scaling_factor: 10.0
   * - inflate_unknown: false
   */
  InflationLayer();

  /**
   * @brief 带参数的构造函数
   * 
   * @param inflation_radius 膨胀半径（米），默认 0.55
   * @param cost_scaling_factor 代价衰减权重，默认 10.0
   * @param inflate_unknown 是否膨胀未知区域，默认 false
   */
  InflationLayer(double inflation_radius, double cost_scaling_factor = 10.0, bool inflate_unknown = false);

  /**
   * @brief 析构函数
   *
   * 清理资源：
   * - 删除距离/代价缓存表
   * - 删除已访问标记数组
   */
  virtual ~InflationLayer()
  {
    deleteKernels();
    if (seen_)
        delete[] seen_;
  }

  /**
   * @brief 初始化函数
   *
   * 执行以下操作：
   * 1. 设置图层为当前状态
   * 2. 调用matchSize()同步尺寸
   * 
   * 参数已在构造函数中预设，不再从ROS参数服务器读取。
   */
  virtual void onInitialize();

  /**
   * @brief 更新边界函数
   *
   * 根据膨胀半径扩展更新边界，确保膨胀区域完整覆盖。
   *
   * @param robot_x 机器人X坐标（世界坐标）
   * @param robot_y 机器人Y坐标（世界坐标）
   * @param robot_yaw 机器人航向角（弧度）
   * @param min_x 更新区域最小X坐标（输出参数）
   * @param min_y 更新区域最小Y坐标（输出参数）
   * @param max_x 更新区域最大X坐标（输出参数）
   * @param max_y 更新区域最大Y坐标（输出参数）
   */
  virtual void updateBounds(double robot_x, double robot_y, double robot_yaw, double* min_x, double* min_y,
                            double* max_x, double* max_y);

  /**
   * @brief 更新代价函数 - 核心膨胀算法
   *
   * 对指定区域内的障碍物进行膨胀处理：
   * 1. 收集所有致命障碍物作为膨胀起点
   * 2. 按距离递增顺序处理栅格
   * 3. 从缓存获取代价值并写入主代价地图
   *
   * @param master_grid 主代价地图
   * @param min_i 更新区域最小栅格X索引
   * @param min_j 更新区域最小栅格Y索引
   * @param max_i 更新区域最大栅格X索引
   * @param max_j 更新区域最大栅格Y索引
   */
  virtual void updateCosts(costmap_2d::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);

  /**
   * @brief 判断图层是否离散化
   * @return true（膨胀层处理离散的栅格数据）
   */
  virtual bool isDiscretized()
  {
    return true;
  }

  /**
   * @brief 同步尺寸函数
   *
   * 当主代价地图尺寸改变时调用：
   * 1. 更新分辨率和膨胀半径（栅格数）
   * 2. 重新计算距离/代价缓存
   * 3. 调整已访问标记数组大小
   */
  virtual void matchSize();

  /**
   * @brief 重置函数
   *
   * 重新初始化图层，清除所有膨胀数据。
   */
  virtual void reset() { onInitialize(); }

  /**
   * @brief 根据距离计算代价值
   *
   * 代价计算公式：
   * - 距离=0 → LETHAL_OBSTACLE（254）
   * - 距离×分辨率 ≤ 内切圆半径 → INSCRIBED_INFLATED_OBSTACLE（253）
   * - 距离>内切圆半径 → 指数衰减: cost = 252 × exp(-weight × (distance - inscribed_radius))
   *
   * @param distance 与障碍物的距离（栅格数）
   * @return 计算得到的代价值（0-255）
   */
  virtual inline unsigned char computeCost(double distance) const
  {
    unsigned char cost = 0;
    if (distance == 0)
      cost = LETHAL_OBSTACLE;//254
    else if (distance * resolution_ <= inscribed_radius_)
      cost = INSCRIBED_INFLATED_OBSTACLE;//253
    else
    {
      // 按欧氏距离进行指数衰减
      double euclidean_distance = distance * resolution_;
      double factor = exp(-1.0 * weight_ * (euclidean_distance - inscribed_radius_));
      cost = (unsigned char)((INSCRIBED_INFLATED_OBSTACLE - 1) * factor);
    }
    return cost;
  }

  /**
   * @brief 设置膨胀参数
   *
   * 当参数改变时触发重新计算缓存和完全重新膨胀。
   *
   * @param inflation_radius 膨胀半径（米）
   * @param cost_scaling_factor 代价衰减权重（影响指数衰减速度）
   */
  void setInflationParameters(double inflation_radius, double cost_scaling_factor);

  /**
   * @brief 获取膨胀半径
   * @return 膨胀半径（米）
   */
  double getInflationRadius() const { return inflation_radius_; }

  /**
   * @brief 获取代价衰减权重
   * @return 代价衰减权重
   */
  double getCostScalingFactor() const { return weight_; }

protected:
  /**
   * @brief 足迹改变回调函数
   *
   * 当机器人足迹改变时调用：
   * 1. 更新内切圆半径
   * 2. 重新计算缓存
   * 3. 标记需要完全重新膨胀
   */
  virtual void onFootprintChanged();

  boost::recursive_mutex* inflation_access_;  ///< 线程互斥锁，保护膨胀数据

  // ===== 膨胀参数 =====
  double resolution_;              ///< 地图分辨率（米/栅格）
  double inflation_radius_;        ///< 膨胀半径（米）
  double inscribed_radius_;        ///< 机器人足迹内切圆半径（米）
  double weight_;                  ///< 代价衰减权重（影响指数衰减速度）
  bool inflate_unknown_;           ///< 是否膨胀未知区域

private:
  /**
   * @brief 查询预计算的距离值
   *
   * 从缓存表中获取两个栅格之间的欧氏距离。
   *
   * @param mx 当前栅格X坐标
   * @param my 当前栅格Y坐标
   * @param src_x 源栅格X坐标（障碍物位置）
   * @param src_y 源栅格Y坐标（障碍物位置）
   * @return 两个栅格之间的欧氏距离（栅格数）
   */
  inline double distanceLookup(int mx, int my, int src_x, int src_y)
  {
    unsigned int dx = abs(mx - src_x);
    unsigned int dy = abs(my - src_y);
    return cached_distances_[dx][dy];
  }

  /**
   * @brief 查询预计算的代价值
   *
   * 从缓存表中获取指定距离对应的代价值。
   *
   * @param mx 当前栅格X坐标
   * @param my 当前栅格Y坐标
   * @param src_x 源栅格X坐标（障碍物位置）
   * @param src_y 源栅格Y坐标（障碍物位置）
   * @return 对应的代价值（0-255）
   */
  inline unsigned char costLookup(int mx, int my, int src_x, int src_y)
  {
    unsigned int dx = abs(mx - src_x);
    unsigned int dy = abs(my - src_y);
    return cached_costs_[dx][dy];
  }

  /**
   * @brief 计算距离和代价缓存表
   *
   * 预计算膨胀半径范围内所有栅格组合的距离和对应代价值，
   * 避免在膨胀过程中重复计算，提升性能。
   */
  void computeCaches();

  /**
   * @brief 删除缓存表（释放内存）
   */
  void deleteKernels();

  /**
   * @brief 将栅格加入膨胀队列
   *
   * 根据栅格到障碍物的距离，将其加入对应距离的处理队列。
   *
   * @param index 栅格线性索引
   * @param mx 栅格X坐标
   * @param my 栅格Y坐标
   * @param src_x 源障碍物X坐标
   * @param src_y 源障碍物Y坐标
   */
  inline void enqueue(unsigned int index, unsigned int mx, unsigned int my,
                      unsigned int src_x, unsigned int src_y);

  // ===== 缓存与状态 =====
  unsigned int cell_inflation_radius_;        ///< 膨胀半径（栅格数）
  unsigned int cached_cell_inflation_radius_; ///< 缓存的膨胀半径（栅格数）
  std::map<double, std::vector<CellData> > inflation_cells_;  ///< 按距离分组的膨胀队列

  bool* seen_;         ///< 已访问标记数组，防止重复处理
  int seen_size_;      ///< 已访问数组大小

  unsigned char** cached_costs_;     ///< 预计算代价缓存表 [dx][dy]
  double** cached_distances_;        ///< 预计算距离缓存表 [dx][dy]
  double last_min_x_, last_min_y_, last_max_x_, last_max_y_;  ///< 上次更新边界

  bool need_reinflation_;  ///< 是否需要完全重新膨胀（参数改变时设置）
};

}  // namespace costmap_2d

#endif  // COSTMAP_2D_INFLATION_LAYER_H_