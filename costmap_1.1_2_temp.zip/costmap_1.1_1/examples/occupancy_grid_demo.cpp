/**
 * @file occupancy_grid_demo.cpp
 * @brief nav_msgs::OccupancyGrid 订阅Demo
 *
 * 功能：
 * 1. 订阅 /map 话题（nav_msgs::OccupancyGrid）
 * 2. 解析地图数据
 * 3. 输出地图信息和统计
 *
 * 使用方法：
 *   ./occupancy_grid_demo [map_topic]
 *
 * 示例：
 *   ./occupancy_grid_demo /map
 */

#include <ros/ros.h>
#include <nav_msgs/OccupancyGrid.h>
#include <iostream>
#include <iomanip>

class OccupancyGridDemo
{
public:
  OccupancyGridDemo(const std::string& map_topic = "/map")
    : map_topic_(map_topic)
  {
    // 初始化ROS节点
    ros::NodeHandle nh;

    // 订阅地图话题
    map_sub_ = nh.subscribe(map_topic_, 1, &OccupancyGridDemo::mapCallback, this);

    ROS_INFO("Occupancy Grid Demo initialized");
    ROS_INFO("Waiting for map on %s...", map_topic_.c_str());
  }

  /**
   * @brief 地图回调函数
   */
  void mapCallback(const nav_msgs::OccupancyGridConstPtr& msg)
  {
    ROS_INFO("Received map: %s", msg->header.frame_id.c_str());

    // 输出地图基本信息
    printMapInfo(msg);

    // 统计栅格值
    printGridStatistics(msg);

    // 输出部分栅格值（地图中心区域）
    printSampleGrid(msg);
  }

  /**
   * @brief 输出地图基本信息
   */
  void printMapInfo(const nav_msgs::OccupancyGridConstPtr& msg)
  {
    std::cout << "\n========================================" << std::endl;
    std::cout << "         地图基本信息" << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << "坐标系: " << msg->header.frame_id << std::endl;
    std::cout << "尺寸: " << msg->info.width << " x " << msg->info.height << " 栅格" << std::endl;
    std::cout << "分辨率: " << msg->info.resolution << " 米/栅格" << std::endl;
    std::cout << "原点: [" << msg->info.origin.position.x << ", "
              << msg->info.origin.position.y << ", "
              << msg->info.origin.position.z << "]" << std::endl;
    std::cout << "朝向: [" << msg->info.origin.orientation.x << ", "
              << msg->info.origin.orientation.y << ", "
              << msg->info.origin.orientation.z << ", "
              << msg->info.origin.orientation.w << "]" << std::endl;

    // 计算实际尺寸
    double width_m = msg->info.width * msg->info.resolution;
    double height_m = msg->info.height * msg->info.resolution;
    std::cout << "实际尺寸: " << width_m << " x " << height_m << " 米" << std::endl;
    std::cout << "========================================\n" << std::endl;
  }

  /**
   * @brief 统计栅格值
   */
  void printGridStatistics(const nav_msgs::OccupancyGridConstPtr& msg)
  {
    int free_count = 0;      // 自由空间 (0)
    int occupied_count = 0;  // 障碍物 (100)
    int unknown_count = 0;   // 未知区域 (-1)
    int other_count = 0;     // 其他值 (1-99)

    for (size_t i = 0; i < msg->data.size(); ++i)
    {
      int8_t value = msg->data[i];
      if (value == 0)
        free_count++;
      else if (value == 100)
        occupied_count++;
      else if (value == -1)
        unknown_count++;
      else
        other_count++;
    }

    int total = msg->data.size();

    std::cout << "栅格统计:" << std::endl;
    std::cout << "  总栅格数: " << total << std::endl;
    std::cout << "  自由空间 (0): " << free_count << " ("
              << std::fixed << std::setprecision(2)
              << (100.0 * free_count / total) << "%)" << std::endl;
    std::cout << "  障碍物 (100): " << occupied_count << " ("
              << std::fixed << std::setprecision(2)
              << (100.0 * occupied_count / total) << "%)" << std::endl;
    std::cout << "  未知区域 (-1): " << unknown_count << " ("
              << std::fixed << std::setprecision(2)
              << (100.0 * unknown_count / total) << "%)" << std::endl;
    std::cout << "  其他 (1-99): " << other_count << " ("
              << std::fixed << std::setprecision(2)
              << (100.0 * other_count / total) << "%)" << std::endl;
    std::cout << "\n栅格值含义:" << std::endl;
    std::cout << "  -1: 未知区域（灰色）" << std::endl;
    std::cout << "   0: 自由空间（白色）" << std::endl;
    std::cout << "   1-99: 中间代价（浅灰到深灰）" << std::endl;
    std::cout << "  100: 障碍物（黑色）" << std::endl;
    std::cout << "========================================\n" << std::endl;
  }

  /**
   * @brief 输出部分栅格值（地图中心区域）
   */
  void printSampleGrid(const nav_msgs::OccupancyGridConstPtr& msg)
  {
    int display_size = 10;
    int start_x = std::max(0, (int)msg->info.width / 2 - display_size / 2);
    int start_y = std::max(0, (int)msg->info.height / 2 - display_size / 2);

    std::cout << "栅格值示例 (中心 " << display_size << "x" << display_size << " 区域):" << std::endl;
    std::cout << "坐标范围: [" << start_x << ", " << start_y << "] 到 ["
              << start_x + display_size - 1 << ", " << start_y + display_size - 1 << "]" << std::endl;
    std::cout << std::endl;

    // 输出栅格值（从上到下，从左到右）
    for (int j = start_y + display_size - 1; j >= start_y; --j)
    {
      for (int i = start_x; i < start_x + display_size; ++i)
      {
        int index = j * msg->info.width + i;
        int8_t value = msg->data[index];

        if (value == -1)
          std::cout << "  ? ";  // 未知
        else if (value == 0)
          std::cout << "  . ";  // 自由
        else if (value == 100)
          std::cout << "  X ";  // 障碍
        else
          std::cout << std::setw(3) << (int)value << " ";  // 其他
      }
      std::cout << std::endl;
    }

    std::cout << "\n图例:" << std::endl;
    std::cout << "  ? = 未知 (-1)" << std::endl;
    std::cout << "  . = 自由 (0)" << std::endl;
    std::cout << "  X = 障碍 (100)" << std::endl;
    std::cout << "  数字 = 其他代价 (1-99)" << std::endl;
    std::cout << "========================================\n" << std::endl;
  }

  /**
   * @brief 运行主循环
   */
  void run()
  {
    ros::spin();
  }

private:
  std::string map_topic_;
  ros::Subscriber map_sub_;
};

int main(int argc, char** argv)
{
  // 初始化ROS
  ros::init(argc, argv, "occupancy_grid_demo");

  // 获取地图话题参数
  std::string map_topic = "/map";
  if (argc > 1)
  {
    map_topic = argv[1];
  }

  // 创建并运行Demo
  OccupancyGridDemo demo(map_topic);
  demo.run();

  return 0;
}