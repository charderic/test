/**
 * @file static_layer_demo.cpp
 * @brief 静态层测试Demo - 接收/map话题，通过LayeredCostmap生成代价地图
 *
 * 功能：
 * 1. 订阅 /map 话题（nav_msgs::OccupancyGrid）
 * 2. 创建 LayeredCostmap 并添加 StaticLayer
 * 3. 生成并输出代价地图信息
 *
 * 使用方法：
 *   ./static_layer_demo [map_topic]
 */

#include <ros/ros.h>
#include <costmap_2d/layered_costmap.h>
#include <costmap_2d/static_layer.h>
#include <costmap_2d/cost_values.h>
#include <nav_msgs/OccupancyGrid.h>
#include <iostream>
#include <iomanip>

int main(int argc, char** argv)
{
  // 初始化ROS节点
  ros::init(argc, argv, "static_layer_demo");
  ros::NodeHandle nh;
  ros::NodeHandle private_nh("~");

  // 获取地图话题参数
  std::string map_topic = "/map";
  if (argc > 1)
  {
    map_topic = argv[1];
  }

  ROS_INFO("等待接收地图: %s", map_topic.c_str());

  // 阻塞等待接收地图消息
  nav_msgs::OccupancyGridConstPtr map_msg = ros::topic::waitForMessage<nav_msgs::OccupancyGrid>(map_topic, nh, ros::Duration(30.0));
  
  if (!map_msg)
  {
    ROS_ERROR("超时未收到地图消息！");
    return -1;
  }

  ROS_INFO("收到地图: %s, 尺寸: %dx%d, 分辨率: %.3f m/pixel",
           map_msg->header.frame_id.c_str(),
           map_msg->info.width, map_msg->info.height,
           map_msg->info.resolution);

  // ===== 1. 创建分层代价地图 =====
  costmap_2d::LayeredCostmap* layered_costmap = new costmap_2d::LayeredCostmap("map", false, true);

  // ===== 2. 创建静态层 =====
  boost::shared_ptr<costmap_2d::StaticLayer> static_layer(new costmap_2d::StaticLayer());

  // ===== 3. 将静态层添加到分层代价地图 =====
  layered_costmap->addPlugin(static_layer);

  // ===== 4. 配置静态层参数 =====
  private_nh.setParam("map_topic", map_topic);
  private_nh.setParam("first_map_only", true);
  private_nh.setParam("subscribe_to_updates", false);
  private_nh.setParam("track_unknown_space", true);
  private_nh.setParam("use_maximum", false);
  private_nh.setParam("lethal_cost_threshold", 100);
  private_nh.setParam("trinary_costmap", true);

  // ===== 5. 初始化静态层（先调用 Layer::initialize，再调用 onInitialize）=====
  ROS_INFO("初始化静态层...");
  static_layer->initialize(layered_costmap, "static_layer", NULL);  // 使用 initialize() 而不是直接调用 onInitialize()
  ROS_INFO("静态层初始化完成");

  // 等待地图处理完成（给一点时间让回调执行）
  ros::Duration(0.5).sleep();
  ros::spinOnce();
  ROS_INFO("等待完成");

  // ===== 6. 更新代价地图 =====
  ROS_INFO("获取代价地图...");
  costmap_2d::Costmap2D* costmap = layered_costmap->getCostmap();
  
  if (!costmap)
  {
    ROS_ERROR("获取代价地图失败！");
    delete layered_costmap;
    return -1;
  }
  ROS_INFO("代价地图获取成功，尺寸: %dx%d", costmap->getSizeInCellsX(), costmap->getSizeInCellsY());

  // 计算机器人位置（使用地图中心）
  double robot_x = costmap->getOriginX() + costmap->getSizeInMetersX() / 2.0;
  double robot_y = costmap->getOriginY() + costmap->getSizeInMetersY() / 2.0;
  double robot_yaw = 0.0;

  // 更新分层代价地图
  layered_costmap->updateMap(robot_x, robot_y, robot_yaw);

  ROS_INFO("代价地图更新完成");

  // ===== 7. 输出代价地图信息 =====
  std::cout << "\n========================================" << std::endl;
  std::cout << "        代价地图基本信息" << std::endl;
  std::cout << "========================================" << std::endl;
  std::cout << "尺寸(栅格):  " << costmap->getSizeInCellsX() << " x "
            << costmap->getSizeInCellsY() << std::endl;
  std::cout << "分辨率:      " << costmap->getResolution() << " 米/栅格" << std::endl;
  std::cout << "原点:        [" << costmap->getOriginX() << ", "
            << costmap->getOriginY() << "]" << std::endl;
  std::cout << "尺寸(米):    " << costmap->getSizeInMetersX() << " x "
            << costmap->getSizeInMetersY() << " 米" << std::endl;
  std::cout << "========================================\n" << std::endl;

  // ===== 8. 输出代价地图统计 =====
  int free_count = 0;
  int lethal_count = 0;
  int no_information_count = 0;
  int other_count = 0;

  for (unsigned int i = 0; i < costmap->getSizeInCellsX(); ++i)
  {
    for (unsigned int j = 0; j < costmap->getSizeInCellsY(); ++j)
    {
      unsigned char cost = costmap->getCost(i, j);
      if (cost == costmap_2d::FREE_SPACE)
        free_count++;
      else if (cost == costmap_2d::LETHAL_OBSTACLE)
        lethal_count++;
      else if (cost == costmap_2d::NO_INFORMATION)
        no_information_count++;
      else
        other_count++;
    }
  }

  unsigned int total_cells = costmap->getSizeInCellsX() * costmap->getSizeInCellsY();

  std::cout << "========================================" << std::endl;
  std::cout << "        代价地图统计信息" << std::endl;
  std::cout << "========================================" << std::endl;
  std::cout << "总栅格数:     " << total_cells << std::endl;
  std::cout << "自由空间:     " << std::setw(10) << free_count << " ("
            << std::fixed << std::setprecision(2) << (100.0 * free_count / total_cells) << "%)" << std::endl;
  std::cout << "致命障碍:     " << std::setw(10) << lethal_count << " ("
            << std::fixed << std::setprecision(2) << (100.0 * lethal_count / total_cells) << "%)" << std::endl;
  std::cout << "其他代价:     " << std::setw(10) << other_count << " ("
            << std::fixed << std::setprecision(2) << (100.0 * other_count / total_cells) << "%)" << std::endl;
  std::cout << "未知区域:     " << std::setw(10) << no_information_count << " ("
            << std::fixed << std::setprecision(2) << (100.0 * no_information_count / total_cells) << "%)" << std::endl;
  std::cout << "========================================\n" << std::endl;

  // ===== 9. 可视化显示中心区域 =====
  const int display_size = 15;
  int start_x = std::max(0, (int)costmap->getSizeInCellsX() / 2 - display_size / 2);
  int start_y = std::max(0, (int)costmap->getSizeInCellsY() / 2 - display_size / 2);

  std::cout << "代价地图可视化 (中心 " << display_size << "x" << display_size << " 区域):" << std::endl;
  std::cout << "坐标范围: [" << start_x << ", " << start_y << "] 到 ["
            << start_x + display_size - 1 << ", " << start_y + display_size - 1 << "]" << std::endl;
  std::cout << std::endl;

  for (int j = start_y + display_size - 1; j >= start_y; --j)
  {
    for (int i = start_x; i < start_x + display_size; ++i)
    {
      unsigned char cost = costmap->getCost(i, j);
      if (cost == costmap_2d::FREE_SPACE)
        std::cout << "  .";
      else if (cost == costmap_2d::LETHAL_OBSTACLE)
        std::cout << "  X";
      else if (cost == costmap_2d::NO_INFORMATION)
        std::cout << "  ?";
      else
        std::cout << std::setw(3) << (int)cost;
    }
    std::cout << std::endl;
  }

  std::cout << "\n图例:" << std::endl;
  std::cout << "  . = 自由空间 (0)" << std::endl;
  std::cout << "  X = 障碍物 (" << (int)costmap_2d::LETHAL_OBSTACLE << ")" << std::endl;
  std::cout << "  ? = 未知区域 (" << (int)costmap_2d::NO_INFORMATION << ")" << std::endl;
  std::cout << "========================================\n" << std::endl;

  // 清理资源
  delete layered_costmap;

  return 0;
}