/**
 * @file save_map_example.c
 * @brief 将GridMap转换回PGM和YAML格式的示例
 * 
 * 演示如何加载地图，进行处理后再保存为标准地图格式
 */

#include "costmap_2d/grid_map.h"
#include "costmap_2d/grid_map_loader.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// 保存GridMap为PGM图像文件
int saveGridMapToPGM(const grid_map::GridMap* map, const char* filename) {
    FILE* file = fopen(filename, "wb");
    if (!file) {
        fprintf(stderr, "无法创建PGM文件: %s\n", filename);
        return -1;
    }
    
    // 写入PGM头部
    fprintf(file, "P5\n");
    fprintf(file, "# Created by GridMap\n");
    fprintf(file, "%d %d\n", map->getWidth(), map->getHeight());
    fprintf(file, "255\n");
    
    // 写入像素数据（注意Y坐标反转）
    for (int y = map->getHeight() - 1; y >= 0; --y) {
        for (int x = 0; x < map->getWidth(); ++x) {
            grid_map::GridIndex idx(x, y);
            int8_t value = map->getCellSafe(idx, grid_map::GridMap::UNKNOWN);
            
            // 转换为灰度值
            unsigned char gray;
            if (value == grid_map::GridMap::UNKNOWN) {
                gray = 205;  // 未知区域用灰色表示
            } else if (value >= grid_map::GridMap::OCCUPIED) {
                gray = 0;    // 障碍物用黑色表示
            } else {
                gray = 254;  // 自由空间用白色表示
            }
            
            fwrite(&gray, 1, 1, file);
        }
    }
    
    fclose(file);
    printf("已保存PGM文件: %s\n", filename);
    return 0;
}

// 保存GridMap配置为YAML文件
int saveGridMapToYAML(const grid_map::GridMap* map, const char* yaml_filename, const char* pgm_filename) {
    FILE* file = fopen(yaml_filename, "w");
    if (!file) {
        fprintf(stderr, "无法创建YAML文件: %s\n", yaml_filename);
        return -1;
    }
    
    // 提取PGM文件名（去掉路径）
    const char* pgm_basename = strrchr(pgm_filename, '/');
    if (pgm_basename) {
        pgm_basename++;
    } else {
        pgm_basename = pgm_filename;
    }
    
    // 写入YAML内容
    fprintf(file, "image: %s\n", pgm_basename);
    fprintf(file, "resolution: %.6f\n", map->getResolution());
    fprintf(file, "origin: [%.6f, %.6f, %.6f]\n", 
            map->getOrigin().position.x,
            map->getOrigin().position.y,
            map->getOrigin().yaw);
    fprintf(file, "negate: 0\n");
    fprintf(file, "occupied_thresh: 0.65\n");
    fprintf(file, "free_thresh: 0.196\n");
    
    fclose(file);
    printf("已保存YAML文件: %s\n", yaml_filename);
    return 0;
}

// 打印保存信息
void printSaveInfo(const grid_map::GridMap* map, const char* base_name) {
    printf("\n========================================\n");
    printf("  地图保存信息\n");
    printf("========================================\n");
    printf("保存基础名称: %s\n", base_name);
    printf("地图尺寸: %d x %d 栅格\n", map->getWidth(), map->getHeight());
    printf("分辨率: %.6f 米/栅格\n", map->getResolution());
    printf("原点: [%.2f, %.2f, %.2f]\n", 
           map->getOrigin().position.x,
           map->getOrigin().position.y,
           map->getOrigin().yaw);
    
    size_t total_cells = (size_t)map->getWidth() * map->getHeight();
    int free_cells = map->countFreeCells();
    int occupied_cells = map->countOccupiedCells();
    int unknown_cells = map->countUnknownCells();
    
    printf("\n栅格统计:\n");
    printf("  总栅格:    %zu\n", total_cells);
    printf("  空闲栅格:  %d (%.2f%%)\n", free_cells, free_cells * 100.0 / total_cells);
    printf("  障碍栅格:  %d (%.2f%%)\n", occupied_cells, occupied_cells * 100.0 / total_cells);
    printf("  未知栅格:  %d (%.2f%%)\n", unknown_cells, unknown_cells * 100.0 / total_cells);
    printf("========================================\n");
}

int main(int argc, char** argv) {
    if (argc < 3) {
        printf("用法: %s <输入YAML文件> <输出基础名称>\n", argv[0]);
        printf("示例: %s maps/hospital_map.yaml output/hospital_map_modified\n", argv[0]);
        return 1;
    }
    
    const char* input_yaml = argv[1];
    const char* output_base = argv[2];
    
    // 构建输出文件名
    char pgm_filename[256];
    char yaml_filename[256];
    snprintf(pgm_filename, sizeof(pgm_filename), "%s.pgm", output_base);
    snprintf(yaml_filename, sizeof(yaml_filename), "%s.yaml", output_base);
    
    try {
        printf("========================================\n");
        printf("  GridMap 转 PGM/YAML 示例\n");
        printf("========================================\n\n");
        
        // 步骤1: 加载原始地图
        printf("步骤1: 加载原始地图...\n");
        grid_map::GridMap map;
        grid_map::loadMap(input_yaml, map);
        
        // 步骤2: 显示原始地图信息
        printf("\n原始地图信息:\n");
        printf("尺寸: %d x %d 栅格\n", map.getWidth(), map.getHeight());
        printf("分辨率: %.6f 米/栅格\n", map.getResolution());
        
        // 步骤3: 对地图进行一些修改（示例操作）
        printf("\n步骤2: 对地图进行修改...\n");
        
        // 在地图中心附近清除一个区域
        grid_map::GridIndex center(map.getWidth() / 2, map.getHeight() / 2);
        printf("  清除中心区域 (%d, %d)...\n", center.x, center.y);
        map.clearArea(center, 5);
        
        // 在中心偏右位置标记一个障碍物
        grid_map::GridIndex obstacle(center.x + 20, center.y);
        printf("  标记障碍物 (%d, %d)...\n", obstacle.x, obstacle.y);
        map.markObstacle(obstacle, 10);
        
        // 步骤4: 保存修改后的地图
        printf("\n步骤3: 保存修改后的地图...\n");
        
        // 创建输出目录（如果需要）
        const char* last_slash = strrchr(output_base, '/');
        if (last_slash) {
            char mkdir_cmd[256];
            size_t dir_len = last_slash - output_base;
            snprintf(mkdir_cmd, sizeof(mkdir_cmd), "mkdir -p %.*s", (int)dir_len, output_base);
            system(mkdir_cmd);
        }
        
        // 保存PGM文件
        if (saveGridMapToPGM(&map, pgm_filename) != 0) {
            fprintf(stderr, "保存PGM失败\n");
            return 1;
        }
        
        // 保存YAML文件
        if (saveGridMapToYAML(&map, yaml_filename, pgm_filename) != 0) {
            fprintf(stderr, "保存YAML失败\n");
            return 1;
        }
        
        // 步骤5: 显示保存信息
        printSaveInfo(&map, output_base);
        
        printf("\n地图转换完成!\n");
        
    } catch (const std::exception& e) {
        fprintf(stderr, "错误: %s\n", e.what());
        return 1;
    }
    
    return 0;
}