#!/bin/bash

# 设置ROS环境
export ROS_HOME=/home/zy/cosmap/ros_data

# 停止之前的进程
killall -9 roscore map_server inflation_demo 2>/dev/null

# 启动roscore
echo "启动 roscore..."
roscore &
sleep 3

# 启动地图服务器
echo "启动 map_server..."
rosrun map_server map_server /home/zy/cosmap/small_map.yaml &
sleep 2

# 运行demo
echo "启动 inflation_demo..."
cd /home/zy/cosmap/build
./inflation_demo

# 清理
killall -9 roscore map_server inflation_demo 2>/dev/null