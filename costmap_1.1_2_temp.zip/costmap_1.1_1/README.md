# CosMap - 独立栅格地图库

一个不依赖ROS的轻量级栅格地图数据结构，用于机器人导航和路径规划。

## 特性

- ✅ **完全独立**：不依赖ROS，可单独使用
- ✅ **轻量级**：仅依赖SDL_image库
- ✅ **功能完整**：支持坐标转换、地图查询、统计分析
- ✅ **兼容性好**：可直接加载ROS格式的地图文件
- ✅ **易于集成**：提供静态库和共享库

## 项目结构

```
cosmap/
├── include/                    # 头文件
│   ├── grid_map.h             # 核心数据结构
│   ├── grid_map_loader.h      # 地图加载器
│   └── image_loader.h         # 原ROS兼容头文件
├── src/                       # 源文件
│   ├── grid_map.cpp           # 核心实现
│   ├── grid_map_loader.cpp    # 加载器实现
│   └── image_loader.cpp       # 原ROS兼容实现
├── examples/                  # 示例程序
│   └── grid_map_example.cpp   # 使用示例
├── maps/                      # 地图数据
│   ├── hospital_map.pgm       # 医院地图图像
│   └── hospital_map.yaml      # 地图配置
├── CMakeLists.txt            # 构建配置
└── README.md                 # 本文件
```

## 核心组件

### 1. GridMap - 栅格地图数据结构

替代ROS的`nav_msgs/OccupancyGrid`，提供：

- **基础功能**：地图初始化、重置、调整大小
- **栅格访问**：获取/设置栅格值，边界安全访问
- **坐标转换**：世界坐标 ↔ 栅格索引（支持旋转）
- **地图查询**：自由/障碍/未知区域检测
- **统计分析**：覆盖率、占用率计算
- **地图操作**：障碍物膨胀、区域清除/标记

### 2. GridMapLoader - 地图加载器

替代ROS的`map_server`，支持：

- **YAML配置解析**：读取地图元数据
- **图像加载**：支持PGM、PNG等格式
- **三种地图模式**：
  - `TRINARY`：三值模式（0=自由，100=障碍，-1=未知）
  - `SCALE`：线性缩放模式（1-99）
  - `RAW`：原始像素值模式
- **地图保存**：导出为PGM+YAML格式

## 编译安装

### 依赖

- CMake >= 3.10
- SDL2
- SDL2_image
- C++11编译器

### Ubuntu/Debian安装依赖

```bash
sudo apt-get update
sudo apt-get install cmake libsdl2-dev libsdl2-image-dev
```

### 编译

```bash
mkdir build && cd build
cmake ..
make
```

### 安装

```bash
sudo make install
```

## 使用示例

### 基本使用

```cpp
#include "grid_map.h"
#include "grid_map_loader.h"

using namespace grid_map;

int main() {
    // 加载地图
    GridMap map;
    loadMap("maps/hospital_map.yaml", map);
    
    // 获取地图信息
    std::cout << "地图尺寸: " << map.getWidth() << "x" << map.getHeight() << std::endl;
    std::cout << "分辨率: " << map.getResolution() << " 米/栅格" << std::endl;
    
    // 坐标转换
    Point2D world_point(10.0, 5.0);
    GridIndex grid_idx = map.worldToGrid(world_point);
    Point2D world_back = map.gridToWorld(grid_idx);
    
    // 查询栅格状态
    if (map.isFree(grid_idx)) {
        std::cout << "该位置是自由空间" << std::endl;
    } else if (map.isOccupied(grid_idx)) {
        std::cout << "该位置是障碍物" << std::endl;
    }
    
    // 地图操作
    map.inflateObstacles(2);  // 膨胀障碍物
    map.clearArea(grid_idx, 1);  // 清除区域
    
    return 0;
}
```

### 运行示例程序

```bash
# 编译后运行
./build/grid_map_example

# 或指定地图文件
./build/grid_map_example /path/to/your/map.yaml
```

## 与ROS OccupancyGrid对比

| 特性 | ROS OccupancyGrid | GridMap |
|------|------------------|---------|
| 依赖 | ROS | 仅SDL_image |
| 数据格式 | ROS消息 | C++类 |
| 坐标转换 | 手动计算 | 内置支持 |
| 地图查询 | 手动遍历 | 提供API |
| 统计分析 | 需自行实现 | 内置函数 |
| 地图操作 | 需自行实现 | 内置函数 |
| 文件I/O | map_server | 内置支持 |

## API参考

### 核心类

#### GridMap

```cpp
// 构造函数
GridMap();
GridMap(int width, int height, double resolution, const MapOrigin& origin);

// 初始化
void initialize(int width, int height, double resolution, const MapOrigin& origin);

// 栅格访问
int8_t getCell(const GridIndex& index) const;
void setCell(const GridIndex& index, int8_t value);
int8_t getCellSafe(const GridIndex& index, int8_t default_value = UNKNOWN) const;

// 坐标转换
GridIndex worldToGrid(const Point2D& world_point) const;
Point2D gridToWorld(const GridIndex& grid_index) const;

// 地图查询
bool isFree(const GridIndex& index) const;
bool isOccupied(const GridIndex& index) const;
bool isUnknown(const GridIndex& index) const;

// 地图操作
void inflateObstacles(int radius);
void clearArea(const GridIndex& center, int radius);
void markObstacle(const GridIndex& center, int radius);

// 统计分析
int countFreeCells() const;
int countOccupiedCells() const;
double getCoverage() const;
double getOccupancyRate() const;
```

#### GridMapLoader

```cpp
// 加载地图
void loadMap(const std::string& yaml_file, GridMap& map);
void loadMapFromImage(const std::string& image_file, const MapConfig& config, GridMap& map);
void loadMapConfig(const std::string& yaml_file, MapConfig& config);

// 保存地图
void saveMap(const GridMap& map, const std::string& base_path);
void saveMapToPGM(const GridMap& map, const std::string& pgm_file);
void saveMapConfig(const GridMap& map, const std::string& yaml_file);
```

## 栅格值定义

- `0`：自由空间
- `1-99`：占用概率（数值越大，占用概率越高）
- `100`：障碍物
- `-1`：未知区域
- `255`：特殊标记（如地图边界）

## 应用场景

- 机器人导航系统
- 路径规划算法（A*、Dijkstra、RRT等）
- 避障系统
- SLAM地图表示
- 仿真环境建模

## 许可证

本项目采用BSD许可证，兼容原ROS map_server的许可证。

## 作者

基于ROS map_server重构，移除ROS依赖，提供独立的数据结构。

## 贡献

欢迎提交Issue和Pull Request！