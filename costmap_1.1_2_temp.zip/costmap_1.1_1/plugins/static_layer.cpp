#include <costmap_2d/static_layer.h>
#include <costmap_2d/costmap_math.h>
#include <tf2/convert.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>

// 注意：已移除 PLUGINLIB_EXPORT_CLASS 宏，因为本项目不使用插件系统

// 使用代价地图常量
using costmap_2d::NO_INFORMATION;    // 未知空间（255）
using costmap_2d::LETHAL_OBSTACLE;   // 致命障碍（254）
using costmap_2d::FREE_SPACE;        // 自由空间（0）

namespace costmap_2d
{

/**
 * @brief 构造函数
 */
StaticLayer::StaticLayer() {}

/**
 * @brief 析构函数
 */
StaticLayer::~StaticLayer()
{
}

/**
 * @brief 初始化静态层
 *
 * 执行以下操作：
 * 1. 读取配置参数
 * 2. 订阅地图话题（latched模式）
 * 3. 等待地图数据到达
 * 4. 设置动态重配置服务器
 */
void StaticLayer::onInitialize()
{
  ros::NodeHandle nh("~/" + name_), g_nh;
  current_ = true;

  // 获取全局坐标系名称（通常为 "map"）
  global_frame_ = layered_costmap_->getGlobalFrameID();

  // ===== 读取配置参数 =====
  //
  // 以下参数可通过 YAML 配置文件或动态重配置设置。
  // 参数命名空间: ~/<layer_name>
  // 例如: /move_base/global_costmap/static_layer/map_topic

  /**
   * @param map_topic (string, default: "map")
   * 订阅的地图话题名称。
   * map_server 默认发布到 /map 话题（latched 模式）。
   * 如果多个 map_server 实例运行，可指定不同话题。
   */
  std::string map_topic;
  nh.param("map_topic", map_topic, std::string("map"));

  /**
   * @param first_map_only (bool, default: false)
   * 是否只接收第一张地图。
   * true: 收到第一张地图后关闭 map_sub_ 订阅器。
   *       适用于静态环境，节省订阅资源。
   * false: 持续监听地图话题，支持动态地图更新。
   */
  nh.param("first_map_only", first_map_only_, false);

  /**
   * @param subscribe_to_updates (bool, default: false)
   * 是否订阅地图增量更新。
   * true: 订阅 <map_topic>_updates 话题，只更新变化区域。
   *       适用于大地图或频繁更新的场景，提高效率。
   * false: 只接收完整地图，不接收增量更新。
   */
  nh.param("subscribe_to_updates", subscribe_to_updates_, false);

  /**
   * @param track_unknown_space (bool, default: true)
   * 是否跟踪未知空间。
   * true: 未知区域(-1)转换为 NO_INFORMATION(255)。
   *       规划器会避开未知区域。
   * false: 未知区域(-1)转换为 FREE_SPACE(0)。
   *       规划器将未知区域视为可通行。
   */
  nh.param("track_unknown_space", track_unknown_space_, true);

  /**
   * @param use_maximum (bool, default: false)
   * 融合到主代价地图时的策略。
   * true: 取静态层和主代价地图的最大值。
   *       适用于静态层优先级高于其他图层的情况。
   * false: 静态层直接覆盖主代价地图。
   *       适用于静态层作为基础图层的情况。
   */
  nh.param("use_maximum", use_maximum_, false);

  /**
   * @param lethal_cost_threshold (int, default: 100, range: [0, 100])
   * 障碍物判定阈值。
   * 地图原始值 >= 此阈值时，转换为 LETHAL_OBSTACLE(254)。
   * 降低阈值可使更多区域被视为障碍（更保守）。
   * 提高阈值可使更少区域被视为障碍（更激进）。
   */
  int temp_lethal_threshold;
  nh.param("lethal_cost_threshold", temp_lethal_threshold, int(100));

  /**
   * @param unknown_cost_value (int, default: -1)
   * 地图中表示未知区域的原始值。
   * ROS OccupancyGrid 标准使用 -1 表示未知。
   * 某些自定义地图可能使用其他值（如 255）。
   */
  int temp_unknown_cost_value;
  nh.param("unknown_cost_value", temp_unknown_cost_value, int(-1));

  /**
   * @param trinary_costmap (bool, default: true)
   * 是否使用三值化模式。
   * true: 只有三种值：FREE_SPACE(0), LETHAL_OBSTACLE(254), NO_INFORMATION(255)。
   *       简单高效，适用于大多数场景。
   * false: SCALE模式，支持 1~99 的中间代价值。
   *       适用于需要精细代价规划的场景。
   */
  nh.param("trinary_costmap", trinary_costmap_, true);

  // 确保阈值在有效范围内 [0, 100]
  // 防止用户配置错误导致异常行为
  lethal_threshold_ = std::max(std::min(temp_lethal_threshold, 100), 0);
  unknown_cost_value_ = temp_unknown_cost_value;

  // ===== 订阅地图话题 =====
  // 只有当话题名称改变时才重新订阅
  if (map_sub_.getTopic() != ros::names::resolve(map_topic))
  {
    // 订阅 latched 话题（新订阅者会立即收到最新地图）
    ROS_INFO("Requesting the map...");
    map_sub_ = g_nh.subscribe(map_topic, 1, &StaticLayer::incomingMap, this);
    map_received_ = false;
    has_updated_data_ = false;

    // 阻塞等待地图到达
    ros::Rate r(10);
    while (!map_received_ && g_nh.ok())
    {
      ros::spinOnce();
      r.sleep();
    }

    ROS_INFO("Received a %d X %d map at %f m/pix", getSizeInCellsX(), getSizeInCellsY(), getResolution());

    // 可选：订阅地图增量更新
    if (subscribe_to_updates_)
    {
      ROS_INFO("Subscribing to updates");
      map_update_sub_ = g_nh.subscribe(map_topic + "_updates", 10, &StaticLayer::incomingUpdate, this);
    }
  }
  else
  {
    has_updated_data_ = true;
  }
}

/**
 * @brief 匹配主代价地图的尺寸
 *
 * 如果不使用滚动窗口，静态层的尺寸应与主代价地图一致。
 */
void StaticLayer::matchSize()
{
  // 滚动窗口模式下，静态地图尺寸与分层代价地图无关
  if (!layered_costmap_->isRolling())
  {
    Costmap2D* master = layered_costmap_->getCostmap();
    resizeMap(master->getSizeInCellsX(), master->getSizeInCellsY(), master->getResolution(),
              master->getOriginX(), master->getOriginY());
  }
}

/**
 * @brief 将地图原始值转换为代价地图值
 *
 * 转换规则：
 * - 未知区域 → NO_INFORMATION(255) 或 FREE_SPACE(0)
 * - 障碍物 → LETHAL_OBSTACLE(254)
 * - 自由空间 → FREE_SPACE(0)
 * - SCALE模式 → 线性插值 (1~99)
 *
 * @param value 地图原始值（通常为 -1, 0~100）
 * @return 转换后的代价值
 */
unsigned char StaticLayer::interpretValue(unsigned char value)
{
  // 处理未知区域unknown_cost_value_默认取值为-1
  if (track_unknown_space_ && value == unknown_cost_value_)
    return NO_INFORMATION;  // 255
  else if (!track_unknown_space_ && value == unknown_cost_value_)
    return FREE_SPACE;      // 0

  // 处理障碍物lethal_threshold_默认取值为100
  else if (value >= lethal_threshold_)
    return LETHAL_OBSTACLE; // 254

  // 三值化模式：非障碍即自由，静态层默认取值为0
  else if (trinary_costmap_)
    return FREE_SPACE;      // 0

  // SCALE模式：线性插值
  double scale = (double) value / lethal_threshold_;
  return scale * LETHAL_OBSTACLE;  // 1~99
}

/**
 * @brief 接收新地图的回调函数
 *
 * 处理流程：
 * 1. 检查地图尺寸/分辨率/原点是否匹配
 * 2. 必要时调整代价地图尺寸
 * 3. 遍历像素并转换值
 * 4. 标记地图已更新
 *
 * @param new_map 新地图消息
 */
void StaticLayer::incomingMap(const nav_msgs::OccupancyGridConstPtr& new_map)
{
  unsigned int size_x = new_map->info.width, size_y = new_map->info.height;

  ROS_DEBUG("Received a %d X %d map at %f m/pix", size_x, size_y, new_map->info.resolution);

  // ===== 检查并调整地图尺寸 =====
  Costmap2D* master = layered_costmap_->getCostmap();

  // 非滚动窗口模式：需要调整整个分层代价地图
  if (!layered_costmap_->isRolling() &&
      (master->getSizeInCellsX() != size_x ||
       master->getSizeInCellsY() != size_y ||
       master->getResolution() != new_map->info.resolution ||
       master->getOriginX() != new_map->info.origin.position.x ||
       master->getOriginY() != new_map->info.origin.position.y))
  {
    // 更新分层代价地图尺寸（包括所有图层）
    ROS_INFO("Resizing costmap to %d X %d at %f m/pix", size_x, size_y, new_map->info.resolution);
    layered_costmap_->resizeMap(size_x, size_y, new_map->info.resolution, new_map->info.origin.position.x,
                                new_map->info.origin.position.y,
                                true /* 锁定尺寸 */);
  }
  // 滚动窗口模式：只调整本地静态层尺寸
  else if (size_x_ != size_x || size_y_ != size_y ||
           resolution_ != new_map->info.resolution ||
           origin_x_ != new_map->info.origin.position.x ||
           origin_y_ != new_map->info.origin.position.y)
  {
    ROS_INFO("Resizing static layer to %d X %d at %f m/pix", size_x, size_y, new_map->info.resolution);
    resizeMap(size_x, size_y, new_map->info.resolution,
              new_map->info.origin.position.x, new_map->info.origin.position.y);
  }

  // ===== 遍历像素并转换值 =====
  unsigned int index = 0;
  for (unsigned int i = 0; i < size_y; ++i)
  {
    for (unsigned int j = 0; j < size_x; ++j)
    {
      unsigned char value = new_map->data[index];
      costmap_[index] = interpretValue(value);
      ++index;
    }
  }

  // 保存地图坐标系
  map_frame_ = new_map->header.frame_id;

  // 标记整个地图已更新
  x_ = y_ = 0;
  width_ = size_x_;
  height_ = size_y_;
  map_received_ = true;
  has_updated_data_ = true;

  // 如果设置了 first_map_only，关闭地图订阅
  if (first_map_only_)
  {
    ROS_INFO("Shutting down the map subscriber. first_map_only flag is on");
    map_sub_.shutdown();
  }
}

/**
 * @brief 接收地图增量更新的回调函数
 *
 * 只更新地图的指定区域，提高效率。
 *
 * @param update 地图更新消息
 */
void StaticLayer::incomingUpdate(const map_msgs::OccupancyGridUpdateConstPtr& update)
{
  unsigned int di = 0;

  // 遍历更新区域
  for (unsigned int y = 0; y < update->height; y++)
  {
    unsigned int index_base = (update->y + y) * size_x_;
    for (unsigned int x = 0; x < update->width; x++)
    {
      unsigned int index = index_base + x + update->x;
      costmap_[index] = interpretValue(update->data[di++]);
    }
  }

  // 标记更新区域，x_和y_为更新区域的左上角坐标
  x_ = update->x;
  y_ = update->y;
  width_ = update->width;
  height_ = update->height;
  has_updated_data_ = true;
}

/**
 * @brief 激活静态层
 *
 * 重新初始化订阅器。
 */
void StaticLayer::activate()
{
  onInitialize();
}

/**
 * @brief 停用静态层
 *
 * 关闭所有订阅器。
 */
void StaticLayer::deactivate()
{
  map_sub_.shutdown();
  if (subscribe_to_updates_)
    map_update_sub_.shutdown();
}

/**
 * @brief 重置静态层
 *
 * 根据 first_map_only 标志决定行为。
 */
void StaticLayer::reset()
{
  if (first_map_only_)
  {
    // 只使用第一张地图，标记为已更新
    has_updated_data_ = true;
  }
  else
  {
    // 重新初始化，重新订阅地图
    onInitialize();
  }
}

/**
 * @brief 计算需要更新的边界框
 *
 * @param robot_x 机器人X坐标
 * @param robot_y 机器人Y坐标
 * @param robot_yaw 机器人航向角
 * @param min_x 最小X坐标（输出）
 * @param min_y 最小Y坐标（输出）
 * @param max_x 最大X坐标（输出）
 * @param max_y 最大Y坐标（输出）
 */
void StaticLayer::updateBounds(double robot_x, double robot_y, double robot_yaw, double* min_x, double* min_y,
                               double* max_x, double* max_y)
{
  ROS_INFO("StaticLayer::updateBounds() 被调用 - robot_x: %.2f, robot_y: %.2f", robot_x, robot_y);
  ROS_INFO("StaticLayer::updateBounds() - map_received_: %d, has_updated_data_: %d, has_extra_bounds_: %d, isRolling: %d", 
           map_received_, has_updated_data_, has_extra_bounds_, layered_costmap_->isRolling());
  
  // 非滚动窗口模式：只有收到新数据时才更新
  if (!layered_costmap_->isRolling()) {
    if (!map_received_ || !(has_updated_data_ || has_extra_bounds_))
    {
      ROS_WARN("StaticLayer::updateBounds() - 提前返回");
      return;
    }
  }

  // 使用额外边界（如果有）
  useExtraBounds(min_x, min_y, max_x, max_y);

  // 计算更新区域的边界
  double wx, wy;

  // 左下角
  mapToWorld(x_, y_, wx, wy);
  *min_x = std::min(wx, *min_x);
  *min_y = std::min(wy, *min_y);

  // 右上角
  mapToWorld(x_ + width_, y_ + height_, wx, wy);
  *max_x = std::max(wx, *max_x);
  *max_y = std::max(wy, *max_y);

  // 重置更新标志
  has_updated_data_ = false;
}

/**
 * @brief 将静态层数据融合到主代价地图
 *
 * @param master_grid 主代价地图
 * @param min_i 更新区域最小列索引
 * @param min_j 更新区域最小行索引
 * @param max_i 更新区域最大列索引
 * @param max_j 更新区域最大行索引
 */
void StaticLayer::updateCosts(costmap_2d::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j)
{
  ROS_INFO("StaticLayer::updateCosts() 被调用 - min_i: %d, min_j: %d, max_i: %d, max_j: %d", 
           min_i, min_j, max_i, max_j);
  
  if (!map_received_)
  {
    ROS_WARN("StaticLayer::updateCosts() - map_received_ 为 false");
    return;
  }

  // ===== 非滚动窗口模式 =====
  if (!layered_costmap_->isRolling())
  {
    // 坐标系一致，直接复制
    if (!use_maximum_)
    {
      ROS_INFO("StaticLayer::updateCosts() - 使用 updateWithTrueOverwrite");
      updateWithTrueOverwrite(master_grid, min_i, min_j, max_i, max_j);
    }
    else
    {
      ROS_INFO("StaticLayer::updateCosts() - 使用 updateWithMax");
      updateWithMax(master_grid, min_i, min_j, max_i, max_j);
    }
  }
  // ===== 滚动窗口模式 =====
  // 注意：滚动窗口模式需要TF变换支持，这里简化处理
  // 在非滚动窗口模式下，这部分代码不会被执行
  else
  {
    // 需要进行坐标变换
    // 由于当前demo使用非滚动窗口模式，这里简化处理
    ROS_WARN("Rolling window mode not supported in this demo");
  }
}

}  // namespace costmap_2d