/**
 * @file obstacle_layer.cpp
 * @brief 障碍物层实现文件
 * 
 * ObstacleLayer 是代价地图系统中负责动态障碍物感知与更新的核心组件。
 * 主要功能包括：
 * 1. 订阅激光雷达、点云等传感器话题
 * 2. 将传感器检测到的障碍物标记到代价地图中
 * 3. 通过射线追踪技术清除不再存在的障碍物
 * 4. 将障碍物层数据融合到全局代价地图
 */

#include <costmap_2d/obstacle_layer.h>
#include <costmap_2d/costmap_math.h>
#include <tf2_ros/message_filter.h>

#include <pluginlib/class_list_macros.hpp>
#include <sensor_msgs/point_cloud2_iterator.h>

// 注册为 ROS 插件
PLUGINLIB_EXPORT_CLASS(costmap_2d::ObstacleLayer, costmap_2d::Layer)

using costmap_2d::NO_INFORMATION;    // 未知区域代价值
using costmap_2d::LETHAL_OBSTACLE;   // 致命障碍物代价值
using costmap_2d::FREE_SPACE;        // 自由空间代价值

using costmap_2d::ObservationBuffer;
using costmap_2d::Observation;

namespace costmap_2d
{

/**
 * @brief 障碍物层初始化函数
 * 
 * 从参数服务器读取配置，创建观测缓冲区和传感器订阅器，
 * 支持 LaserScan、PointCloud、PointCloud2 三种数据类型。
 */
void ObstacleLayer::onInitialize()
{
  ros::NodeHandle nh("~/" + name_), g_nh;
  // 获取滚动窗口模式
  rolling_window_ = layered_costmap_->isRolling();

  // 设置默认代价值：是否跟踪未知空间
  bool track_unknown_space;
  nh.param("track_unknown_space", track_unknown_space, layered_costmap_->isTrackingUnknown());
  if (track_unknown_space)
    default_value_ = NO_INFORMATION;
  else
    default_value_ = FREE_SPACE;

  // 匹配主代价地图尺寸
  ObstacleLayer::matchSize();
  current_ = true;

  // 获取全局坐标系和变换容忍度
  global_frame_ = layered_costmap_->getGlobalFrameID();
  double transform_tolerance;
  nh.param("transform_tolerance", transform_tolerance, 0.2);

  // 获取传感器源配置字符串
  std::string topics_string;
  nh.param("observation_sources", topics_string, std::string(""));
  ROS_INFO("    Subscribed to Topics: %s", topics_string.c_str());

  // 按空格分割传感器源
  std::stringstream ss(topics_string);
  std::string source;
  while (ss >> source)
  {
    ros::NodeHandle source_node(nh, source);

    // 读取每个传感器的配置参数
    double observation_keep_time, expected_update_rate, min_obstacle_height, max_obstacle_height;
    std::string topic, sensor_frame, data_type;
    bool inf_is_valid, clearing, marking;

    source_node.param("topic", topic, source);                        // 话题名称
    source_node.param("sensor_frame", sensor_frame, std::string("")); // 传感器坐标系
    source_node.param("observation_persistence", observation_keep_time, 0.0);     // 观测数据持久化时间
    source_node.param("expected_update_rate", expected_update_rate, 0.0);         // 期望更新频率
    source_node.param("data_type", data_type, std::string("PointCloud"));         // 数据类型
    source_node.param("min_obstacle_height", min_obstacle_height, 0.0);          // 最小障碍物高度
    source_node.param("max_obstacle_height", max_obstacle_height, 2.0);          // 最大障碍物高度
    source_node.param("inf_is_valid", inf_is_valid, false);                      // 无穷远值是否有效
    source_node.param("clearing", clearing, false);                              // 是否用于清除自由空间
    source_node.param("marking", marking, true);                                 // 是否用于标记障碍物

    // 验证数据类型合法性
    if (!(data_type == "PointCloud2" || data_type == "PointCloud" || data_type == "LaserScan"))
    {
      ROS_FATAL("Only topics that use point clouds or laser scans are currently supported");
      throw std::runtime_error("Only topics that use point clouds or laser scans are currently supported");
    }

    // 获取障碍物检测范围和射线追踪范围
    std::string raytrace_range_param_name, obstacle_range_param_name;
    double obstacle_range = 2.5;  // 默认障碍物检测范围 2.5 米
    if (source_node.searchParam("obstacle_range", obstacle_range_param_name))
    {
      source_node.getParam(obstacle_range_param_name, obstacle_range);
    }

    double raytrace_range = 3.0;  // 默认射线追踪范围 3.0 米
    if (source_node.searchParam("raytrace_range", raytrace_range_param_name))
    {
      source_node.getParam(raytrace_range_param_name, raytrace_range);
    }

    ROS_DEBUG("Creating an observation buffer for source %s, topic %s, frame %s", 
              source.c_str(), topic.c_str(), sensor_frame.c_str());

    // 创建观测缓冲区
    observation_buffers_.push_back(
        boost::shared_ptr<ObservationBuffer>(
            new ObservationBuffer(topic, observation_keep_time, expected_update_rate, 
                                  min_obstacle_height, max_obstacle_height, 
                                  obstacle_range, raytrace_range, *tf_, 
                                  global_frame_, sensor_frame, transform_tolerance)));

    // 根据配置添加到标记缓冲区
    if (marking)
      marking_buffers_.push_back(observation_buffers_.back());

    // 根据配置添加到清除缓冲区
    if (clearing)
      clearing_buffers_.push_back(observation_buffers_.back());

    ROS_DEBUG("Created an observation buffer for source %s, topic %s, global frame: %s, "
              "expected update rate: %.2f, observation persistence: %.2f",
              source.c_str(), topic.c_str(), global_frame_.c_str(), 
              expected_update_rate, observation_keep_time);

    // 根据数据类型创建对应的订阅器和回调
    if (data_type == "LaserScan")
    {
      boost::shared_ptr<message_filters::Subscriber<sensor_msgs::LaserScan>> 
          sub(new message_filters::Subscriber<sensor_msgs::LaserScan>(g_nh, topic, 50));

      boost::shared_ptr<tf2_ros::MessageFilter<sensor_msgs::LaserScan>> filter(
          new tf2_ros::MessageFilter<sensor_msgs::LaserScan>(*sub, *tf_, global_frame_, 50, g_nh));

      // 根据是否允许无穷远值选择不同的回调
      if (inf_is_valid)
      {
        filter->registerCallback([this,buffer=observation_buffers_.back()](auto& msg){ 
          laserScanValidInfCallback(msg, buffer); 
        });
      }
      else
      {
        filter->registerCallback([this,buffer=observation_buffers_.back()](auto& msg){ 
          laserScanCallback(msg, buffer); 
        });
      }

      observation_subscribers_.push_back(sub);
      observation_notifiers_.push_back(filter);
      observation_notifiers_.back()->setTolerance(ros::Duration(0.05));
    }
    else if (data_type == "PointCloud")
    {
      boost::shared_ptr<message_filters::Subscriber<sensor_msgs::PointCloud>> 
          sub(new message_filters::Subscriber<sensor_msgs::PointCloud>(g_nh, topic, 50));

      if (inf_is_valid)
      {
        ROS_WARN("obstacle_layer: inf_is_valid option is not applicable to PointCloud observations.");
      }

      boost::shared_ptr<tf2_ros::MessageFilter<sensor_msgs::PointCloud>> 
          filter(new tf2_ros::MessageFilter<sensor_msgs::PointCloud>(*sub, *tf_, global_frame_, 50, g_nh));
      filter->registerCallback([this,buffer=observation_buffers_.back()](auto& msg){ 
        pointCloudCallback(msg, buffer); 
      });

      observation_subscribers_.push_back(sub);
      observation_notifiers_.push_back(filter);
    }
    else  // PointCloud2
    {
      boost::shared_ptr<message_filters::Subscriber<sensor_msgs::PointCloud2>> 
          sub(new message_filters::Subscriber<sensor_msgs::PointCloud2>(g_nh, topic, 50));

      if (inf_is_valid)
      {
        ROS_WARN("obstacle_layer: inf_is_valid option is not applicable to PointCloud observations.");
      }

      boost::shared_ptr<tf2_ros::MessageFilter<sensor_msgs::PointCloud2>> 
          filter(new tf2_ros::MessageFilter<sensor_msgs::PointCloud2>(*sub, *tf_, global_frame_, 50, g_nh));
      filter->registerCallback([this,buffer=observation_buffers_.back()](auto& msg){ 
        pointCloud2Callback(msg, buffer); 
      });

      observation_subscribers_.push_back(sub);
      observation_notifiers_.push_back(filter);
    }

    // 设置目标坐标系
    if (sensor_frame != "")
    {
      std::vector<std::string> target_frames;
      target_frames.push_back(global_frame_);
      target_frames.push_back(sensor_frame);
      observation_notifiers_.back()->setTargetFrames(target_frames);
    }
  }

  // 初始化动态重配置
  dsrv_ = NULL;
  setupDynamicReconfigure(nh);
}

/**
 * @brief 设置动态重配置服务
 */
void ObstacleLayer::setupDynamicReconfigure(ros::NodeHandle& nh)
{
  dsrv_ = new dynamic_reconfigure::Server<costmap_2d::ObstaclePluginConfig>(nh);
  dynamic_reconfigure::Server<costmap_2d::ObstaclePluginConfig>::CallbackType cb =
      [this](auto& config, auto level){ reconfigureCB(config, level); };
  dsrv_->setCallback(cb);
}

/**
 * @brief 析构函数
 */
ObstacleLayer::~ObstacleLayer()
{
  if (dsrv_)
    delete dsrv_;
}

/**
 * @brief 动态重配置回调函数
 * @param config 配置参数
 * @param level 重配置级别
 */
void ObstacleLayer::reconfigureCB(costmap_2d::ObstaclePluginConfig &config, uint32_t level)
{
  enabled_ = config.enabled;                        // 是否启用障碍物层
  footprint_clearing_enabled_ = config.footprint_clearing_enabled;  // 是否清除机器人足迹
  max_obstacle_height_ = config.max_obstacle_height;                // 最大障碍物高度
  combination_method_ = config.combination_method;                  // 融合方法
}

/**
 * @brief 激光雷达消息回调函数
 * @param message 激光扫描消息
 * @param buffer 观测缓冲区指针
 */
void ObstacleLayer::laserScanCallback(const sensor_msgs::LaserScanConstPtr& message,
                                      const boost::shared_ptr<ObservationBuffer>& buffer)
{
  // 将激光扫描转换为点云
  sensor_msgs::PointCloud2 cloud;
  cloud.header = message->header;

  try
  {
    // 使用 TF 将激光扫描转换到全局坐标系
    projector_.transformLaserScanToPointCloud(message->header.frame_id, *message, cloud, *tf_);
  }
  catch (tf2::TransformException &ex)
  {
    ROS_WARN("High fidelity enabled, but TF returned a transform exception to frame %s: %s", 
             global_frame_.c_str(), ex.what());
    // 降级处理：不进行坐标变换
    projector_.projectLaser(*message, cloud);
  }
  catch (std::runtime_error &ex)
  {
    ROS_WARN("transformLaserScanToPointCloud error, it seems the message from laser sensor is malformed. "
             "Ignore this laser scan. what(): %s", ex.what());
    return;
  }

  // 将点云存入缓冲区（线程安全）
  buffer->lock();
  buffer->bufferCloud(cloud);
  buffer->unlock();
}

/**
 * @brief 支持无穷远值的激光雷达消息回调函数
 * @param raw_message 原始激光扫描消息
 * @param buffer 观测缓冲区指针
 * 
 * 将激光扫描中的正无穷远值替换为最大量程值，然后转换为点云。
 */
void ObstacleLayer::laserScanValidInfCallback(const sensor_msgs::LaserScanConstPtr& raw_message,
                                              const boost::shared_ptr<ObservationBuffer>& buffer)
{
  // 将正无穷远值替换为最大量程
  float epsilon = 0.0001;  // 微小偏移量，避免等于 range_max
  sensor_msgs::LaserScan message = *raw_message;
  for (size_t i = 0; i < message.ranges.size(); i++)
  {
    float range = message.ranges[i];
    if (!std::isfinite(range) && range > 0)
    {
      message.ranges[i] = message.range_max - epsilon;
    }
  }

  // 将激光扫描转换为点云
  sensor_msgs::PointCloud2 cloud;
  cloud.header = message.header;

  try
  {
    projector_.transformLaserScanToPointCloud(message.header.frame_id, message, cloud, *tf_);
  }
  catch (tf2::TransformException &ex)
  {
    ROS_WARN("High fidelity enabled, but TF returned a transform exception to frame %s: %s",
             global_frame_.c_str(), ex.what());
    projector_.projectLaser(message, cloud);
  }
  catch (std::runtime_error &ex)
  {
    ROS_WARN("transformLaserScanToPointCloud error, it seems the message from laser sensor is malformed. "
             "Ignore this laser scan. what(): %s", ex.what());
    return;
  }

  // 将点云存入缓冲区
  buffer->lock();
  buffer->bufferCloud(cloud);
  buffer->unlock();
}

/**
 * @brief PointCloud 消息回调函数
 * @param message PointCloud 消息
 * @param buffer 观测缓冲区指针
 * 
 * 将 PointCloud 转换为 PointCloud2 后存入缓冲区。
 */
void ObstacleLayer::pointCloudCallback(const sensor_msgs::PointCloudConstPtr& message,
                                       const boost::shared_ptr<ObservationBuffer>& buffer)
{
  sensor_msgs::PointCloud2 cloud2;

  // 转换为 PointCloud2 格式
  if (!sensor_msgs::convertPointCloudToPointCloud2(*message, cloud2))
  {
    ROS_ERROR("Failed to convert a PointCloud to a PointCloud2, dropping message");
    return;
  }

  // 将点云存入缓冲区
  buffer->lock();
  buffer->bufferCloud(cloud2);
  buffer->unlock();
}

/**
 * @brief PointCloud2 消息回调函数
 * @param message PointCloud2 消息
 * @param buffer 观测缓冲区指针
 */
void ObstacleLayer::pointCloud2Callback(const sensor_msgs::PointCloud2ConstPtr& message,
                                        const boost::shared_ptr<ObservationBuffer>& buffer)
{
  // 直接将点云存入缓冲区
  buffer->lock();
  buffer->bufferCloud(*message);
  buffer->unlock();
}

/**
 * @brief 更新代价地图边界
 * @param robot_x 机器人 X 坐标
 * @param robot_y 机器人 Y 坐标
 * @param robot_yaw 机器人大航向角
 * @param min_x 输出参数：最小 X 边界
 * @param min_y 输出参数：最小 Y 边界
 * @param max_x 输出参数：最大 X 边界
 * @param max_y 输出参数：最大 Y 边界
 * 
 * 执行射线追踪清除自由空间，并标记新检测到的障碍物。
 */
void ObstacleLayer::updateBounds(double robot_x, double robot_y, double robot_yaw, 
                                  double* min_x, double* min_y, double* max_x, double* max_y)
{
  // 滚动窗口模式：更新地图原点
  if (rolling_window_)
    updateOrigin(robot_x - getSizeInMetersX() / 2, robot_y - getSizeInMetersY() / 2);
  
  // 使用额外边界
  useExtraBounds(min_x, min_y, max_x, max_y);

  bool current = true;
  std::vector<Observation> observations, clearing_observations;

  // 获取标记障碍物的观测数据
  current = current && getMarkingObservations(observations);

  // 获取用于清除的观测数据
  current = current && getClearingObservations(clearing_observations);

  // 更新全局状态
  current_ = current;

  // 执行射线追踪清除自由空间
  for (unsigned int i = 0; i < clearing_observations.size(); ++i)
  {
    raytraceFreespace(clearing_observations[i], min_x, min_y, max_x, max_y);
  }

  // 处理障碍物标记
  for (std::vector<Observation>::const_iterator it = observations.begin(); it != observations.end(); ++it)
  {
    const Observation& obs = *it;
    const sensor_msgs::PointCloud2& cloud = *(obs.cloud_);
    double sq_obstacle_range = obs.obstacle_range_ * obs.obstacle_range_;

    // 遍历点云中的每个点
    sensor_msgs::PointCloud2ConstIterator<float> iter_x(cloud, "x");
    sensor_msgs::PointCloud2ConstIterator<float> iter_y(cloud, "y");
    sensor_msgs::PointCloud2ConstIterator<float> iter_z(cloud, "z");

    for (; iter_x != iter_x.end(); ++iter_x, ++iter_y, ++iter_z)
    {
      double px = *iter_x, py = *iter_y, pz = *iter_z;

      // 高度过滤：只处理低于最大高度的障碍物
      if (pz > max_obstacle_height_)
      {
        ROS_DEBUG("The point is too high");
        continue;
      }

      // 距离过滤：只处理 obstacle_range 范围内的点
      double sq_dist = (px - obs.origin_.x) * (px - obs.origin_.x) + 
                       (py - obs.origin_.y) * (py - obs.origin_.y) + 
                       (pz - obs.origin_.z) * (pz - obs.origin_.z);

      if (sq_dist >= sq_obstacle_range)
      {
        ROS_DEBUG("The point is too far away");
        continue;
      }

      // 转换为地图坐标
      unsigned int mx, my;
      if (!worldToMap(px, py, mx, my))
      {
        ROS_DEBUG("Computing map coords failed");
        continue;
      }

      // 标记为致命障碍物
      unsigned int index = getIndex(mx, my);
      costmap_[index] = LETHAL_OBSTACLE;
      
      // 更新边界
      touch(px, py, min_x, min_y, max_x, max_y);
    }
  }

  // 更新机器人足迹
  updateFootprint(robot_x, robot_y, robot_yaw, min_x, min_y, max_x, max_y);
}

/**
 * @brief 更新机器人足迹边界
 * @param robot_x 机器人 X 坐标
 * @param robot_y 机器人 Y 坐标
 * @param robot_yaw 机器人大航向角
 * @param min_x 最小 X 边界
 * @param min_y 最小 Y 边界
 * @param max_x 最大 X 边界
 * @param max_y 最大 Y 边界
 */
void ObstacleLayer::updateFootprint(double robot_x, double robot_y, double robot_yaw, 
                                     double* min_x, double* min_y, double* max_x, double* max_y)
{
  if (!footprint_clearing_enabled_) return;
  
  // 转换足迹到全局坐标系
  transformFootprint(robot_x, robot_y, robot_yaw, getFootprint(), transformed_footprint_);

  // 更新边界
  for (unsigned int i = 0; i < transformed_footprint_.size(); i++)
  {
    touch(transformed_footprint_[i].x, transformed_footprint_[i].y, min_x, min_y, max_x, max_y);
  }
}

/**
 * @brief 将障碍物层代价融合到主代价地图
 * @param master_grid 主代价地图
 * @param min_i 最小网格索引 i
 * @param min_j 最小网格索引 j
 * @param max_i 最大网格索引 i
 * @param max_j 最大网格索引 j
 */
void ObstacleLayer::updateCosts(costmap_2d::Costmap2D& master_grid, int min_i, int min_j, 
                                 int max_i, int max_j)
{
  // 如果启用了足迹清除，将机器人位置标记为自由空间
  if (footprint_clearing_enabled_)
  {
    setConvexPolygonCost(transformed_footprint_, costmap_2d::FREE_SPACE);
  }

  // 根据融合策略更新主代价地图
  switch (combination_method_)
  {
    case 0:  // Overwrite - 直接覆盖
      updateWithOverwrite(master_grid, min_i, min_j, max_i, max_j);
      break;
    case 1:  // Maximum - 取最大值
      updateWithMax(master_grid, min_i, min_j, max_i, max_j);
      break;
    default:  // 不做任何操作
      break;
  }
}

/**
 * @brief 添加静态观测数据
 * @param obs 观测数据
 * @param marking 是否用于标记障碍物
 * @param clearing 是否用于清除自由空间
 */
void ObstacleLayer::addStaticObservation(costmap_2d::Observation& obs, bool marking, bool clearing)
{
  if (marking)
    static_marking_observations_.push_back(obs);
  if (clearing)
    static_clearing_observations_.push_back(obs);
}

/**
 * @brief 清除静态观测数据
 * @param marking 是否清除标记观测
 * @param clearing 是否清除清除观测
 */
void ObstacleLayer::clearStaticObservations(bool marking, bool clearing)
{
  if (marking)
    static_marking_observations_.clear();
  if (clearing)
    static_clearing_observations_.clear();
}

/**
 * @brief 获取用于标记障碍物的观测数据
 * @param marking_observations 输出：观测数据列表
 * @return 当前观测数据是否有效
 */
bool ObstacleLayer::getMarkingObservations(std::vector<Observation>& marking_observations) const
{
  bool current = true;
  
  // 从标记缓冲区获取观测数据
  for (unsigned int i = 0; i < marking_buffers_.size(); ++i)
  {
    marking_buffers_[i]->lock();
    marking_buffers_[i]->getObservations(marking_observations);
    current = marking_buffers_[i]->isCurrent() && current;
    marking_buffers_[i]->unlock();
  }
  
  // 添加静态标记观测数据
  marking_observations.insert(marking_observations.end(),
                              static_marking_observations_.begin(), static_marking_observations_.end());
  
  return current;
}

/**
 * @brief 获取用于清除自由空间的观测数据
 * @param clearing_observations 输出：观测数据列表
 * @return 当前观测数据是否有效
 */
bool ObstacleLayer::getClearingObservations(std::vector<Observation>& clearing_observations) const
{
  bool current = true;
  
  // 从清除缓冲区获取观测数据
  for (unsigned int i = 0; i < clearing_buffers_.size(); ++i)
  {
    clearing_buffers_[i]->lock();
    clearing_buffers_[i]->getObservations(clearing_observations);
    current = clearing_buffers_[i]->isCurrent() && current;
    clearing_buffers_[i]->unlock();
  }
  
  // 添加静态清除观测数据
  clearing_observations.insert(clearing_observations.end(),
                              static_clearing_observations_.begin(), static_clearing_observations_.end());
  
  return current;
}

/**
 * @brief 射线追踪清除自由空间
 * @param clearing_observation 清除观测数据
 * @param min_x 最小 X 边界
 * @param min_y 最小 Y 边界
 * @param max_x 最大 X 边界
 * @param max_y 最大 Y 边界
 * 
 * 使用 Bresenham 算法从传感器原点到每个检测点画射线，
 * 将射线上的栅格标记为自由空间。
 */
void ObstacleLayer::raytraceFreespace(const Observation& clearing_observation, 
                                       double* min_x, double* min_y, double* max_x, double* max_y)
{
  double ox = clearing_observation.origin_.x;  // 传感器原点 X
  double oy = clearing_observation.origin_.y;  // 传感器原点 Y
  const sensor_msgs::PointCloud2 &cloud = *(clearing_observation.cloud_);

  // 将传感器原点转换为地图坐标
  unsigned int x0, y0;
  if (!worldToMap(ox, oy, x0, y0))
  {
    ROS_WARN_THROTTLE(1.0, "The origin for the sensor at (%.2f, %.2f) is out of map bounds. "
                      "So, the costmap cannot raytrace for it.", ox, oy);
    return;
  }

  // 预计算地图边界
  double origin_x = origin_x_, origin_y = origin_y_;
  double map_end_x = origin_x + size_x_ * resolution_;
  double map_end_y = origin_y + size_y_ * resolution_;

  // 更新边界
  touch(ox, oy, min_x, min_y, max_x, max_y);

  // 遍历点云中的每个点
  sensor_msgs::PointCloud2ConstIterator<float> iter_x(cloud, "x");
  sensor_msgs::PointCloud2ConstIterator<float> iter_y(cloud, "y");

  for (; iter_x != iter_x.end(); ++iter_x, ++iter_y)
  {
    double wx = *iter_x;
    double wy = *iter_y;

    // 边界裁剪：确保端点在地图范围内
    double a = wx - ox;
    double b = wy - oy;

    // 处理 X 方向边界
    if (wx < origin_x)
    {
      double t = (origin_x - ox) / a;
      wx = origin_x;
      wy = oy + b * t;
    }
    if (wy < origin_y)
    {
      double t = (origin_y - oy) / b;
      wx = ox + a * t;
      wy = origin_y;
    }

    // 处理 Y 方向边界
    if (wx > map_end_x)
    {
      double t = (map_end_x - ox) / a;
      wx = map_end_x - .001;
      wy = oy + b * t;
    }
    if (wy > map_end_y)
    {
      double t = (map_end_y - oy) / b;
      wx = ox + a * t;
      wy = map_end_y - .001;
    }

    // 将端点转换为地图坐标
    unsigned int x1, y1;
    if (!worldToMap(wx, wy, x1, y1))
      continue;

    // 计算射线追踪范围（栅格数）
    unsigned int cell_raytrace_range = cellDistance(clearing_observation.raytrace_range_);
    
    // 创建标记器：将射线上的栅格标记为自由空间
    MarkCell marker(costmap_, FREE_SPACE);
    
    // 执行射线追踪
    raytraceLine(marker, x0, y0, x1, y1, cell_raytrace_range);

    // 更新边界
    updateRaytraceBounds(ox, oy, wx, wy, clearing_observation.raytrace_range_, 
                         min_x, min_y, max_x, max_y);
  }
}

/**
 * @brief 激活障碍物层
 * 
 * 重新订阅传感器话题并重置观测缓冲区。
 */
void ObstacleLayer::activate()
{
  for (unsigned int i = 0; i < observation_subscribers_.size(); ++i)
  {
    if (observation_subscribers_[i] != NULL)
      observation_subscribers_[i]->subscribe();
  }

  for (unsigned int i = 0; i < observation_buffers_.size(); ++i)
  {
    if (observation_buffers_[i])
      observation_buffers_[i]->resetLastUpdated();
  }
}

/**
 * @brief 停用障碍物层
 * 
 * 取消订阅所有传感器话题。
 */
void ObstacleLayer::deactivate()
{
  for (unsigned int i = 0; i < observation_subscribers_.size(); ++i)
  {
    if (observation_subscribers_[i] != NULL)
      observation_subscribers_[i]->unsubscribe();
  }
}

/**
 * @brief 更新射线追踪边界
 * @param ox 传感器原点 X
 * @param oy 传感器原点 Y
 * @param wx 端点 X
 * @param wy 端点 Y
 * @param range 射线追踪范围
 * @param min_x 最小 X 边界
 * @param min_y 最小 Y 边界
 * @param max_x 最大 X 边界
 * @param max_y 最大 Y 边界
 */
void ObstacleLayer::updateRaytraceBounds(double ox, double oy, double wx, double wy, double range,
                                         double* min_x, double* min_y, double* max_x, double* max_y)
{
  double dx = wx - ox, dy = wy - oy;
  double full_distance = hypot(dx, dy);
  double scale = std::min(1.0, range / full_distance);
  double ex = ox + dx * scale, ey = oy + dy * scale;
  touch(ex, ey, min_x, min_y, max_x, max_y);
}

/**
 * @brief 重置障碍物层
 * 
 * 停用层，重置地图，然后重新激活。
 */
void ObstacleLayer::reset()
{
  deactivate();
  resetMaps();
  current_ = true;
  activate();
}

}  // namespace costmap_2d