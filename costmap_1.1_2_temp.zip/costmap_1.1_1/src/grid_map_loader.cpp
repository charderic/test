/**
 * @file grid_map_loader.cpp
 * @brief 地图加载器实现
 */

#include "costmap_2d/grid_map_loader.h"
#include <cstring>
#include <cstdio>
#include <fstream>
#include <sstream>

namespace grid_map {

// ===== YAML配置加载 =====

void loadMapConfig(const std::string& yaml_file, MapConfig& config) {
    std::ifstream file(yaml_file);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to open YAML file: " + yaml_file);
    }
    
    std::string line;
    while (std::getline(file, line)) {
        // 移除注释
        size_t comment_pos = line.find('#');
        if (comment_pos != std::string::npos) {
            line = line.substr(0, comment_pos);
        }
        
        // 解析键值对
        size_t colon_pos = line.find(':');
        if (colon_pos == std::string::npos) continue;
        
        std::string key = line.substr(0, colon_pos);
        std::string value = line.substr(colon_pos + 1);
        
        // 去除空白字符
        key.erase(0, key.find_first_not_of(" \t"));
        key.erase(key.find_last_not_of(" \t") + 1);
        value.erase(0, value.find_first_not_of(" \t"));
        value.erase(value.find_last_not_of(" \t") + 1);
        
        // 解析配置项
        if (key == "image") {
            // 处理路径：如果是相对路径，转换为绝对路径
            if (value[0] != '/') {
                size_t last_slash = yaml_file.find_last_of('/');
                if (last_slash != std::string::npos) {
                    std::string yaml_dir = yaml_file.substr(0, last_slash + 1);
                    value = yaml_dir + value;
                }
            }
            config.image_file = value;
        } else if (key == "resolution") {
            config.resolution = std::stod(value);
        } else if (key == "origin") {
            // 解析格式: [x, y, yaw]
            size_t start = value.find('[');
            size_t end = value.find(']');
            if (start != std::string::npos && end != std::string::npos) {
                std::string coords = value.substr(start + 1, end - start - 1);
                std::istringstream iss(coords);
                std::string token;
                int idx = 0;
                while (std::getline(iss, token, ',') && idx < 3) {
                    token.erase(0, token.find_first_not_of(" \t"));
                    token.erase(token.find_last_not_of(" \t") + 1);
                    if (idx == 0) config.origin.position.x = std::stod(token);
                    else if (idx == 1) config.origin.position.y = std::stod(token);
                    else if (idx == 2) config.origin.yaw = std::stod(token);
                    idx++;
                }
            }
        } else if (key == "negate") {
            config.negate = (std::stoi(value) != 0);
        } else if (key == "occupied_thresh") {
            config.occupied_thresh = std::stod(value);
        } else if (key == "free_thresh") {
            config.free_thresh = std::stod(value);
        } else if (key == "mode") {
            if (value == "trinary") config.mode = TRINARY;
            else if (value == "scale") config.mode = SCALE;
            else if (value == "raw") config.mode = RAW;
        }
    }
    
    file.close();
    
    // 验证配置
    if (config.image_file.empty()) {
        throw std::runtime_error("Image file not specified in YAML");
    }
    if (config.resolution <= 0.0) {
        throw std::runtime_error("Invalid resolution: " + std::to_string(config.resolution));
    }
}

// ===== 图像加载 =====

void loadMapFromImage(const std::string& image_file, const MapConfig& config, GridMap& map) {
    // 加载图像
    SDL_Surface* img = IMG_Load(image_file.c_str());
    if (!img) {
        throw std::runtime_error("Failed to load image: " + image_file + 
                               " - " + std::string(IMG_GetError()));
    }
    
    // 初始化地图
    MapOrigin origin(config.origin.position.x, config.origin.position.y, config.origin.yaw);
    map.initialize(img->w, img->h, config.resolution, origin);
    
    // 获取图像参数
    int rowstride = img->pitch;
    int n_channels = img->format->BytesPerPixel;
    int avg_channels = (config.mode == TRINARY || !img->format->Amask) ? n_channels : n_channels - 1;
    
    // 遍历像素
    unsigned char* pixels = (unsigned char*)(img->pixels);
    
    for (int y = 0; y < img->h; ++y) {
        for (int x = 0; x < img->w; ++x) {
            // 计算像素指针
            unsigned char* p = pixels + y * rowstride + x * n_channels;
            
            // 计算平均颜色值
            int color_sum = 0;
            for (int k = 0; k < avg_channels; ++k) {
                color_sum += *(p + k);
            }
            double color_avg = color_sum / (double)avg_channels;
            
            // 获取Alpha值
            int alpha = (n_channels == 1) ? 1 : *(p + n_channels - 1);
            
            // 颜色反转
            if (config.negate) {
                color_avg = 255.0 - color_avg;
            }
            
            // 转换为栅格值
            int8_t value;
            
            if (config.mode == RAW) {
                // RAW模式：直接使用原始灰度值
                value = static_cast<int8_t>(color_avg);
            } else {
                // 计算占用概率（白色=自由，黑色=障碍）
                double occ = (255.0 - color_avg) / 255.0;
                
                if (occ > config.occupied_thresh) {
                    value = GridMap::OCCUPIED;
                } else if (occ < config.free_thresh) {
                    value = GridMap::FREE_SPACE;
                } else if (config.mode == TRINARY || alpha < 1.0) {
                    value = GridMap::UNKNOWN;
                } else {
                    // SCALE模式：线性插值
                    double ratio = (occ - config.free_thresh) / (config.occupied_thresh - config.free_thresh);
                    value = static_cast<int8_t>(1 + 98 * ratio);
                }
            }
            
            // 设置栅格值（注意Y坐标反转）
            GridIndex idx(x, img->h - y - 1);
            map.setCell(idx, value);
        }
    }
    
    // 释放图像资源
    SDL_FreeSurface(img);
}

// ===== 完整地图加载 =====

void loadMap(const std::string& yaml_file, GridMap& map) {
    MapConfig config;
    loadMapConfig(yaml_file, config);
    loadMapFromImage(config.image_file, config, map);
}

// ===== 地图保存 =====

void saveMapToPGM(const GridMap& map, const std::string& pgm_file) {
    FILE* file = fopen(pgm_file.c_str(), "wb");
    if (!file) {
        throw std::runtime_error("Failed to open PGM file for writing: " + pgm_file);
    }
    
    // 写入PGM头部
    fprintf(file, "P5\n");
    fprintf(file, "# Created by grid_map\n");
    fprintf(file, "%d %d\n", map.getWidth(), map.getHeight());
    fprintf(file, "255\n");
    
    // 写入像素数据
    for (int y = map.getHeight() - 1; y >= 0; --y) {
        for (int x = 0; x < map.getWidth(); ++x) {
            GridIndex idx(x, y);
            int8_t value = map.getCell(idx);
            
            // 转换为灰度值
            unsigned char gray;
            if (value == GridMap::UNKNOWN) {
                gray = 205;  // 未知区域用灰色表示
            } else if (value >= GridMap::OCCUPIED) {
                gray = 0;    // 障碍物用黑色表示
            } else {
                gray = 254;  // 自由空间用白色表示
            }
            
            fwrite(&gray, 1, 1, file);
        }
    }
    
    fclose(file);
}

void saveMapConfig(const GridMap& map, const std::string& yaml_file) {
    std::ofstream file(yaml_file);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to open YAML file for writing: " + yaml_file);
    }
    
    // 提取基础文件名
    size_t last_slash = yaml_file.find_last_of('/');
    std::string yaml_name = (last_slash != std::string::npos) ? 
                           yaml_file.substr(last_slash + 1) : yaml_file;
    std::string pgm_name = yaml_name.substr(0, yaml_name.find_last_of('.')) + ".pgm";
    
    // 写入YAML配置
    file << "image: " << pgm_name << "\n";
    file << "resolution: " << map.getResolution() << "\n";
    file << "origin: [" << map.getOrigin().position.x << ", " 
         << map.getOrigin().position.y << ", " 
         << map.getOrigin().yaw << "]\n";
    file << "negate: 0\n";
    file << "occupied_thresh: 0.65\n";
    file << "free_thresh: 0.196\n";
    
    file.close();
}

void saveMap(const GridMap& map, const std::string& base_path) {
    std::string pgm_file = base_path + ".pgm";
    std::string yaml_file = base_path + ".yaml";
    
    saveMapToPGM(map, pgm_file);
    saveMapConfig(map, yaml_file);
}

} // namespace grid_map