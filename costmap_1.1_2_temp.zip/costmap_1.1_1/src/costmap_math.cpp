/*
 * Copyright (c) 2013, Willow Garage, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Willow Garage, Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <costmap_2d/costmap_2d.h>
#include <costmap_2d/costmap_math.h>

namespace costmap_2d
{

/**
 * @brief 计算点到线段的最短距离（投影法）
 *
 * 算法原理：
 * 1. 计算测试点到线段起点的向量 AP
 * 2. 计算线段向量 AB
 * 3. 计算 AP 在 AB 上的投影参数 param
 * 4. 根据 param 值判断最近点位置：
 *    - param < 0: 最近点为起点 A
 *    - param > 1: 最近点为终点 B
 *    - 否则: 最近点为投影点
 * 5. 计算并返回测试点到最近点的距离
 *
 * @param pX 测试点的X坐标
 * @param pY 测试点的Y坐标
 * @param x0 线段起点X坐标
 * @param y0 线段起点Y坐标
 * @param x1 线段终点X坐标
 * @param y1 线段终点Y坐标
 * @return 点到线段的最短距离
 */
double distanceToLine(double pX, double pY, double x0, double y0, double x1, double y1)
{
  // 计算向量 AP 和 AB
  double A = pX - x0;
  double B = pY - y0;
  double C = x1 - x0;
  double D = y1 - y0;

  // 计算点积和线段长度的平方
  double dot = A * C + B * D;
  double len_sq = C * C + D * D;
  
  // 计算投影参数 param
  // param = (AP · AB) / |AB|²
  // param 表示投影点在线段上的位置比例
  double param = dot / len_sq;

  // 根据 param 值确定最近点坐标
  double xx, yy;

  if (param < 0)
  {
    // 投影点在线段起点之前，最近点为起点
    xx = x0;
    yy = y0;
  }
  else if (param > 1)
  {
    // 投影点在线段终点之后，最近点为终点
    xx = x1;
    yy = y1;
  }
  else
  {
    // 投影点在线段内部，计算投影点坐标
    xx = x0 + param * C;
    yy = y0 + param * D;
  }

  // 返回测试点到最近点的欧几里得距离
  return distance(pX, pY, xx, yy);
}

/**
 * @brief 点是否在多边形内部（射线法/Ray Casting Algorithm）
 *
 * 算法原理：
 * 1. 从测试点向右发射一条水平射线
 * 2. 遍历多边形的每条边
 * 3. 判断射线与边是否相交
 * 4. 如果交点数为奇数，点在多边形内部；否则在外部
 *
 * 特殊处理：
 * - 边的两个端点分别在射线两侧时才计数
 * - 使用严格不等式避免边界判断问题
 *
 * @param polygon 多边形顶点向量（按顺序排列）
 * @param testx 测试点X坐标
 * @param testy 测试点Y坐标
 * @return true表示点在多边形内部
 */
bool intersects(std::vector<Point>& polygon, float testx, float testy)
{
  bool c = false;  // 交点计数的奇偶性标志
  int i, j, nvert = polygon.size();
  
  // 遍历多边形的每条边（j始终是i的前一个顶点）
  for (i = 0, j = nvert - 1; i < nvert; j = i++)
  {
    // 获取当前边的两个端点坐标
    float yi = polygon[i].y, yj = polygon[j].y;
    float xi = polygon[i].x, xj = polygon[j].x;

    // 判断条件：
    // 1. 边的两个端点分别在射线两侧（(yi > testy) != (yj > testy)）
    // 2. 测试点的X坐标小于交点的X坐标
    if (((yi > testy) != (yj > testy)) && 
        (testx < (xj - xi) * (testy - yi) / (yj - yi) + xi))
      c = !c;  // 翻转奇偶性
  }
  
  return c;
}

/**
 * @brief 辅助函数：检查多边形1的任意顶点是否在多边形2内部
 *
 * @param polygon1 第一个多边形
 * @param polygon2 第二个多边形
 * @return true表示polygon1的至少一个顶点在polygon2内部
 */
bool intersects_helper(std::vector<Point>& polygon1, std::vector<Point>& polygon2)
{
  for (unsigned int i = 0; i < polygon1.size(); i++)
    if (intersects(polygon2, polygon1[i].x, polygon1[i].y))
      return true;
  return false;
}

/**
 * @brief 判断两个多边形是否相交
 *
 * 算法原理：
 * 如果任意一个多边形的至少一个顶点在另一个多边形内部，则认为两多边形相交。
 * 注意：这种判断方法可能遗漏某些边界情况（如边边相交但顶点不在内部），
 * 但对于机器人导航中的碰撞检测已经足够。
 *
 * @param polygon1 第一个多边形
 * @param polygon2 第二个多边形
 * @return true表示两多边形相交
 */
bool intersects(std::vector<Point>& polygon1, std::vector<Point>& polygon2)
{
  // 检查polygon1的顶点是否在polygon2内部，或反之
  return intersects_helper(polygon1, polygon2) || intersects_helper(polygon2, polygon1);
}

}  // namespace costmap_2d
