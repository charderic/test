/**
 * @file layered_costmap_demo.cpp
 * @brief 分层代价地图Demo - 使用LayeredCostmap管理障碍物层和膨胀层
 *
 * 功能：
 * 1. 创建LayeredCostmap，模拟障碍物层和膨胀层的工作流程
 * 2. 订阅激光雷达话题，实时更新代价地图
 * 3. 使用标准Bresenham射线追踪算法
 * 4. 应用指数衰减膨胀算法
 * 5. 实时可视化代价地图
 * 6. 发布局部代价地图话题 /local_costmap
 *
 * 使用方法：
 *   ./layered_costmap_demo [laser_topic]
 */

#include <ros/ros.h>
#include <costmap_2d/layered_costmap.h>
#include <costmap_2d/cost_values.h>
#include <costmap_2d/costmap_math.h>
#include <sensor_msgs/LaserScan.h>
#include <nav_msgs/OccupancyGrid.h>
#include <iostream>
#include <iomanip>
#include <mutex>
#include <cmath>

// 全局变量
std::unique_ptr<costmap_2d::LayeredCostmap> layered_costmap_;
sensor_msgs::LaserScanConstPtr last_scan_;
std::mutex scan_mutex_;
bool has_scan_ = false;

// 发布者
ros::Publisher costmap_pub_;

// 膨胀参数
double inflation_radius_ = 0.5;   // 膨胀半径（米）
double cost_scaling_factor_ = 5.0; // 代价衰减系数

/**
 * @brief 激光扫描回调函数
 */
void laserScanCallback(const sensor_msgs::LaserScanConstPtr& scan)
{
  std::lock_guard<std::mutex> lock(scan_mutex_);
  last_scan_ = scan;
  has_scan_ = true;
  ROS_DEBUG_THROTTLE(1.0, "收到激光扫描: %ld 个点", static_cast<long>(scan->ranges.size()));
}

/**
 * @brief Bresenham射线追踪算法 - 清除自由空间
 */
void raytraceLine(costmap_2d::Costmap2D& costmap, int x0, int y0, int x1, int y1)
{
  int dx = abs(x1 - x0);
  int dy = abs(y1 - y0);
  int sx = (x0 < x1) ? 1 : -1;
  int sy = (y0 < y1) ? 1 : -1;
  int err = dx - dy;
  int x = x0;
  int y = y0;

  while (true)
  {
    if (x >= 0 && x < static_cast<int>(costmap.getSizeInCellsX()) &&
        y >= 0 && y < static_cast<int>(costmap.getSizeInCellsY()))
    {
      costmap.setCost(x, y, costmap_2d::FREE_SPACE);
    }

    if (x == x1 && y == y1) break;

    int e2 = 2 * err;
    if (e2 > -dy)
    {
      err -= dy;
      x += sx;
    }
    if (e2 < dx)
    {
      err += dx;
      y += sy;
    }
  }
}

/**
 * @brief 更新障碍物层 - 处理激光扫描数据
 */
void updateObstacleLayer(costmap_2d::Costmap2D& costmap, const sensor_msgs::LaserScan& scan)
{
  // 机器人位于地图中心
  int robot_cell_x = costmap.getSizeInCellsX() / 2;
  int robot_cell_y = costmap.getSizeInCellsY() / 2;

  // 遍历激光扫描的每个点
  for (size_t i = 0; i < scan.ranges.size(); ++i)
  {
    double range = scan.ranges[i];
    
    // 跳过无效值
    if (std::isnan(range) || std::isinf(range))
      continue;
    
    if (range <= scan.range_min || range >= scan.range_max)
      continue;

    // 计算点的角度和世界坐标
    double angle = scan.angle_min + i * scan.angle_increment;
    double wx = range * cos(angle);
    double wy = range * sin(angle);
    
    // 转换为栅格坐标
    unsigned int cell_x, cell_y;
    if (!costmap.worldToMap(wx, wy, cell_x, cell_y))
      continue;

    // 射线追踪清除自由空间
    raytraceLine(costmap, robot_cell_x, robot_cell_y, cell_x, cell_y);
    
    // 设置障碍物
    costmap.setCost(cell_x, cell_y, costmap_2d::LETHAL_OBSTACLE);
  }
}

/**
 * @brief 膨胀算法 - 对障碍物周围区域添加代价值
 */
void applyInflation(costmap_2d::Costmap2D& costmap)
{
  unsigned int size_x = costmap.getSizeInCellsX();
  unsigned int size_y = costmap.getSizeInCellsY();
  double resolution = costmap.getResolution();
  
  // 计算膨胀半径（栅格数）
  unsigned int inflation_radius_cells = static_cast<unsigned int>(inflation_radius_ / resolution);
  
  // 创建临时地图存储膨胀代价
  std::vector<unsigned char> temp_costs(size_x * size_y);
  memcpy(temp_costs.data(), costmap.getCharMap(), size_x * size_y);

  // 遍历所有栅格
  for (unsigned int i = 0; i < size_x; ++i)
  {
    for (unsigned int j = 0; j < size_y; ++j)
    {
      if (costmap.getCost(i, j) != costmap_2d::LETHAL_OBSTACLE)
        continue;

      // 对障碍物周围进行膨胀
      for (unsigned int dx = 0; dx <= inflation_radius_cells; ++dx)
      {
        for (unsigned int dy = 0; dy <= inflation_radius_cells; ++dy)
        {
          // 检查四个象限
          for (int sx = -1; sx <= 1; sx += 2)
          {
            for (int sy = -1; sy <= 1; sy += 2)
            {
              int nx = i + sx * static_cast<int>(dx);
              int ny = j + sy * static_cast<int>(dy);
              
              if (nx < 0 || nx >= static_cast<int>(size_x) ||
                  ny < 0 || ny >= static_cast<int>(size_y))
                continue;

              // 计算距离（欧几里得距离）
              double distance = sqrt(dx * dx + dy * dy) * resolution;
              
              if (distance > inflation_radius_)
                continue;

              // 计算代价值（指数衰减）
              unsigned char cost = static_cast<unsigned char>(
                  252.0 * exp(-cost_scaling_factor_ * (distance - 0.05)) + 1.0);
              
              // 确保代价值在有效范围内
              cost = std::min(cost, static_cast<unsigned char>(253));
              cost = std::max(cost, static_cast<unsigned char>(1));

              // 如果当前栅格不是障碍物且代价值更高，则更新
              unsigned char current_cost = temp_costs[ny * size_x + nx];
              if (current_cost != costmap_2d::LETHAL_OBSTACLE && cost > current_cost)
              {
                temp_costs[ny * size_x + nx] = cost;
              }
            }
          }
        }
      }
    }
  }

  // 将膨胀结果写回代价地图
  memcpy(costmap.getCharMap(), temp_costs.data(), size_x * size_y);
}

/**
 * @brief 重置代价地图为指定值
 */
void resetCostmapToValue(costmap_2d::Costmap2D& costmap, unsigned char value)
{
  unsigned char* map = costmap.getCharMap();
  for (unsigned int i = 0; i < costmap.getSizeInCellsX() * costmap.getSizeInCellsY(); ++i)
  {
    map[i] = value;
  }
}

/**
 * @brief 将代价地图转换为OccupancyGrid消息
 */
nav_msgs::OccupancyGrid costmapToOccupancyGrid(costmap_2d::Costmap2D& costmap)
{
  nav_msgs::OccupancyGrid grid;
  
  // 设置消息头
  grid.header.stamp = ros::Time::now();
  grid.header.frame_id = "base_link";
  
  // 设置地图元数据
  grid.info.width = costmap.getSizeInCellsX();
  grid.info.height = costmap.getSizeInCellsY();
  grid.info.resolution = costmap.getResolution();
  grid.info.origin.position.x = costmap.getOriginX();
  grid.info.origin.position.y = costmap.getOriginY();
  grid.info.origin.position.z = 0.0;
  grid.info.origin.orientation.w = 1.0;
  
  // 填充数据
  grid.data.resize(grid.info.width * grid.info.height);
  unsigned char* costmap_data = costmap.getCharMap();
  
  for (unsigned int i = 0; i < grid.info.width * grid.info.height; ++i)
  {
    unsigned char cost = costmap_data[i];
    
    // 转换为OccupancyGrid格式：-1=未知, 0=空闲, 100=障碍物
    if (cost == costmap_2d::NO_INFORMATION)
      grid.data[i] = -1;
    else if (cost == costmap_2d::FREE_SPACE)
      grid.data[i] = 0;
    else if (cost == costmap_2d::LETHAL_OBSTACLE)
      grid.data[i] = 100;
    else
    {
      // 膨胀区域，转换为0-99的范围
      grid.data[i] = static_cast<int>(cost * 99.0 / 253.0);
    }
  }
  
  return grid;
}

/**
 * @brief 可视化代价地图
 */
void visualizeCostmap(costmap_2d::Costmap2D* costmap)
{
  if (!costmap) return;

  std::cout << "\n========================================" << std::endl;
  std::cout << "    分层代价地图 (障碍物层 + 膨胀层)" << std::endl;
  std::cout << "========================================" << std::endl;
  std::cout << "尺寸(栅格):  " << costmap->getSizeInCellsX() << " x "
            << costmap->getSizeInCellsY() << std::endl;
  std::cout << "分辨率:      " << costmap->getResolution() << " 米/栅格" << std::endl;
  std::cout << "膨胀半径:    " << inflation_radius_ << " 米" << std::endl;
  std::cout << "代价衰减系数: " << cost_scaling_factor_ << std::endl;
  std::cout << "发布话题:    /local_costmap" << std::endl;

  // 统计信息
  int free_count = 0, lethal_count = 0, inflate_count = 0, no_info_count = 0;

  for (unsigned int i = 0; i < costmap->getSizeInCellsX(); ++i)
  {
    for (unsigned int j = 0; j < costmap->getSizeInCellsY(); ++j)
    {
      unsigned char cost = costmap->getCost(i, j);
      if (cost == costmap_2d::FREE_SPACE)
        free_count++;
      else if (cost == costmap_2d::LETHAL_OBSTACLE)
        lethal_count++;
      else if (cost == costmap_2d::NO_INFORMATION)
        no_info_count++;
      else
        inflate_count++;
    }
  }

  unsigned int total = costmap->getSizeInCellsX() * costmap->getSizeInCellsY();
  std::cout << "----------------------------------------" << std::endl;
  std::cout << "统计信息:" << std::endl;
  std::cout << "  总栅格:     " << total << std::endl;
  std::cout << "  自由空间:   " << free_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * free_count / total) << "%)" << std::endl;
  std::cout << "  障碍物:     " << lethal_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * lethal_count / total) << "%)" << std::endl;
  std::cout << "  膨胀区域:   " << inflate_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * inflate_count / total) << "%)" << std::endl;
  std::cout << "  未知区域:   " << no_info_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * no_info_count / total) << "%)" << std::endl;
  std::cout << "========================================\n" << std::endl;

  // 可视化显示中心区域
  const int display_size = 25;
  int center_x = costmap->getSizeInCellsX() / 2;
  int center_y = costmap->getSizeInCellsY() / 2;
  int start_x = std::max(0, center_x - display_size / 2);
  int start_y = std::max(0, center_y - display_size / 2);

  std::cout << "可视化 (中心 " << display_size << "x" << display_size << " 区域):" << std::endl;
  std::cout << "机器人位置: [中心]" << std::endl;
  std::cout << std::endl;

  // 绘制网格
  for (int j = start_y + display_size - 1; j >= start_y; --j)
  {
    std::cout << "  ";
    for (int i = start_x; i < start_x + display_size; ++i)
    {
      if (i >= (int)costmap->getSizeInCellsX() || j >= (int)costmap->getSizeInCellsY())
      {
        std::cout << "  ";
        continue;
      }

      unsigned char cost = costmap->getCost(i, j);
      bool is_center = (i == center_x && j == center_y);
      
      if (is_center)
        std::cout << " R";
      else if (cost == costmap_2d::FREE_SPACE)
        std::cout << "  ";
      else if (cost == costmap_2d::LETHAL_OBSTACLE)
        std::cout << " X";
      else if (cost == costmap_2d::NO_INFORMATION)
        std::cout << " ?";
      else if (cost >= 200)
        std::cout << " #";
      else if (cost >= 100)
        std::cout << " +";
      else
        std::cout << " .";
    }
    std::cout << std::endl;
  }

  std::cout << "\n图例:" << std::endl;
  std::cout << "  R = 机器人位置" << std::endl;
  std::cout << "  X = 障碍物 (" << (int)costmap_2d::LETHAL_OBSTACLE << ")" << std::endl;
  std::cout << "  # = 高代价膨胀区域 (200+)" << std::endl;
  std::cout << "  + = 中代价膨胀区域 (100-199)" << std::endl;
  std::cout << "  . = 低代价膨胀区域 (1-99)" << std::endl;
  std::cout << "  ? = 未知区域 (" << (int)costmap_2d::NO_INFORMATION << ")" << std::endl;
  std::cout << "     = 自由空间 (0)" << std::endl;
  std::cout << "========================================\n" << std::endl;
}

int main(int argc, char** argv)
{
  ros::init(argc, argv, "layered_costmap_demo");
  ros::NodeHandle nh;

  std::string laser_topic = "/scan";
  if (argc > 1)
    laser_topic = argv[1];
  ROS_INFO("订阅激光雷达话题: %s", laser_topic.c_str());

  ros::Subscriber scan_sub = nh.subscribe(laser_topic, 10, laserScanCallback);

  // 创建代价地图发布者
  costmap_pub_ = nh.advertise<nav_msgs::OccupancyGrid>("/local_costmap", 10);
  ROS_INFO("发布局部代价地图话题: /local_costmap");

  // 等待第一个激光扫描消息
  ROS_INFO("等待激光雷达数据...");
  ros::Rate wait_rate(10);
  while (ros::ok() && !has_scan_)
  {
    ros::spinOnce();
    wait_rate.sleep();
  }

  if (!ros::ok())
  {
    ROS_ERROR("节点被终止");
    return -1;
  }

  ROS_INFO("收到激光数据!");

  // ===== 创建LayeredCostmap =====
  double map_width = 5.0;
  double map_height = 5.0;
  double resolution = 0.05;
  
  layered_costmap_.reset(new costmap_2d::LayeredCostmap("base_link", true, true));
  
  layered_costmap_->resizeMap(
      static_cast<unsigned int>(map_width / resolution),
      static_cast<unsigned int>(map_height / resolution),
      resolution,
      -map_width / 2.0,
      -map_height / 2.0
  );

  // 获取底层代价地图
  costmap_2d::Costmap2D* costmap = layered_costmap_->getCostmap();
  resetCostmapToValue(*costmap, costmap_2d::NO_INFORMATION);

  // ===== 实时更新和显示代价地图 =====
  ROS_INFO("\n开始实时更新分层代价地图...");
  ROS_INFO("按 Ctrl+C 退出\n");

  ros::Rate update_rate(10);
  int update_count = 0;

  while (ros::ok())
  {
    ros::spinOnce();

    if (update_count % 5 == 0)
    {
      // 重置地图
      resetCostmapToValue(*costmap, costmap_2d::NO_INFORMATION);
      
      // 更新障碍物层
      if (has_scan_)
      {
        std::lock_guard<std::mutex> lock(scan_mutex_);
        updateObstacleLayer(*costmap, *last_scan_);
      }
      
      // 应用膨胀层
      applyInflation(*costmap);
      
      // 发布代价地图
      nav_msgs::OccupancyGrid grid_msg = costmapToOccupancyGrid(*costmap);
      costmap_pub_.publish(grid_msg);
      
      // 清屏并显示
      std::cout << "\033[2J\033[H";
      visualizeCostmap(costmap);
    }

    update_count++;
    update_rate.sleep();
  }

  ROS_INFO("退出demo");
  return 0;
}