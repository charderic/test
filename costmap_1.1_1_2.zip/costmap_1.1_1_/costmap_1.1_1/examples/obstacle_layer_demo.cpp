/**
 * @file obstacle_layer_demo.cpp
 * @brief 障碍物层实时测试Demo - 接收LaserScan，生成动态障碍物层
 *
 * 功能：
 * 1. 订阅激光雷达话题（默认 /scan）
 * 2. 创建简单的代价地图并实时更新障碍物
 * 3. 使用射线追踪清除自由空间
 * 4. 可视化显示局部代价地图
 *
 * 使用方法：
 *   ./obstacle_layer_demo [laser_topic]
 *
 * 依赖：
 *   - ROS (用于接收LaserScan消息)
 *   - costmap_2d 库
 */

#include <ros/ros.h>
#include <costmap_2d/costmap_2d.h>
#include <costmap_2d/cost_values.h>
#include <sensor_msgs/LaserScan.h>
#include <iostream>
#include <iomanip>
#include <mutex>
#include <cmath>

// 全局变量
std::unique_ptr<costmap_2d::Costmap2D> costmap_;
sensor_msgs::LaserScanConstPtr last_scan_;
std::mutex scan_mutex_;
bool has_scan_ = false;

/**
 * @brief 激光扫描回调函数
 */
void laserScanCallback(const sensor_msgs::LaserScanConstPtr& scan)
{
  std::lock_guard<std::mutex> lock(scan_mutex_);
  last_scan_ = scan;
  has_scan_ = true;
  ROS_DEBUG_THROTTLE(1.0, "收到激光扫描: %ld 个点", static_cast<long>(scan->ranges.size()));
}

/**
 * @brief Bresenham射线追踪算法 - 清除自由空间
 */
void raytraceLine(costmap_2d::Costmap2D& costmap, int x0, int y0, int x1, int y1)
{
  int dx = abs(x1 - x0);
  int dy = abs(y1 - y0);
  int sx = (x0 < x1) ? 1 : -1;
  int sy = (y0 < y1) ? 1 : -1;
  int err = dx - dy;
  int x = x0;
  int y = y0;

  while (true)
  {
    // 设置为自由空间
    if (x >= 0 && x < static_cast<int>(costmap.getSizeInCellsX()) &&
        y >= 0 && y < static_cast<int>(costmap.getSizeInCellsY()))
    {
      costmap.setCost(x, y, costmap_2d::FREE_SPACE);
    }

    if (x == x1 && y == y1) break;

    int e2 = 2 * err;
    if (e2 > -dy)
    {
      err -= dy;
      x += sx;
    }
    if (e2 < dx)
    {
      err += dx;
      y += sy;
    }
  }
}

/**
 * @brief 更新代价地图 - 处理激光扫描数据
 */
void updateCostmapFromLaserScan(costmap_2d::Costmap2D& costmap, const sensor_msgs::LaserScan& scan)
{
  double resolution = costmap.getResolution();
  double origin_x = costmap.getOriginX();
  double origin_y = costmap.getOriginY();
  
  // 机器人位于地图中心
  double robot_x = 0.0;
  double robot_y = 0.0;
  
  // 将机器人位置转换为栅格坐标
  int robot_cell_x = costmap.getSizeInCellsX() / 2;
  int robot_cell_y = costmap.getSizeInCellsY() / 2;

  // 遍历激光扫描的每个点
  for (size_t i = 0; i < scan.ranges.size(); ++i)
  {
    double range = scan.ranges[i];
    
    // 跳过无效值
    if (std::isnan(range) || std::isinf(range))
      continue;
    
    // 跳过超出范围的值
    if (range <= scan.range_min || range >= scan.range_max)
      continue;

    // 计算点的角度
    double angle = scan.angle_min + i * scan.angle_increment;
    
    // 计算点的世界坐标（相对于机器人）
    double wx = robot_x + range * cos(angle);
    double wy = robot_y + range * sin(angle);
    
    // 将世界坐标转换为栅格坐标
    unsigned int cell_x, cell_y;
    if (!costmap.worldToMap(wx, wy, cell_x, cell_y))
      continue;
    
    // 检查是否在地图范围内
    if (cell_x >= costmap.getSizeInCellsX() || cell_y >= costmap.getSizeInCellsY())
      continue;

    // 从机器人位置到障碍物位置进行射线追踪，清除自由空间
    raytraceLine(costmap, robot_cell_x, robot_cell_y, cell_x, cell_y);
    
    // 在障碍物位置设置致命障碍物代价
    costmap.setCost(cell_x, cell_y, costmap_2d::LETHAL_OBSTACLE);
  }
}

/**
 * @brief 重置代价地图为指定值
 */
void resetCostmapToValue(costmap_2d::Costmap2D& costmap, unsigned char value)
{
  unsigned char* map = costmap.getCharMap();
  for (unsigned int i = 0; i < costmap.getSizeInCellsX() * costmap.getSizeInCellsY(); ++i)
  {
    map[i] = value;
  }
}

/**
 * @brief 可视化代价地图
 */
void visualizeCostmap(costmap_2d::Costmap2D* costmap)
{
  if (!costmap) return;

  // 显示基本信息
  std::cout << "\n========================================" << std::endl;
  std::cout << "        障碍物层代价地图" << std::endl;
  std::cout << "========================================" << std::endl;
  std::cout << "尺寸(栅格):  " << costmap->getSizeInCellsX() << " x "
            << costmap->getSizeInCellsY() << std::endl;
  std::cout << "分辨率:      " << costmap->getResolution() << " 米/栅格" << std::endl;
  std::cout << "原点:        [" << costmap->getOriginX() << ", "
            << costmap->getOriginY() << "]" << std::endl;
  std::cout << "尺寸(米):    " << costmap->getSizeInMetersX() << " x "
            << costmap->getSizeInMetersY() << " 米" << std::endl;

  // 统计信息
  int free_count = 0;
  int lethal_count = 0;
  int no_info_count = 0;

  for (unsigned int i = 0; i < costmap->getSizeInCellsX(); ++i)
  {
    for (unsigned int j = 0; j < costmap->getSizeInCellsY(); ++j)
    {
      unsigned char cost = costmap->getCost(i, j);
      if (cost == costmap_2d::FREE_SPACE)
        free_count++;
      else if (cost == costmap_2d::LETHAL_OBSTACLE)
        lethal_count++;
      else if (cost == costmap_2d::NO_INFORMATION)
        no_info_count++;
    }
  }

  unsigned int total = costmap->getSizeInCellsX() * costmap->getSizeInCellsY();
  std::cout << "----------------------------------------" << std::endl;
  std::cout << "统计信息:" << std::endl;
  std::cout << "  总栅格:     " << total << std::endl;
  std::cout << "  自由空间:   " << free_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * free_count / total) << "%)" << std::endl;
  std::cout << "  障碍物:     " << lethal_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * lethal_count / total) << "%)" << std::endl;
  std::cout << "  未知区域:   " << no_info_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * no_info_count / total) << "%)" << std::endl;
  std::cout << "========================================\n" << std::endl;

  // 可视化显示中心区域
  const int display_size = 20;
  int center_x = costmap->getSizeInCellsX() / 2;
  int center_y = costmap->getSizeInCellsY() / 2;
  int start_x = std::max(0, center_x - display_size / 2);
  int start_y = std::max(0, center_y - display_size / 2);

  std::cout << "可视化 (中心 " << display_size << "x" << display_size << " 区域):" << std::endl;
  std::cout << "机器人位置: [中心]" << std::endl;
  std::cout << std::endl;

  // 绘制网格
  for (int j = start_y + display_size - 1; j >= start_y; --j)
  {
    std::cout << "  ";
    for (int i = start_x; i < start_x + display_size; ++i)
    {
      if (i >= (int)costmap->getSizeInCellsX() || j >= (int)costmap->getSizeInCellsY())
      {
        std::cout << "  ";
        continue;
      }

      unsigned char cost = costmap->getCost(i, j);
      
      // 判断是否是中心位置（机器人位置）
      bool is_center = (i == center_x && j == center_y);
      
      if (is_center)
        std::cout << " R";  // 机器人位置
      else if (cost == costmap_2d::FREE_SPACE)
        std::cout << "  ";   // 自由空间
      else if (cost == costmap_2d::LETHAL_OBSTACLE)
        std::cout << " X";   // 障碍物
      else if (cost == costmap_2d::NO_INFORMATION)
        std::cout << " ?";   // 未知区域
      else
        std::cout << " .";   // 其他代价
    }
    std::cout << std::endl;
  }

  std::cout << "\n图例:" << std::endl;
  std::cout << "  R = 机器人位置" << std::endl;
  std::cout << "  X = 障碍物 (" << (int)costmap_2d::LETHAL_OBSTACLE << ")" << std::endl;
  std::cout << "  ? = 未知区域 (" << (int)costmap_2d::NO_INFORMATION << ")" << std::endl;
  std::cout << "     = 自由空间 (0)" << std::endl;
  std::cout << "========================================\n" << std::endl;
}

int main(int argc, char** argv)
{
  // 初始化ROS节点
  ros::init(argc, argv, "obstacle_layer_demo");
  ros::NodeHandle nh;

  // 获取激光话题参数
  std::string laser_topic = "/scan";
  if (argc > 1)
  {
    laser_topic = argv[1];
  }
  ROS_INFO("订阅激光雷达话题: %s", laser_topic.c_str());

  // 订阅激光扫描
  ros::Subscriber scan_sub = nh.subscribe(laser_topic, 10, laserScanCallback);

  // 等待第一个激光扫描消息
  ROS_INFO("等待激光雷达数据...");
  ros::Rate wait_rate(10);
  while (ros::ok() && !has_scan_)
  {
    ros::spinOnce();
    wait_rate.sleep();
  }

  if (!ros::ok())
  {
    ROS_ERROR("节点被终止");
    return -1;
  }

  ROS_INFO("收到激光数据!");

  // ===== 创建代价地图 =====
  double map_width = 5.0;   // 5米宽
  double map_height = 5.0;  // 5米高
  double resolution = 0.05; // 5厘米分辨率
  
  costmap_.reset(new costmap_2d::Costmap2D(
      static_cast<unsigned int>(map_width / resolution),
      static_cast<unsigned int>(map_height / resolution),
      resolution,
      -map_width / 2.0,  // 原点X（使机器人在中心）
      -map_height / 2.0   // 原点Y
  ));
  
  // 初始化所有栅格为未知区域
  resetCostmapToValue(*costmap_, costmap_2d::NO_INFORMATION);

  // ===== 实时更新和显示代价地图 =====
  ROS_INFO("\n开始实时更新障碍物层...");
  ROS_INFO("按 Ctrl+C 退出\n");

  ros::Rate update_rate(10);  // 10Hz 更新频率
  int update_count = 0;

  while (ros::ok())
  {
    // 处理回调
    ros::spinOnce();

    // 每5次更新显示一次（每0.5秒）
    if (update_count % 5 == 0)
    {
      // 重置地图为未知区域
      resetCostmapToValue(*costmap_, costmap_2d::NO_INFORMATION);
      
      // 如果有新的激光数据，更新代价地图
      if (has_scan_)
      {
        std::lock_guard<std::mutex> lock(scan_mutex_);
        updateCostmapFromLaserScan(*costmap_, *last_scan_);
      }
      
      // 清屏并显示
      std::cout << "\033[2J\033[H";  // ANSI清屏指令
      visualizeCostmap(costmap_.get());
    }

    update_count++;
    update_rate.sleep();
  }

  ROS_INFO("退出demo");
  return 0;
}