/**
 * @file full_local_costmap_demo.cpp
 * @brief 完整局部代价地图Demo - 使用LayeredCostmap管理ObstacleLayer和InflationLayer插件
 *
 * 功能：
 * 1. 创建LayeredCostmap，加载ObstacleLayer和InflationLayer插件
 * 2. 订阅激光雷达话题，实时更新障碍物层
 * 3. 应用膨胀算法处理障碍物
 * 4. 实时可视化代价地图
 *
 * 使用方法：
 *   1. 设置ROS参数
 *   2. 运行demo
 * 
 * 依赖：
 *   - ROS
 *   - costmap_2d
 *   - pluginlib
 */

#include <ros/ros.h>
#include <costmap_2d/layered_costmap.h>
#include <costmap_2d/cost_values.h>
#include <sensor_msgs/LaserScan.h>
#include <pluginlib/class_loader.hpp>
#include <tf2_ros/transform_listener.h>
#include <tf2_ros/buffer.h>
#include <iostream>
#include <iomanip>
#include <mutex>

// 全局变量
std::unique_ptr<costmap_2d::LayeredCostmap> layered_costmap_;
std::unique_ptr<tf2_ros::Buffer> tf_buffer_;
std::unique_ptr<tf2_ros::TransformListener> tf_listener_;
sensor_msgs::LaserScanConstPtr last_scan_;
std::mutex scan_mutex_;
bool has_scan_ = false;

/**
 * @brief 激光扫描回调函数
 */
void laserScanCallback(const sensor_msgs::LaserScanConstPtr& scan)
{
  std::lock_guard<std::mutex> lock(scan_mutex_);
  last_scan_ = scan;
  has_scan_ = true;
  ROS_DEBUG_THROTTLE(1.0, "收到激光扫描: %ld 个点", static_cast<long>(scan->ranges.size()));
}

/**
 * @brief 可视化代价地图
 */
void visualizeCostmap(costmap_2d::Costmap2D* costmap)
{
  if (!costmap) return;

  std::cout << "\n========================================" << std::endl;
  std::cout << "    完整局部代价地图 (ObstacleLayer + InflationLayer)" << std::endl;
  std::cout << "========================================" << std::endl;
  std::cout << "尺寸(栅格):  " << costmap->getSizeInCellsX() << " x "
            << costmap->getSizeInCellsY() << std::endl;
  std::cout << "分辨率:      " << costmap->getResolution() << " 米/栅格" << std::endl;
  std::cout << "原点:        [" << costmap->getOriginX() << ", "
            << costmap->getOriginY() << "]" << std::endl;

  // 统计信息
  int free_count = 0, lethal_count = 0, inflate_count = 0, no_info_count = 0;

  for (unsigned int i = 0; i < costmap->getSizeInCellsX(); ++i)
  {
    for (unsigned int j = 0; j < costmap->getSizeInCellsY(); ++j)
    {
      unsigned char cost = costmap->getCost(i, j);
      if (cost == costmap_2d::FREE_SPACE)
        free_count++;
      else if (cost == costmap_2d::LETHAL_OBSTACLE)
        lethal_count++;
      else if (cost == costmap_2d::NO_INFORMATION)
        no_info_count++;
      else
        inflate_count++;
    }
  }

  unsigned int total = costmap->getSizeInCellsX() * costmap->getSizeInCellsY();
  std::cout << "----------------------------------------" << std::endl;
  std::cout << "统计信息:" << std::endl;
  std::cout << "  总栅格:     " << total << std::endl;
  std::cout << "  自由空间:   " << free_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * free_count / total) << "%)" << std::endl;
  std::cout << "  障碍物:     " << lethal_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * lethal_count / total) << "%)" << std::endl;
  std::cout << "  膨胀区域:   " << inflate_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * inflate_count / total) << "%)" << std::endl;
  std::cout << "  未知区域:   " << no_info_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * no_info_count / total) << "%)" << std::endl;
  std::cout << "========================================\n" << std::endl;

  // 可视化显示中心区域
  const int display_size = 25;
  int center_x = costmap->getSizeInCellsX() / 2;
  int center_y = costmap->getSizeInCellsY() / 2;
  int start_x = std::max(0, center_x - display_size / 2);
  int start_y = std::max(0, center_y - display_size / 2);

  std::cout << "可视化 (中心 " << display_size << "x" << display_size << " 区域):" << std::endl;
  std::cout << "机器人位置: [中心]" << std::endl;
  std::cout << std::endl;

  // 绘制网格
  for (int j = start_y + display_size - 1; j >= start_y; --j)
  {
    std::cout << "  ";
    for (int i = start_x; i < start_x + display_size; ++i)
    {
      if (i >= (int)costmap->getSizeInCellsX() || j >= (int)costmap->getSizeInCellsY())
      {
        std::cout << "  ";
        continue;
      }

      unsigned char cost = costmap->getCost(i, j);
      bool is_center = (i == center_x && j == center_y);
      
      if (is_center)
        std::cout << " R";
      else if (cost == costmap_2d::FREE_SPACE)
        std::cout << "  ";
      else if (cost == costmap_2d::LETHAL_OBSTACLE)
        std::cout << " X";
      else if (cost == costmap_2d::NO_INFORMATION)
        std::cout << " ?";
      else if (cost >= 200)
        std::cout << " #";
      else if (cost >= 100)
        std::cout << " +";
      else
        std::cout << " .";
    }
    std::cout << std::endl;
  }

  std::cout << "\n图例:" << std::endl;
  std::cout << "  R = 机器人位置" << std::endl;
  std::cout << "  X = 障碍物 (" << (int)costmap_2d::LETHAL_OBSTACLE << ")" << std::endl;
  std::cout << "  # = 高代价膨胀区域 (200+)" << std::endl;
  std::cout << "  + = 中代价膨胀区域 (100-199)" << std::endl;
  std::cout << "  . = 低代价膨胀区域 (1-99)" << std::endl;
  std::cout << "  ? = 未知区域 (" << (int)costmap_2d::NO_INFORMATION << ")" << std::endl;
  std::cout << "     = 自由空间 (0)" << std::endl;
  std::cout << "========================================\n" << std::endl;
}

int main(int argc, char** argv)
{
  ros::init(argc, argv, "full_local_costmap_demo");
  ros::NodeHandle nh("~");

  // 创建TF缓冲区和监听器
  tf_buffer_.reset(new tf2_ros::Buffer());
  tf_listener_.reset(new tf2_ros::TransformListener(*tf_buffer_));

  // ===== 创建LayeredCostmap =====
  double map_width = 5.0;
  double map_height = 5.0;
  double resolution = 0.05;
  
  layered_costmap_.reset(new costmap_2d::LayeredCostmap("odom", true, true));
  
  layered_costmap_->resizeMap(
      static_cast<unsigned int>(map_width / resolution),
      static_cast<unsigned int>(map_height / resolution),
      resolution,
      -map_width / 2.0,
      -map_height / 2.0
  );

  // ===== 加载ObstacleLayer插件 =====
  pluginlib::ClassLoader<costmap_2d::Layer> layer_loader("costmap_2d", "costmap_2d::Layer");
  
  try
  {
    // 加载障碍物层
    boost::shared_ptr<costmap_2d::Layer> obstacle_layer = 
        layer_loader.createInstance("costmap_2d::ObstacleLayer");
    
    // 设置障碍物层参数
    nh.setParam("obstacle_layer/observation_sources", std::string("scan"));
    nh.setParam("obstacle_layer/scan/topic", std::string("/scan"));
    nh.setParam("obstacle_layer/scan/sensor_frame", std::string(""));
    nh.setParam("obstacle_layer/scan/observation_persistence", 0.0);
    nh.setParam("obstacle_layer/scan/expected_update_rate", 0.0);
    nh.setParam("obstacle_layer/scan/data_type", std::string("LaserScan"));
    nh.setParam("obstacle_layer/scan/min_obstacle_height", 0.0);
    nh.setParam("obstacle_layer/scan/max_obstacle_height", 2.0);
    nh.setParam("obstacle_layer/scan/inf_is_valid", false);
    nh.setParam("obstacle_layer/scan/clearing", true);
    nh.setParam("obstacle_layer/scan/marking", true);
    nh.setParam("obstacle_layer/scan/obstacle_range", 2.5);
    nh.setParam("obstacle_layer/scan/raytrace_range", 3.0);
    
    // 初始化障碍物层
    obstacle_layer->initialize(layered_costmap_.get(), tf_buffer_.get(), "obstacle_layer");
    layered_costmap_->addLayer(obstacle_layer);
    
    ROS_INFO("成功加载 ObstacleLayer");
  }
  catch (pluginlib::PluginlibException& ex)
  {
    ROS_ERROR("加载 ObstacleLayer 失败: %s", ex.what());
    return -1;
  }

  // ===== 加载InflationLayer插件 =====
  try
  {
    // 加载膨胀层
    boost::shared_ptr<costmap_2d::Layer> inflation_layer = 
        layer_loader.createInstance("costmap_2d::InflationLayer");
    
    // 设置膨胀层参数
    nh.setParam("inflation_layer/inflation_radius", 0.5);  // 0.5米膨胀半径
    nh.setParam("inflation_layer/cost_scaling_factor", 5.0);  // 代价衰减系数
    
    // 初始化膨胀层
    inflation_layer->initialize(layered_costmap_.get(), tf_buffer_.get(), "inflation_layer");
    layered_costmap_->addLayer(inflation_layer);
    
    ROS_INFO("成功加载 InflationLayer");
  }
  catch (pluginlib::PluginlibException& ex)
  {
    ROS_ERROR("加载 InflationLayer 失败: %s", ex.what());
    return -1;
  }

  // 获取底层代价地图
  costmap_2d::Costmap2D* costmap = layered_costmap_->getCostmap();

  // ===== 订阅激光雷达 =====
  ros::Subscriber scan_sub = nh.subscribe("/scan", 10, laserScanCallback);
  
  ROS_INFO("订阅激光雷达话题: /scan");
  ROS_INFO("等待激光雷达数据...");

  // 等待第一个激光扫描消息
  ros::Rate wait_rate(10);
  while (ros::ok() && !has_scan_)
  {
    ros::spinOnce();
    wait_rate.sleep();
  }

  if (!ros::ok())
  {
    ROS_ERROR("节点被终止");
    return -1;
  }

  ROS_INFO("收到激光数据!");

  // ===== 实时更新和显示代价地图 =====
  ROS_INFO("\n开始实时更新局部代价地图...");
  ROS_INFO("按 Ctrl+C 退出\n");

  ros::Rate update_rate(10);
  int update_count = 0;

  while (ros::ok())
  {
    ros::spinOnce();

    if (update_count % 5 == 0)
    {
      // 更新代价地图
      layered_costmap_->updateMap(0.0, 0.0, 0.0);
      
      // 清屏并显示
      std::cout << "\033[2J\033[H";
      visualizeCostmap(costmap);
    }

    update_count++;
    update_rate.sleep();
  }

  ROS_INFO("退出demo");
  return 0;
}