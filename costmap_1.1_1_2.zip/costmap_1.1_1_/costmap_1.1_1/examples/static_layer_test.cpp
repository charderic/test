/**
 * @file static_layer_test.cpp
 * @brief 简化测试：直接加载地图文件测试 StaticLayer + InflationLayer
 */

#include <costmap_2d/static_layer1.h>
#include <costmap_2d/inflation_layer.h>
#include <costmap_2d/layered_costmap.h>
#include <boost/shared_ptr.hpp>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cmath>

namespace costmap_2d
{

class PGMMapLoader
{
public:
  static OccupancyGridData loadFromPGM(const std::string& pgm_path, 
                                        double resolution, 
                                        double origin_x, 
                                        double origin_y)
  {
    OccupancyGridData grid;
    std::ifstream file(pgm_path.c_str(), std::ios::binary);
    
    if (!file.is_open())
    {
      std::cerr << "[PGMMapLoader] 无法打开 PGM 文件: " << pgm_path << std::endl;
      return grid;
    }
    
    std::string line;
    int width = 0, height = 0;
    bool header_done = false;
    std::vector<unsigned char> raw_data;
    
    while (std::getline(file, line))
    {
      size_t comment_pos = line.find('#');
      if (comment_pos != std::string::npos)
        line = line.substr(0, comment_pos);
      
      std::istringstream iss(line);
      
      if (!header_done)
      {
        std::string magic;
        iss >> magic;
        if (magic == "P5" || magic == "P2")
        {
          header_done = true;
        }
      }
      else if (width == 0)
      {
        iss >> width >> height;
      }
      else
      {
        int max_val;
        iss >> max_val;
        
        if (width > 0 && height > 0)
        {
          raw_data.resize(width * height);
          file.read(reinterpret_cast<char*>(raw_data.data()), width * height);
          
          if (file.gcount() != width * height)
          {
            file.clear();
            file.seekg(std::streamoff(0), std::ios::beg);
            
            int line_count = 0;
            while (line_count < 3 && std::getline(file, line))
            {
              line_count++;
            }
            
            raw_data.clear();
            for (int i = 0; i < width * height; ++i)
            {
              int val;
              file >> val;
              raw_data.push_back(static_cast<unsigned char>(val));
            }
          }
          break;
        }
      }
    }
    
    file.close();
    
    if (raw_data.empty())
    {
      std::cerr << "[PGMMapLoader] PGM 数据为空" << std::endl;
      return grid;
    }
    
    grid.setGridInfo(width, height, resolution, origin_x, origin_y);
    grid.setFrameId("map");
    
    // 转换值
    for (size_t i = 0; i < raw_data.size(); ++i)
    {
      int val = raw_data[i];
      if (val > 200)
        grid[i] = 0;
      else if (val < 50)
        grid[i] = 100;
      else
        grid[i] = -1;
    }
    
    return grid;
  }
  
  static OccupancyGridData loadFromYaml(const std::string& yaml_path)
  {
    OccupancyGridData grid;
    std::ifstream file(yaml_path.c_str());
    
    if (!file.is_open())
    {
      std::cerr << "[PGMMapLoader] 无法打开 YAML 文件: " << yaml_path << std::endl;
      return grid;
    }
    
    std::string line;
    std::string image_path;
    double resolution = 0.05;
    double origin_x = 0.0, origin_y = 0.0;
    
    while (std::getline(file, line))
    {
      while (!line.empty() && (line[0] == ' ' || line[0] == '\t'))
        line.erase(line.begin());
      
      if (line.empty() || line[0] == '#')
        continue;
      
      if (line.find("image:") != std::string::npos)
      {
        size_t pos = line.find(":");
        image_path = line.substr(pos + 1);
        while (!image_path.empty() && (image_path[0] == '"' || image_path[0] == ' '))
          image_path.erase(image_path.begin());
        while (!image_path.empty() && (image_path.back() == '"' || image_path.back() == ' '))
          image_path.pop_back();
      }
      else if (line.find("resolution:") != std::string::npos)
      {
        size_t pos = line.find(":");
        resolution = std::atof(line.substr(pos + 1).c_str());
      }
      else if (line.find("origin:") != std::string::npos)
      {
        std::getline(file, line);
        std::istringstream iss(line);
        std::string val;
        std::vector<double> values;
        while (std::getline(iss, val, ','))
        {
          while (!val.empty() && (val[0] == ' ' || val[0] == '[' || val[0] == ']'))
            val.erase(val.begin());
          while (!val.empty() && (val.back() == ' ' || val.back() == ']'))
            val.pop_back();
          if (!val.empty())
            values.push_back(std::atof(val.c_str()));
        }
        if (values.size() >= 2)
        {
          origin_x = values[0];
          origin_y = values[1];
        }
      }
    }
    
    file.close();
    
    if (!image_path.empty())
    {
      size_t pos = yaml_path.find_last_of('/');
      if (pos != std::string::npos && image_path[0] != '/')
      {
        image_path = yaml_path.substr(0, pos + 1) + image_path;
      }
      
      grid = loadFromPGM(image_path, resolution, origin_x, origin_y);
    }
    
    return grid;
  }
};

}  // namespace costmap_2d

int main(int argc, char** argv)
{
  std::string map_path = "/home/zy/cosmap/costmap_1.1_1_/costmap_1.1_1/maps/hospital_map.yaml";
  
  if (argc > 1)
    map_path = argv[1];
  
  std::cout << "========================================" << std::endl;
  std::cout << "  StaticLayer + InflationLayer 测试" << std::endl;
  std::cout << "========================================" << std::endl;
  std::cout << "地图文件: " << map_path << std::endl;
  std::cout << "========================================\n" << std::endl;
  
  // 加载地图
  std::cout << "[Test] 加载地图..." << std::endl;
  costmap_2d::OccupancyGridData grid = costmap_2d::PGMMapLoader::loadFromYaml(map_path);
  
  if (!grid.isValid())
  {
    std::cerr << "[Test] 错误：地图加载失败" << std::endl;
    return 1;
  }
  
  std::cout << "[Test] 地图加载成功: " << grid.getWidth() << "x" << grid.getHeight() 
            << " @ " << grid.getResolution() << " m/pix" << std::endl;
  std::cout << "[Test] 栅格总数: " << grid.size() << std::endl;
  
  // 统计原始地图数据
  int free_count = 0, obs_count = 0, unknown_count = 0;
  for (size_t i = 0; i < grid.size(); ++i)
  {
    if (grid[i] == 0) free_count++;
    else if (grid[i] == 100) obs_count++;
    else unknown_count++;
  }
  std::cout << "[Test] 原始地图统计:" << std::endl;
  std::cout << "  自由空间: " << free_count << std::endl;
  std::cout << "  障碍物: " << obs_count << std::endl;
  std::cout << "  未知: " << unknown_count << std::endl;
  
  // 创建分层代价地图
  std::cout << "\n[Test] 创建分层代价地图..." << std::endl;
  costmap_2d::LayeredCostmap* layered_costmap = new costmap_2d::LayeredCostmap("map", false, true);
  std::cout << "[Test] LayeredCostmap 创建成功" << std::endl;
  
  // 创建 StaticLayer
  costmap_2d::StaticLayer* static_layer = new costmap_2d::StaticLayer();
  std::cout << "[Test] StaticLayer 创建成功" << std::endl;
  
  // 创建 InflationLayer
  costmap_2d::InflationLayer* inflation_layer = new costmap_2d::InflationLayer(0.55, 10.0, false);
  std::cout << "[Test] InflationLayer 创建成功" << std::endl;
  
  // 使用 shared_ptr 管理内存
  boost::shared_ptr<costmap_2d::Layer> sl_ptr(static_layer);
  boost::shared_ptr<costmap_2d::Layer> il_ptr(inflation_layer);
  
  // 添加插件
  std::cout << "[Test] 添加插件..." << std::endl;
  layered_costmap->addPlugin(sl_ptr);
  layered_costmap->addPlugin(il_ptr);
  std::cout << "[Test] 插件添加成功" << std::endl;
  
  // 初始化 - 必须使用 initialize() 而不是 onInitialize()
  // initialize() 会设置 layered_costmap_ 指针，然后调用 onInitialize()
  std::cout << "[Test] 初始化 StaticLayer..." << std::endl;
  static_layer->initialize(layered_costmap, "static_layer", NULL);
  static_layer->setEnabled(true);
  static_layer->activate();
  std::cout << "[Test] 初始化 InflationLayer..." << std::endl;
  inflation_layer->initialize(layered_costmap, "inflation_layer", NULL);
  inflation_layer->setEnabled(true);
  inflation_layer->activate();
  
  // 处理地图
  std::cout << "[Test] 处理静态地图..." << std::endl;
  static_layer->incomingMap(grid);
  std::cout << "[Test] 静态地图处理完成" << std::endl;
  
  // 更新代价地图
  std::cout << "[Test] 更新代价地图..." << std::endl;
  double robot_x = 0.0, robot_y = 0.0, robot_yaw = 0.0;
  layered_costmap->updateMap(robot_x, robot_y, robot_yaw);
  std::cout << "[Test] 代价地图更新完成" << std::endl;
  
  // 获取主代价地图
  costmap_2d::Costmap2D* master = layered_costmap->getCostmap();
  
  // 统计结果
  int free_final = 0, obs_final = 0, inflated_final = 0, unknown_final = 0;
  unsigned char* data = master->getCharMap();
  unsigned int size = master->getSizeInCellsX() * master->getSizeInCellsY();
  
  for (unsigned int i = 0; i < size; ++i)
  {
    if (data[i] == costmap_2d::FREE_SPACE) free_final++;
    else if (data[i] == costmap_2d::LETHAL_OBSTACLE) obs_final++;
    else if (data[i] == costmap_2d::INSCRIBED_INFLATED_OBSTACLE) inflated_final++;
    else if (data[i] == costmap_2d::NO_INFORMATION) unknown_final++;
    else if (data[i] > costmap_2d::FREE_SPACE) inflated_final++;
  }
  
  std::cout << "\n[Test] 代价地图统计:" << std::endl;
  std::cout << "  自由空间(0): " << free_final << std::endl;
  std::cout << "  障碍物(254): " << obs_final << std::endl;
  std::cout << "  膨胀区域(1-253): " << inflated_final << std::endl;
  std::cout << "  未知区域(255): " << unknown_final << std::endl;
  
  // 清理
  delete layered_costmap;
  
  std::cout << "\n========================================" << std::endl;
  std::cout << "  测试完成" << std::endl;
  std::cout << "========================================" << std::endl;
  
  return 0;
}
