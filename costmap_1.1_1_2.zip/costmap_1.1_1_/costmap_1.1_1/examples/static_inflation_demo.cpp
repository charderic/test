/**
 * @file static_inflation_demo.cpp
 * @brief 静态层+膨胀层Demo - 接收/map话题，生成膨胀后的代价地图
 *
 * 功能：
 * 1. 订阅 /map 话题（nav_msgs::OccupancyGrid）
 * 2. 创建 LayeredCostmap 分层代价地图
 * 3. 添加 StaticLayer 静态层插件
 * 4. 添加 InflationLayer 膨胀层插件
 * 5. 生成并输出膨胀后的代价地图
 *
 * 使用方法：
 *   ./static_inflation_demo [map_topic]
 */

#include <ros/ros.h>
#include <costmap_2d/layered_costmap.h>
#include <costmap_2d/static_layer.h>
#include <costmap_2d/inflation_layer.h>
#include <costmap_2d/cost_values.h>
#include <nav_msgs/OccupancyGrid.h>
#include <iostream>
#include <iomanip>
#include <fstream>

// 全局变量
std::unique_ptr<costmap_2d::LayeredCostmap> layered_costmap_;
boost::shared_ptr<costmap_2d::StaticLayer> static_layer_;
boost::shared_ptr<costmap_2d::InflationLayer> inflation_layer_;

/**
 * @brief 可视化代价地图
 */
void visualizeCostmap(costmap_2d::Costmap2D* costmap)
{
  if (!costmap) return;

  std::cout << "\n========================================" << std::endl;
  std::cout << "    静态层 + 膨胀层代价地图" << std::endl;
  std::cout << "========================================" << std::endl;
  std::cout << "尺寸(栅格):  " << costmap->getSizeInCellsX() << " x "
            << costmap->getSizeInCellsY() << std::endl;
  std::cout << "尺寸(米):    " << costmap->getSizeInMetersX() << " x "
            << costmap->getSizeInMetersY() << std::endl;
  std::cout << "分辨率:      " << costmap->getResolution() << " 米/栅格" << std::endl;
  std::cout << "原点:        (" << costmap->getOriginX() << ", "
            << costmap->getOriginY() << ")" << std::endl;

  // 统计信息
  int free_count = 0, lethal_count = 0, inflate_count = 0, no_info_count = 0;

  for (unsigned int i = 0; i < costmap->getSizeInCellsX(); ++i)
  {
    for (unsigned int j = 0; j < costmap->getSizeInCellsY(); ++j)
    {
      unsigned char cost = costmap->getCost(i, j);
      if (cost == costmap_2d::FREE_SPACE)
        free_count++;
      else if (cost == costmap_2d::LETHAL_OBSTACLE)
        lethal_count++;
      else if (cost == costmap_2d::NO_INFORMATION)
        no_info_count++;
      else
        inflate_count++;
    }
  }

  unsigned int total = costmap->getSizeInCellsX() * costmap->getSizeInCellsY();
  std::cout << "----------------------------------------" << std::endl;
  std::cout << "统计信息:" << std::endl;
  std::cout << "  总栅格:     " << total << std::endl;
  std::cout << "  自由空间:   " << free_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * free_count / total) << "%)" << std::endl;
  std::cout << "  障碍物:     " << lethal_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * lethal_count / total) << "%)" << std::endl;
  std::cout << "  膨胀区域:   " << inflate_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * inflate_count / total) << "%)" << std::endl;
  std::cout << "  未知区域:   " << no_info_count << " (" 
            << std::fixed << std::setprecision(1) << (100.0 * no_info_count / total) << "%)" << std::endl;
  std::cout << "========================================\n" << std::endl;
}

/**
 * @brief 保存代价地图为PGM文件
 */
void saveCostmapToPGM(costmap_2d::Costmap2D* costmap, const std::string& filename)
{
  std::ofstream pgm_file(filename);
  if (!pgm_file.is_open())
  {
    ROS_ERROR("无法打开文件: %s", filename.c_str());
    return;
  }

  // 写入PGM文件头
  pgm_file << "P2\n";
  pgm_file << "# Static + Inflation Costmap\n";
  pgm_file << costmap->getSizeInCellsX() << " " << costmap->getSizeInCellsY() << "\n";
  pgm_file << "255\n";

  // 写入像素数据
  for (unsigned int j = costmap->getSizeInCellsY(); j > 0; --j)
  {
    for (unsigned int i = 0; i < costmap->getSizeInCellsX(); ++i)
    {
      unsigned char cost = costmap->getCost(i, j);
      int gray_value;
      
      if (cost == costmap_2d::FREE_SPACE)
        gray_value = 255;  // 白色
      else if (cost == costmap_2d::LETHAL_OBSTACLE)
        gray_value = 0;    // 黑色
      else if (cost == costmap_2d::NO_INFORMATION)
        gray_value = 205;  // 灰色
      else
        gray_value = 255 - cost;  // 膨胀区域，根据代价值渐变

      pgm_file << gray_value;
      if (i < costmap->getSizeInCellsX() - 1)
        pgm_file << " ";
    }
    pgm_file << "\n";
  }

  pgm_file.close();
  ROS_INFO("代价地图已保存到: %s", filename.c_str());
}

int main(int argc, char** argv)
{
  // 初始化ROS节点
  ros::init(argc, argv, "static_inflation_demo");
  ros::NodeHandle nh;
  ros::NodeHandle private_nh("~");

  // 获取地图话题参数
  std::string map_topic = "/map";
  if (argc > 1)
  {
    map_topic = argv[1];
  }

  ROS_INFO("等待接收地图: %s", map_topic.c_str());

  // 阻塞等待接收地图消息
  nav_msgs::OccupancyGridConstPtr map_msg = ros::topic::waitForMessage<nav_msgs::OccupancyGrid>(map_topic, nh, ros::Duration(30.0));
  
  if (!map_msg)
  {
    ROS_ERROR("超时未收到地图消息！");
    return -1;
  }

  ROS_INFO("收到地图: %s, 尺寸: %dx%d, 分辨率: %.3f m/pixel",
           map_msg->header.frame_id.c_str(),
           map_msg->info.width, map_msg->info.height,
           map_msg->info.resolution);

  // ===== 1. 创建分层代价地图 =====
  layered_costmap_.reset(new costmap_2d::LayeredCostmap("map", false, true));

  // ===== 2. 创建静态层 =====
  static_layer_.reset(new costmap_2d::StaticLayer());

  // ===== 3. 将静态层添加到分层代价地图 =====
  layered_costmap_->addPlugin(static_layer_);

  // ===== 4. 配置静态层参数 =====
  private_nh.setParam("static_layer/map_topic", map_topic);
  private_nh.setParam("static_layer/first_map_only", true);
  private_nh.setParam("static_layer/track_unknown_space", true);
  private_nh.setParam("static_layer/use_maximum", false);
  private_nh.setParam("static_layer/lethal_cost_threshold", 100);
  private_nh.setParam("static_layer/trinary_costmap", true);

  // ===== 5. 初始化静态层 =====
  ROS_INFO("初始化静态层...");
  static_layer_->initialize(layered_costmap_.get(), "static_layer", NULL);
  static_layer_->setEnabled(true);  // 启用静态层
  ROS_INFO("静态层初始化完成");

  // 等待地图处理完成
  ros::Duration(0.5).sleep();
  ros::spinOnce();

  // ===== 6. 创建膨胀层 =====
  inflation_layer_.reset(new costmap_2d::InflationLayer());

  // ===== 7. 将膨胀层添加到分层代价地图 =====
  layered_costmap_->addPlugin(inflation_layer_);

  // ===== 8. 配置膨胀层参数 =====
  private_nh.setParam("inflation_layer/inflation_radius", 0.5);      // 膨胀半径0.5米
  private_nh.setParam("inflation_layer/cost_scaling_factor", 10.0);  // 代价衰减系数
  private_nh.setParam("inflation_layer/inscribed_radius", 0.3);      // 内切半径0.3米

  // ===== 9. 初始化膨胀层 =====
  ROS_INFO("初始化膨胀层...");
  inflation_layer_->initialize(layered_costmap_.get(), "inflation_layer", NULL);
  inflation_layer_->setEnabled(true);  // 启用膨胀层
  ROS_INFO("膨胀层初始化完成");

  // ===== 10. 更新代价地图 =====
  ROS_INFO("获取代价地图...");
  costmap_2d::Costmap2D* costmap = layered_costmap_->getCostmap();
  
  if (!costmap)
  {
    ROS_ERROR("获取代价地图失败！");
    return -1;
  }
  ROS_INFO("代价地图获取成功，尺寸: %dx%d", costmap->getSizeInCellsX(), costmap->getSizeInCellsY());

  // 计算机器人位置（使用地图中心）
  double robot_x = costmap->getOriginX() + costmap->getSizeInMetersX() / 2.0;
  double robot_y = costmap->getOriginY() + costmap->getSizeInMetersY() / 2.0;
  double robot_yaw = 0.0;

  ROS_INFO("机器人位置: (%.2f, %.2f)", robot_x, robot_y);

  // 更新分层代价地图
  layered_costmap_->updateMap(robot_x, robot_y, robot_yaw);

  ROS_INFO("代价地图更新完成");

  // ===== 11. 可视化代价地图 =====
  visualizeCostmap(costmap);

  // ===== 12. 保存代价地图为PGM文件 =====
  saveCostmapToPGM(costmap, "static_inflation_costmap.pgm");

  // ===== 13. 输出膨胀层信息 =====
  ROS_INFO("\n膨胀层信息:");
  ROS_INFO("  膨胀半径: %.2f 米", inflation_layer_->getInflationRadius());
  ROS_INFO("  代价衰减系数: %.2f", inflation_layer_->getCostScalingFactor());

  // ===== 14. 显示部分代价地图数据（中心区域）=====
  unsigned int center_x = costmap->getSizeInCellsX() / 2;
  unsigned int center_y = costmap->getSizeInCellsY() / 2;
  unsigned int window_size = 10;

  ROS_INFO("\n中心区域代价值 (%dx%d):", window_size * 2, window_size * 2);
  for (unsigned int j = center_y + window_size; j > center_y - window_size; --j)
  {
    std::cout << "  ";
    for (unsigned int i = center_x - window_size; i < center_x + window_size; ++i)
    {
      if (i < costmap->getSizeInCellsX() && j < costmap->getSizeInCellsY())
      {
        unsigned char cost = costmap->getCost(i, j);
        std::cout << std::setw(3) << static_cast<int>(cost) << " ";
      }
      else
      {
        std::cout << "   ";
      }
    }
    std::cout << std::endl;
  }

  ROS_INFO("\nDemo运行完成！");
  ROS_INFO("生成的PGM文件: static_inflation_costmap.pgm");

  return 0;
}