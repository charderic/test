/**
 * @file test_laser_publisher.cpp
 * @brief 测试用激光雷达数据发布器
 * 
 * 发布模拟的激光扫描数据，用于测试 layered_costmap_demo
 */

#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>

int main(int argc, char** argv)
{
  ros::init(argc, argv, "test_laser_publisher");
  ros::NodeHandle nh;

  ros::Publisher scan_pub = nh.advertise<sensor_msgs::LaserScan>("/scan", 10);
  
  ROS_INFO("发布模拟激光数据到 /scan 话题");

  sensor_msgs::LaserScan scan_msg;
  scan_msg.header.frame_id = "laser";
  scan_msg.angle_min = -M_PI;
  scan_msg.angle_max = M_PI;
  scan_msg.angle_increment = 0.01;
  scan_msg.range_min = 0.1;
  scan_msg.range_max = 10.0;
  
  int num_ranges = static_cast<int>((scan_msg.angle_max - scan_msg.angle_min) / scan_msg.angle_increment);
  scan_msg.ranges.resize(num_ranges);

  ros::Rate rate(10);
  
  double obstacle_angle = 0.0; // 障碍物角度
  
  while (ros::ok())
  {
    scan_msg.header.stamp = ros::Time::now();
    
    // 生成模拟激光数据
    for (int i = 0; i < num_ranges; ++i)
    {
      double angle = scan_msg.angle_min + i * scan_msg.angle_increment;
      
      // 在正前方添加一个模拟障碍物（距离2米）
      if (fabs(angle - obstacle_angle) < 0.1)
      {
        scan_msg.ranges[i] = 2.0;
      }
      // 在左前方添加另一个障碍物
      else if (fabs(angle - (-M_PI/4)) < 0.15)
      {
        scan_msg.ranges[i] = 3.0;
      }
      // 在右前方添加第三个障碍物
      else if (fabs(angle - (M_PI/3)) < 0.1)
      {
        scan_msg.ranges[i] = 1.5;
      }
      else
      {
        // 其他方向为最大距离（无障碍物）
        scan_msg.ranges[i] = scan_msg.range_max;
      }
    }
    
    scan_pub.publish(scan_msg);
    ROS_DEBUG_THROTTLE(1.0, "发布激光扫描: %d 个点", num_ranges);
    
    // 让障碍物缓慢移动（模拟动态障碍物）
    obstacle_angle += 0.02;
    if (obstacle_angle > M_PI/2)
      obstacle_angle = -M_PI/2;
    
    rate.sleep();
  }

  return 0;
}