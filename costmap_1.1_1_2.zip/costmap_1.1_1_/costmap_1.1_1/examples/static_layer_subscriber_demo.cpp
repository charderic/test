/**
 * @file static_layer_subscriber_demo.cpp
 * @brief StaticLayer + InflationLayer 分层膨胀 Demo
 *
 * 功能：
 * 1. 使用 ROS 订阅 /map 话题
 * 2. 将数据转换为自定义数据结构 OccupancyGridData
 * 3. 存储到 Vector 容器中
 * 4. 当 Vector 非空时，调用 StaticLayer 的 incomingMap
 * 5. 配置 InflationLayer 对障碍物进行膨胀
 *
 * 分层架构：
 *   StaticLayer (静态地图)  -->  master_grid  -->  InflationLayer (障碍物膨胀)
 *
 * 膨胀原理：
 *   InflationLayer::updateCosts() 读取 master_grid 中的 LETHAL_OBSTACLE(254)
 *   按距离衰减公式膨胀到周围区域
 *
 * 使用方法：
 *   ./static_layer_subscriber_demo [map_topic]
 */

#include <ros/ros.h>
#include <nav_msgs/OccupancyGrid.h>
#include <geometry_msgs/Pose.h>
#include <costmap_2d/static_layer1.h>
#include <costmap_2d/inflation_layer.h>
#include <costmap_2d/layered_costmap.h>
#include <iostream>
#include <vector>
#include <iomanip>
#include <boost/thread.hpp>

/**
 * @brief 地图订阅器类
 *
 * 使用 ROS 订阅 /map 话题，将数据转换为自定义数据结构，
 * 并存储到 Vector 容器中。
 */
class MapSubscriber
{
public:
  MapSubscriber(const std::string& map_topic = "/map")
    : map_topic_(map_topic)
    , last_data_hash_(0)
    , running_(true)
  {
    ros::NodeHandle nh;
    map_sub_ = nh.subscribe(map_topic_, 1, &MapSubscriber::mapCallback, this);
    std::cout << "[MapSubscriber] 初始化完成，订阅话题: " << map_topic_ << std::endl;
  }

  ~MapSubscriber()
  {
    running_ = false;
    if (worker_thread_.joinable())
      worker_thread_.join();
  }

  bool hasData() const
  {
    boost::mutex::scoped_lock lock(data_mutex_);
    return !data_queue_.empty();
  }

  size_t getQueueSize() const
  {
    boost::mutex::scoped_lock lock(data_mutex_);
    return data_queue_.size();
  }

  costmap_2d::OccupancyGridData take()
  {
    boost::mutex::scoped_lock lock(data_mutex_);
    if (data_queue_.empty())
    {
      return costmap_2d::OccupancyGridData();
    }
    
    costmap_2d::OccupancyGridData grid = data_queue_.front();
    data_queue_.erase(data_queue_.begin());
    return grid;
  }

  void clear()
  {
    boost::mutex::scoped_lock lock(data_mutex_);
    data_queue_.clear();
  }

private:
  void mapCallback(const nav_msgs::OccupancyGridConstPtr& msg)
  {
    size_t hash = computeHash(msg);
    if (hash == last_data_hash_)
    {
      std::cout << "[MapSubscriber] 数据未变化，跳过" << std::endl;
      return;
    }
    last_data_hash_ = hash;

    costmap_2d::OccupancyGridData grid = convertToGridData(msg);

    {
      boost::mutex::scoped_lock lock(data_mutex_);
      data_queue_.push_back(grid);
    }

    std::cout << "[MapSubscriber] 收到新地图: " << grid.getWidth() << "x" << grid.getHeight()
              << ", 队列大小: " << data_queue_.size() << std::endl;
  }

  size_t computeHash(const nav_msgs::OccupancyGridConstPtr& msg)
  {
    size_t hash = 0;
    hash ^= std::hash<int>()(msg->info.width) << 0;
    hash ^= std::hash<int>()(msg->info.height) << 4;
    hash ^= std::hash<double>()(msg->info.resolution) << 8;
    for (size_t i = 0; i < msg->data.size() && i < 1000; i += 100)
    {
      hash ^= std::hash<int>()(msg->data[i]) << (i % 20);
    }
    return hash;
  }

  costmap_2d::OccupancyGridData convertToGridData(const nav_msgs::OccupancyGridConstPtr& msg)
  {
    costmap_2d::OccupancyGridData grid;
    
    grid.setFrameId(msg->header.frame_id);
    grid.setTimestamp(msg->header.stamp.toSec());
    
    grid.setGridInfo(
      msg->info.width,
      msg->info.height,
      msg->info.resolution,
      msg->info.origin.position.x,
      msg->info.origin.position.y
    );
    
    for (size_t i = 0; i < msg->data.size(); ++i)
    {
      grid[i] = msg->data[i];
    }
    
    return grid;
  }

private:
  std::string map_topic_;
  ros::Subscriber map_sub_;
  std::vector<costmap_2d::OccupancyGridData> data_queue_;
  mutable boost::mutex data_mutex_;
  size_t last_data_hash_;
  bool running_;
  boost::thread worker_thread_;
};

/**
 * @brief 主函数
 */
int main(int argc, char** argv)
{
  ros::init(argc, argv, "static_layer_subscriber_demo");

  std::string map_topic = "/map";
  if (argc > 1)
  {
    map_topic = argv[1];
  }

  std::cout << "========================================" << std::endl;
  std::cout << "  StaticLayer + InflationLayer Demo" << std::endl;
  std::cout << "========================================" << std::endl;
  std::cout << "地图话题: " << map_topic << std::endl;
  std::cout << "========================================\n" << std::endl;

  // ========== 创建分层代价地图 ==========
  // 参数：全局坐标系，是否滚动窗口，是否跟踪未知空间
  costmap_2d::LayeredCostmap layered_costmap("map", false, true);

  // ========== 创建 StaticLayer（静态地图层）==========
  costmap_2d::StaticLayer static_layer;
  
  // ========== 创建 InflationLayer（膨胀层）==========
  // 参数：膨胀半径(米), 代价衰减权重, 是否膨胀未知区域
  costmap_2d::InflationLayer inflation_layer(0.55, 10.0, false);

  // ========== 添加到分层地图（顺序很重要！）==========
  // 添加顺序 = 更新顺序：StaticLayer 先更新代价，InflationLayer 后膨胀
  layered_costmap.addPlugin(boost::shared_ptr<costmap_2d::Layer>(&static_layer));
  layered_costmap.addPlugin(boost::shared_ptr<costmap_2d::Layer>(&inflation_layer));

  // ========== 初始化各层 ==========
  // 必须使用 initialize() 而不是 onInitialize()
  // initialize() 会设置 layered_costmap_ 指针，然后调用 onInitialize()
  static_layer.initialize(&layered_costmap, "static_layer", NULL);
  static_layer.setEnabled(true);
  static_layer.activate();
  
  inflation_layer.initialize(&layered_costmap, "inflation_layer", NULL);
  inflation_layer.setEnabled(true);
  inflation_layer.activate();

  std::cout << "[Main] 分层代价地图初始化完成" << std::endl;
  std::cout << "[Main] - StaticLayer: 静态地图层" << std::endl;
  std::cout << "[Main] - InflationLayer: 膨胀半径=0.55m, 权重=10.0" << std::endl;
  std::cout << "[Main] 等待地图数据...\n" << std::endl;

  // ========== 创建地图订阅器 ==========
  MapSubscriber subscriber(map_topic);

  // ========== 主循环 ==========
  // 创建代价地图发布器（用于 rviz 可视化）
  ros::NodeHandle nh;
  ros::Publisher costmap_pub = nh.advertise<nav_msgs::OccupancyGrid>("/costmap", 1, true);
  
  std::cout << "[Main] 发布代价地图到 /costmap 话题" << std::endl;
  
  // 用于存储代价地图的元信息
  nav_msgs::MapMetaData map_meta;
  bool meta_initialized = false;
  costmap_2d::Costmap2D* master = nullptr;
  
  ros::Rate rate(10);
  
  while (ros::ok())
  {
    ros::spinOnce();

    // 当 Vector 非空时，调用 incomingMap
    if (subscriber.hasData())
    {
      std::cout << "[Main] ========== 开始更新 ==========" << std::endl;
      
      while (subscriber.hasData())
      {
        costmap_2d::OccupancyGridData grid = subscriber.take();
        
        if (grid.isValid())
        {
          std::cout << "[Main] 调用 static_layer.incomingMap()" << std::endl;
          
          // 1. StaticLayer 处理静态地图数据
          //    → 将 OccupancyGrid 转换为代价写入 StaticLayer 内部 costmap_
          static_layer.incomingMap(grid);
        }
      }
      
      // 2. 调用 LayeredCostmap::updateMap() 触发完整更新流程
      //    → 按顺序调用各层的 updateBounds() 和 updateCosts()
      double robot_x = 0.0, robot_y = 0.0, robot_yaw = 0.0;
      
      std::cout << "[Main] 调用 layered_costmap.updateMap()" << std::endl;
      layered_costmap.updateMap(robot_x, robot_y, robot_yaw);
      
      // 获取主代价地图
      master = layered_costmap.getCostmap();
      
      // 初始化地图元信息
      if (!meta_initialized && master->getSizeInCellsX() > 0)
      {
        map_meta.resolution = master->getResolution();
        map_meta.width = master->getSizeInCellsX();
        map_meta.height = master->getSizeInCellsY();
        map_meta.origin.position.x = master->getOriginX();
        map_meta.origin.position.y = master->getOriginY();
        map_meta.origin.position.z = 0.0;
        map_meta.origin.orientation.w = 1.0;
        meta_initialized = true;
      }
      
      // 打印代价统计
      int free_count = 0, obs_count = 0, inflated_count = 0, unknown_count = 0;
      unsigned char* data = master->getCharMap();
      unsigned int size = master->getSizeInCellsX() * master->getSizeInCellsY();
      
      for (unsigned int i = 0; i < size; ++i)
      {
        if (data[i] == costmap_2d::FREE_SPACE) free_count++;
        else if (data[i] == costmap_2d::LETHAL_OBSTACLE) obs_count++;
        else if (data[i] == costmap_2d::INSCRIBED_INFLATED_OBSTACLE) inflated_count++;
        else if (data[i] == costmap_2d::NO_INFORMATION) unknown_count++;
        else if (data[i] > costmap_2d::FREE_SPACE) inflated_count++;
      }
      
      std::cout << "[Main] 代价统计:" << std::endl;
      std::cout << "  自由空间: " << free_count << std::endl;
      std::cout << "  障碍物(254): " << obs_count << std::endl;
      std::cout << "  膨胀区域: " << inflated_count << std::endl;
      std::cout << "  未知区域: " << unknown_count << std::endl;
      std::cout << "[Main] ========== 更新完成 ==========\n" << std::endl;
    }
    
    // 发布代价地图（每次循环都发布，便于 rviz 观察）
    if (meta_initialized)
    {
      nav_msgs::OccupancyGrid costmap_msg;
      costmap_msg.header.stamp = ros::Time::now();
      costmap_msg.header.frame_id = "map";
      costmap_msg.info = map_meta;
      
      // 复制代价数据（转换为 0-100 范围）
      costmap_msg.data.resize(map_meta.width * map_meta.height);
      unsigned char* data = master->getCharMap();
      for (size_t i = 0; i < costmap_msg.data.size(); ++i)
      {
        // 代价地图值 0-255 -> OccupancyGrid 值 0-100
        // 0(FREE) -> 0, 255(NO_INFORMATION) -> -1, 254(LETHAL) -> 100
        unsigned char val = data[i];
        if (val == costmap_2d::NO_INFORMATION)
          costmap_msg.data[i] = -1;
        else if (val == costmap_2d::LETHAL_OBSTACLE)
          costmap_msg.data[i] = 100;
        else
          costmap_msg.data[i] = static_cast<int8_t>(val * 100 / 255);
      }
      
      costmap_pub.publish(costmap_msg);
    }

    rate.sleep();
  }

  static_layer.deactivate();
  std::cout << "[Main] Demo 退出" << std::endl;

  return 0;
}
