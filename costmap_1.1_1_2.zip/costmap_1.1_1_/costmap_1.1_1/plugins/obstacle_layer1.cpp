/**
 * @file obstacle_layer1.cpp
 * @brief 障碍物层实现 - 去ROS依赖版本
 */

#include <costmap_2d/obstacle_layer1.h>
#include <costmap_2d/costmap_math.h>
#include <costmap_2d/footprint.h>
#include <iostream>
#include <algorithm>
#include <cmath>

namespace costmap_2d
{

ObstacleLayer::ObstacleLayer()
  : obstacle_range_(2.5)
  , raytrace_range_(3.0)
  , max_obstacle_height_(2.0)
  , timestamp_tolerance_ns_(100000000) // 100ms
  , rolling_window_(false)
  , footprint_clearing_enabled_(true)
{
  costmap_ = NULL;
}

ObstacleLayer::~ObstacleLayer()
{
}

void ObstacleLayer::onInitialize()
{
  rolling_window_ = layered_costmap_->isRolling();
  
  bool track_unknown_space = layered_costmap_->isTrackingUnknown();
  default_value_ = track_unknown_space ? NO_INFORMATION : FREE_SPACE;
  
  matchSize();
  current_ = true;
  
  observations_.clear();
  
  std::cout << "[ObstacleLayer] 初始化完成" << std::endl;
  std::cout << "[ObstacleLayer]   - obstacle_range: " << obstacle_range_ << " m" << std::endl;
  std::cout << "[ObstacleLayer]   - raytrace_range: " << raytrace_range_ << " m" << std::endl;
  std::cout << "[ObstacleLayer]   - rolling_window: " << (rolling_window_ ? "true" : "false") << std::endl;
}

void ObstacleLayer::activate()
{
  std::cout << "[ObstacleLayer] 已激活" << std::endl;
}

void ObstacleLayer::deactivate()
{
  std::cout << "[ObstacleLayer] 已停用" << std::endl;
}

void ObstacleLayer::reset()
{
  deactivate();
  observations_.clear();
  activate();
}

void ObstacleLayer::updateBounds(double robot_x, double robot_y, double robot_yaw,
                                 double* min_x, double* min_y, double* max_x, double* max_y)
{
  // 调试：检查 costmap_ 状态
  static int debug_count = 0;
  if (debug_count++ < 3) {
    unsigned int sx = getSizeInCellsX();
    unsigned int sy = getSizeInCellsY();
    int no_info = 0, lethal = 0;
    for (size_t i = 0; i < sx * sy && i < 10000; ++i) {
      if (costmap_[i] == NO_INFORMATION) no_info++;
      else if (costmap_[i] == LETHAL_OBSTACLE) lethal++;
    }
    std::cout << "[ObstacleLayer::updateBounds] costmap_ 大小: " << sx << "x" << sy 
              << ", 前1万格: NO_INFO=" << no_info << " LETHAL=" << lethal << std::endl;
  }
  
  if (rolling_window_)
  {
    double new_ox = robot_x - getSizeInMetersX() / 2;
    double new_oy = robot_y - getSizeInMetersY() / 2;
    printf("[ObstacleLayer] 滚动窗口: 机器人(%.2f,%.2f) -> 新原点(%.2f,%.2f)\n",
           robot_x, robot_y, new_ox, new_oy);
    updateOrigin(new_ox, new_oy);
  }
  
  useExtraBounds(min_x, min_y, max_x, max_y);
  
  bool current = true;
  std::vector<Observation> observations, clearing_observations;
  
  current = current && getMarkingObservations(observations);
  current = current && getClearingObservations(clearing_observations);
  current_ = current;
  
  // 清除自由空间
  for (size_t i = 0; i < clearing_observations.size(); ++i)
  {
    raytraceFreespace(clearing_observations[i], min_x, min_y, max_x, max_y);
  }
  
  // 标记障碍物
  int marked_count = 0;
  for (size_t i = 0; i < observations.size(); ++i)
  {
    const Observation& obs = observations[i];
    const PointCloud& cloud = *(obs.cloud_);
    double sq_obstacle_range = obs.obstacle_range_ * obs.obstacle_range_;
    
    for (size_t j = 0; j < cloud.size(); ++j)
    {
      const Point& point = cloud[j];
      
      if (point.z > max_obstacle_height_)
        continue;
      
      double sq_dist = (point.x - obs.origin_.x) * (point.x - obs.origin_.x) +
                      (point.y - obs.origin_.y) * (point.y - obs.origin_.y) +
                      (point.z - obs.origin_.z) * (point.z - obs.origin_.z);
      
      if (sq_dist >= sq_obstacle_range)
        continue;
      
      unsigned int mx, my;
      if (!worldToMap(point.x, point.y, mx, my))
        continue;
      
      unsigned int index = getIndex(mx, my);
      costmap_[index] = LETHAL_OBSTACLE;
      marked_count++;
      
      touch(point.x, point.y, min_x, min_y, max_x, max_y);
    }
  }
  if (marked_count > 0) {
    std::cout << "[ObstacleLayer] 标记了 " << marked_count << " 个障碍物" << std::endl;
  }
  
  // 更新足迹边界
  if (footprint_clearing_enabled_)
  {
    transformFootprint(robot_x, robot_y, robot_yaw, getFootprint(), transformed_footprint_);
    
    for (size_t i = 0; i < transformed_footprint_.size(); i++)
    {
      touch(transformed_footprint_[i].x, transformed_footprint_[i].y, min_x, min_y, max_x, max_y);
    }
  }
}

void ObstacleLayer::updateCosts(costmap_2d::Costmap2D& master_grid, int min_i, int min_j,
                               int max_i, int max_j)
{
  if (footprint_clearing_enabled_)
  {
    setConvexPolygonCost(transformed_footprint_, costmap_2d::FREE_SPACE);
  }
  
  // 调试：检查 costmap_ 状态
  static int debug_count = 0;
  if (debug_count++ < 3) {
    int lethal_count = 0;
    int no_info_count = 0;
    int costmap_size = getSizeInCellsX() * getSizeInCellsY();
    for (int j = min_j; j < max_j && j < (int)getSizeInCellsY(); j++)
    {
      for (int i = min_i; i < max_i && i < (int)getSizeInCellsX(); i++)
      {
        unsigned int index = getIndex(i, j);
        if (index < (unsigned int)costmap_size && costmap_[index] == LETHAL_OBSTACLE)
          lethal_count++;
        if (index < (unsigned int)costmap_size && costmap_[index] == NO_INFORMATION)
          no_info_count++;
      }
    }
    std::cout << "[ObstacleLayer::updateCosts] 区域[" << min_i << "," << min_j 
              << "到" << max_i << "," << max_j << "], LETHAL=" << lethal_count 
              << ", NO_INFO=" << no_info_count << std::endl;
  }
  
  // 使用覆盖方式更新代价
  std::cout << "[ObstacleLayer::updateCosts] 更新区域: [" << min_i << "," << min_j 
            << "到" << max_i << "," << max_j << "]" << std::endl;
  updateWithOverwrite(master_grid, min_i, min_j, max_i, max_j);
}

void ObstacleLayer::incomingLaserScan(const LaserScanData& scan, const RobotPose& robot_pose, double sensor_mount_angle)
{
  if (!scan.isValid() || !robot_pose.isValid())
  {
    std::cerr << "[ObstacleLayer] 无效的激光扫描或机器人位姿" << std::endl;
    return;
  }
  
  // 检查时间戳对齐
  int64_t time_diff = static_cast<int64_t>(scan.timestamp_ns_) - static_cast<int64_t>(robot_pose.timestamp_ns_);
  if (time_diff < 0) time_diff = -time_diff;
  
  if (time_diff > static_cast<int64_t>(timestamp_tolerance_ns_))
  {
    std::cerr << "[ObstacleLayer] 时间戳不对齐: scan=" << scan.timestamp_ns_ 
              << " pose=" << robot_pose.timestamp_ns_ 
              << " diff=" << time_diff << " ns" << std::endl;
    return;
  }
  
  // 将激光扫描转换为点云
  PointCloud raw_cloud = laserScanToPointCloud(scan);
  
  // 转换到全局坐标系
  boost::shared_ptr<PointCloud> global_cloud(new PointCloud());
  global_cloud->reserve(raw_cloud.size());
  
  // 调试：打印前几个点的坐标转换
  static int debug_count = 0;
  bool print_debug = (debug_count++ < 2);
  if (print_debug) {
    printf("[ObstacleLayer] 机器人位姿: (%.2f, %.2f, %.2f rad)\n", 
           robot_pose.x_, robot_pose.y_, robot_pose.theta_);
    printf("[ObstacleLayer] 激光角度范围: [%.2f, %.2f] rad, 增量: %.4f rad\n",
           scan.angle_min_, scan.angle_max_, scan.angle_increment_);
  }
  
  Point origin;
  origin.x = robot_pose.x_;
  origin.y = robot_pose.y_;
  origin.z = 0.0;
  
  for (size_t i = 0; i < raw_cloud.size(); ++i)
  {
    const Point& pt = raw_cloud[i];
    double tx, ty;
    
    // 传感器安装在机器人上
    // sensor_mount_angle: 传感器安装角度偏移，用于补偿激光雷达的实际安装方向
    // 转换公式：global = robot_pose + rotation(sensor_point + mount_angle_offset)
    double effective_theta = robot_pose.theta_ + sensor_mount_angle;
    transformPoint(pt.x, pt.y, robot_pose.x_, robot_pose.y_, effective_theta, tx, ty);
    
  // 调试：打印前几个激光点的转换
    if (print_debug && i < 5) {
      // 计算传感器坐标对应的角度
      double sensor_angle = std::atan2(pt.y, pt.x);
      // 计算世界坐标下的角度（考虑机器人朝向）
      double world_angle = std::atan2(ty - robot_pose.y_, tx - robot_pose.x_);
      printf("[ObstacleLayer] 点[%zu]: 传感器角度=%.2frad, 世界角度=%.2frad, 机器人朝向=%.2frad\n",
             i, sensor_angle, world_angle, robot_pose.theta_);
      printf("  传感器(%.2f,%.2f) -> 世界(%.2f,%.2f)\n",
             pt.x, pt.y, tx, ty);
    }
    
    Point global_pt;
    global_pt.x = tx;
    global_pt.y = ty;
    global_pt.z = pt.z;
    global_pt.intensity = pt.intensity;
    
    global_cloud->addPoint(global_pt);
  }
  
  // 创建观测数据
  Observation obs(origin, global_cloud, obstacle_range_, raytrace_range_);
  observations_.push_back(obs);
  
  // 限制观测数据数量
  if (observations_.size() > 10)
  {
    observations_.erase(observations_.begin());
  }
  
  std::cout << "[ObstacleLayer] 处理激光扫描: " << global_cloud->size() << " 个点" << std::endl;
}

PointCloud ObstacleLayer::laserScanToPointCloud(const LaserScanData& scan)
{
  PointCloud cloud;
  
  size_t num_points = scan.ranges_.size();
  cloud.reserve(num_points);
  
  double angle = scan.angle_min_;
  
  for (size_t i = 0; i < num_points; ++i, angle += scan.angle_increment_)
  {
    float range = scan.ranges_[i];
    
    // 检查范围有效性
    if (!std::isfinite(range) || range < scan.range_min_ || range > scan.range_max_)
    {
      continue;
    }
    
    // 转换为笛卡尔坐标 (传感器坐标系)
    double x = range * std::cos(angle);
    double y = range * std::sin(angle);
    double z = 0.0;  // 假设2D激光扫描
    
    cloud.addPoint(x, y, z);
  }
  
  return cloud;
}

void ObstacleLayer::transformPoint(double wx, double wy, double ox, double oy, double theta,
                                  double& tx, double& ty)
{
  // 2D 坐标变换: global = origin + R(theta) * sensor_point
  double cos_t = std::cos(theta);
  double sin_t = std::sin(theta);
  
  tx = ox + cos_t * wx - sin_t * wy;
  ty = oy + sin_t * wx + cos_t * wy;
}

bool ObstacleLayer::getMarkingObservations(std::vector<Observation>& marking_observations) const
{
  bool current = true;
  
  for (size_t i = 0; i < observations_.size(); ++i)
  {
    marking_observations.push_back(observations_[i]);
  }
  
  return current;
}

bool ObstacleLayer::getClearingObservations(std::vector<Observation>& clearing_observations) const
{
  bool current = true;
  
  for (size_t i = 0; i < observations_.size(); ++i)
  {
    clearing_observations.push_back(observations_[i]);
  }
  
  return current;
}

void ObstacleLayer::raytraceFreespace(const Observation& clearing_observation, double* min_x,
                                     double* min_y, double* max_x, double* max_y)
{
  const PointCloud& cloud = *(clearing_observation.cloud_);
  double ox = clearing_observation.origin_.x;
  double oy = clearing_observation.origin_.y;
  
  for (size_t i = 0; i < cloud.size(); ++i)
  {
    const Point& pt = cloud[i];
    double wx = pt.x;
    double wy = pt.y;
    
    unsigned int x0, y0, x1, y1;
    if (!worldToMap(ox, oy, x0, y0))
      continue;
    
    if (!worldToMap(wx, wy, x1, y1))
      continue;
    
    raytraceLine(x0, y0, x1, y1);
    
    touch(wx, wy, min_x, min_y, max_x, max_y);
  }
  
  touch(ox, oy, min_x, min_y, max_x, max_y);
}

void ObstacleLayer::raytraceLine(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1)
{
  // 如果起点和终点相同，直接返回
  if (x0 == x1 && y0 == y1)
    return;
  
  int dx = std::abs(static_cast<int>(x1) - static_cast<int>(x0));
  int dy = std::abs(static_cast<int>(y1) - static_cast<int>(y0));
  
  int sx = x0 < x1 ? 1 : -1;
  int sy = y0 < y1 ? 1 : -1;
  
  int err = dx - dy;
  int x = x0, y = y0;
  
  unsigned int size_x = getSizeInCellsX();
  unsigned int size_y = getSizeInCellsY();
  
  while (true)
  {
    if (x >= size_x || y >= size_y)
      return;
    
    unsigned int index = getIndex(x, y);
    if (costmap_[index] == NO_INFORMATION)
      break;
    
    costmap_[index] = FREE_SPACE;
    
    if (x == x1 && y == y1)
      break;
    
    int e2 = 2 * err;
    if (e2 > -dy)
    {
      err -= dy;
      x += sx;
    }
    if (e2 < dx)
    {
      err += dx;
      y += sy;
    }
  }
}

} // namespace costmap_2d
