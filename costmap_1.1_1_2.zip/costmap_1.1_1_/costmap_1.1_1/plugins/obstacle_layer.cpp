/**
 * @file obstacle_layer.cpp
 * @brief 障碍物层实现 - 订阅激光雷达，标记障碍物，清除自由空间
 */

#include <costmap_2d/obstacle_layer.h>
#include <costmap_2d/costmap_math.h>
#include <tf2_ros/message_filter.h>

#include <pluginlib/class_list_macros.hpp>
#include <sensor_msgs/point_cloud2_iterator.h>

PLUGINLIB_EXPORT_CLASS(costmap_2d::ObstacleLayer, costmap_2d::Layer)

using costmap_2d::NO_INFORMATION;
using costmap_2d::LETHAL_OBSTACLE;
using costmap_2d::FREE_SPACE;

using costmap_2d::ObservationBuffer;
using costmap_2d::Observation;

namespace costmap_2d
{

void ObstacleLayer::onInitialize()
{
  ros::NodeHandle nh("~/" + name_), g_nh;
  rolling_window_ = layered_costmap_->isRolling();

  bool track_unknown_space;
  nh.param("track_unknown_space", track_unknown_space, layered_costmap_->isTrackingUnknown());
  default_value_ = track_unknown_space ? NO_INFORMATION : FREE_SPACE;

  ObstacleLayer::matchSize();
  current_ = true;

  global_frame_ = layered_costmap_->getGlobalFrameID();
  double transform_tolerance;
  nh.param("transform_tolerance", transform_tolerance, 0.2);

  std::string topics_string;
  nh.param("observation_sources", topics_string, std::string(""));
  ROS_INFO("    Subscribed to Topics: %s", topics_string.c_str());

  std::stringstream ss(topics_string);
  std::string source;
  while (ss >> source)
  {
    ros::NodeHandle source_node(nh, source);

    double observation_keep_time, expected_update_rate, min_obstacle_height, max_obstacle_height;
    std::string topic, sensor_frame;
    bool inf_is_valid, clearing, marking;

    source_node.param("topic", topic, source);
    source_node.param("sensor_frame", sensor_frame, std::string(""));
    source_node.param("observation_persistence", observation_keep_time, 0.0);
    source_node.param("expected_update_rate", expected_update_rate, 0.0);
    source_node.param("min_obstacle_height", min_obstacle_height, 0.0);
    source_node.param("max_obstacle_height", max_obstacle_height, 2.0);
    source_node.param("inf_is_valid", inf_is_valid, false);
    source_node.param("clearing", clearing, false);
    source_node.param("marking", marking, true);

    std::string raytrace_range_param_name, obstacle_range_param_name;
    double obstacle_range = 2.5;
    if (source_node.searchParam("obstacle_range", obstacle_range_param_name))
      source_node.getParam(obstacle_range_param_name, obstacle_range);

    double raytrace_range = 3.0;
    if (source_node.searchParam("raytrace_range", raytrace_range_param_name))
      source_node.getParam(raytrace_range_param_name, raytrace_range);

    observation_buffers_.push_back(boost::shared_ptr<ObservationBuffer>(
        new ObservationBuffer(topic, observation_keep_time, expected_update_rate,
                              min_obstacle_height, max_obstacle_height,
                              obstacle_range, raytrace_range, *tf_,
                              global_frame_, sensor_frame, transform_tolerance)));

    if (marking)
      marking_buffers_.push_back(observation_buffers_.back());

    if (clearing)
      clearing_buffers_.push_back(observation_buffers_.back());

    // 创建 LaserScan 订阅器
    boost::shared_ptr<message_filters::Subscriber<sensor_msgs::LaserScan>>
        sub(new message_filters::Subscriber<sensor_msgs::LaserScan>(g_nh, topic, 50));

    boost::shared_ptr<tf2_ros::MessageFilter<sensor_msgs::LaserScan>> filter(
        new tf2_ros::MessageFilter<sensor_msgs::LaserScan>(*sub, *tf_, global_frame_, 50, g_nh));

    if (inf_is_valid)
    {
      filter->registerCallback([this,buffer=observation_buffers_.back()](auto& msg){
        laserScanValidInfCallback(msg, buffer);
      });
    }
    else
    {
      filter->registerCallback([this,buffer=observation_buffers_.back()](auto& msg){
        laserScanCallback(msg, buffer);
      });
    }

    observation_subscribers_.push_back(sub);
    observation_notifiers_.push_back(filter);
    observation_notifiers_.back()->setTolerance(ros::Duration(0.05));

    if (sensor_frame != "")
    {
      std::vector<std::string> target_frames;
      target_frames.push_back(global_frame_);
      target_frames.push_back(sensor_frame);
      observation_notifiers_.back()->setTargetFrames(target_frames);
    }
  }

  dsrv_ = NULL;
  setupDynamicReconfigure(nh);
}

void ObstacleLayer::setupDynamicReconfigure(ros::NodeHandle& nh)
{
  dsrv_ = new dynamic_reconfigure::Server<costmap_2d::ObstaclePluginConfig>(nh);
  dynamic_reconfigure::Server<costmap_2d::ObstaclePluginConfig>::CallbackType cb =
      [this](auto& config, auto level){ reconfigureCB(config, level); };
  dsrv_->setCallback(cb);
}

ObstacleLayer::~ObstacleLayer()
{
  if (dsrv_)
    delete dsrv_;
}

void ObstacleLayer::reconfigureCB(costmap_2d::ObstaclePluginConfig &config, uint32_t level)
{
  enabled_ = config.enabled;
  footprint_clearing_enabled_ = config.footprint_clearing_enabled;
  max_obstacle_height_ = config.max_obstacle_height;
  combination_method_ = config.combination_method;
}

void ObstacleLayer::laserScanCallback(const sensor_msgs::LaserScanConstPtr& message,
                                      const boost::shared_ptr<ObservationBuffer>& buffer)
{
  sensor_msgs::PointCloud2 cloud;
  cloud.header = message->header;

  try
  {
    projector_.transformLaserScanToPointCloud(message->header.frame_id, *message, cloud, *tf_);
  }
  catch (tf2::TransformException &ex)
  {
    ROS_WARN("TF transform exception to frame %s: %s", global_frame_.c_str(), ex.what());
    projector_.projectLaser(*message, cloud);
  }
  catch (std::runtime_error &ex)
  {
    ROS_WARN("Laser scan transform error: %s", ex.what());
    return;
  }

  buffer->lock();
  buffer->bufferCloud(cloud);
  buffer->unlock();
}

void ObstacleLayer::laserScanValidInfCallback(const sensor_msgs::LaserScanConstPtr& raw_message,
                                              const boost::shared_ptr<ObservationBuffer>& buffer)
{
  float epsilon = 0.0001;
  sensor_msgs::LaserScan message = *raw_message;
  for (size_t i = 0; i < message.ranges.size(); i++)
  {
    float range = message.ranges[i];
    if (!std::isfinite(range) && range > 0)
      message.ranges[i] = message.range_max - epsilon;
  }

  sensor_msgs::PointCloud2 cloud;
  cloud.header = message.header;

  try
  {
    projector_.transformLaserScanToPointCloud(message.header.frame_id, message, cloud, *tf_);
  }
  catch (tf2::TransformException &ex)
  {
    ROS_WARN("TF transform exception to frame %s: %s", global_frame_.c_str(), ex.what());
    projector_.projectLaser(message, cloud);
  }
  catch (std::runtime_error &ex)
  {
    ROS_WARN("Laser scan transform error: %s", ex.what());
    return;
  }

  buffer->lock();
  buffer->bufferCloud(cloud);
  buffer->unlock();
}

void ObstacleLayer::updateBounds(double robot_x, double robot_y, double robot_yaw,
                                  double* min_x, double* min_y, double* max_x, double* max_y)
{
  if (rolling_window_)
    updateOrigin(robot_x - getSizeInMetersX() / 2, robot_y - getSizeInMetersY() / 2);

  useExtraBounds(min_x, min_y, max_x, max_y);

  bool current = true;
  std::vector<Observation> observations, clearing_observations;

  current = current && getMarkingObservations(observations);
  current = current && getClearingObservations(clearing_observations);
  current_ = current;

  for (unsigned int i = 0; i < clearing_observations.size(); ++i)
  {
    raytraceFreespace(clearing_observations[i], min_x, min_y, max_x, max_y);
  }

  for (std::vector<Observation>::const_iterator it = observations.begin(); it != observations.end(); ++it)
  {
    const Observation& obs = *it;
    const PointCloud& cloud = *(obs.cloud_);
    double sq_obstacle_range = obs.obstacle_range_ * obs.obstacle_range_;

    for (PointCloud::const_iterator it = cloud.begin(); it != cloud.end(); ++it)
    {
      double px = it->x, py = it->y, pz = it->z;

      if (pz > max_obstacle_height_)
        continue;

      double sq_dist = (px - obs.origin_.x) * (px - obs.origin_.x) +
                       (py - obs.origin_.y) * (py - obs.origin_.y) +
                       (pz - obs.origin_.z) * (pz - obs.origin_.z);

      if (sq_dist >= sq_obstacle_range)
        continue;

      unsigned int mx, my;
      if (!worldToMap(px, py, mx, my))
        continue;

      unsigned int index = getIndex(mx, my);
      costmap_[index] = LETHAL_OBSTACLE;

      touch(px, py, min_x, min_y, max_x, max_y);
    }
  }

  updateFootprint(robot_x, robot_y, robot_yaw, min_x, min_y, max_x, max_y);
}

void ObstacleLayer::updateFootprint(double robot_x, double robot_y, double robot_yaw,
                                     double* min_x, double* min_y, double* max_x, double* max_y)
{
  if (!footprint_clearing_enabled_) return;

  transformFootprint(robot_x, robot_y, robot_yaw, getFootprint(), transformed_footprint_);

  for (unsigned int i = 0; i < transformed_footprint_.size(); i++)
  {
    touch(transformed_footprint_[i].x, transformed_footprint_[i].y, min_x, min_y, max_x, max_y);
  }
}

void ObstacleLayer::updateCosts(costmap_2d::Costmap2D& master_grid, int min_i, int min_j,
                                 int max_i, int max_j)
{
  if (footprint_clearing_enabled_)
  {
    setConvexPolygonCost(transformed_footprint_, costmap_2d::FREE_SPACE);
  }

  switch (combination_method_)
  {
    case 0:
      updateWithOverwrite(master_grid, min_i, min_j, max_i, max_j);
      break;
    case 1:
      updateWithMax(master_grid, min_i, min_j, max_i, max_j);
      break;
    default:
      break;
  }
}

void ObstacleLayer::addStaticObservation(costmap_2d::Observation& obs, bool marking, bool clearing)
{
  if (marking)
    static_marking_observations_.push_back(obs);
  if (clearing)
    static_clearing_observations_.push_back(obs);
}

void ObstacleLayer::clearStaticObservations(bool marking, bool clearing)
{
  if (marking)
    static_marking_observations_.clear();
  if (clearing)
    static_clearing_observations_.clear();
}

bool ObstacleLayer::getMarkingObservations(std::vector<Observation>& marking_observations) const
{
  bool current = true;
  for (std::vector<boost::shared_ptr<ObservationBuffer>>::const_iterator it = marking_buffers_.begin();
       it != marking_buffers_.end(); ++it)
  {
    (*it)->getObservations(marking_observations);
    current = current && (*it)->isCurrent();
  }

  for (std::vector<Observation>::const_iterator it = static_marking_observations_.begin();
       it != static_marking_observations_.end(); ++it)
  {
    marking_observations.push_back(*it);
  }

  return current;
}

bool ObstacleLayer::getClearingObservations(std::vector<Observation>& clearing_observations) const
{
  bool current = true;
  for (std::vector<boost::shared_ptr<ObservationBuffer>>::const_iterator it = clearing_buffers_.begin();
       it != clearing_buffers_.end(); ++it)
  {
    (*it)->getObservations(clearing_observations);
    current = current && (*it)->isCurrent();
  }

  for (std::vector<Observation>::const_iterator it = static_clearing_observations_.begin();
       it != static_clearing_observations_.end(); ++it)
  {
    clearing_observations.push_back(*it);
  }

  return current;
}

void ObstacleLayer::raytraceFreespace(const Observation& clearing_observation, double* min_x,
                                       double* min_y, double* max_x, double* max_y)
{
  const PointCloud& cloud = *(clearing_observation.cloud_);
  double ox = clearing_observation.origin_.x, oy = clearing_observation.origin_.y;

  for (PointCloud::const_iterator it = cloud.begin(); it != cloud.end(); ++it)
  {
    double wx = it->x, wy = it->y;

    unsigned int x0, y0, x1, y1;
    if (!worldToMap(ox, oy, x0, y0))
      continue;

    if (!worldToMap(wx, wy, x1, y1))
      continue;

    raytraceLine(x0, y0, x1, y1);

    touch(wx, wy, min_x, min_y, max_x, max_y);
  }

  touch(ox, oy, min_x, min_y, max_x, max_y);
}

void ObstacleLayer::raytraceLine(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1)
{
  int dx = abs((int)x1 - (int)x0);
  int dy = abs((int)y1 - (int)y0);

  int sx = x0 < x1 ? 1 : -1;
  int sy = y0 < y1 ? 1 : -1;

  int err = dx - dy;
  int x = x0, y = y0;

  unsigned int size_x = getSizeInCellsX(), size_y = getSizeInCellsY();

  while (true)
  {
    if (x >= size_x || y >= size_y)
      return;

    unsigned int index = getIndex(x, y);
    if (costmap_[index] == NO_INFORMATION)
      break;

    costmap_[index] = FREE_SPACE;

    if (x == x1 && y == y1)
      break;

    int e2 = 2 * err;
    if (e2 > -dy)
    {
      err -= dy;
      x += sx;
    }
    if (e2 < dx)
    {
      err += dx;
      y += sy;
    }
  }
}

}  // namespace costmap_2d
