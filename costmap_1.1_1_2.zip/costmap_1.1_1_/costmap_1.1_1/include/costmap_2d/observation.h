/**
 * @file observation.h
 * @brief 观测数据类头文件 - 存储传感器观测信息
 *
 * Observation 类是障碍物层（ObstacleLayer）中用于存储传感器观测数据的核心数据结构。
 * 它封装了一次传感器测量的完整信息，包括：
 * 1. 传感器原点位置（传感器在全局坐标系中的坐标）
 * 2. 点云数据（传感器检测到的所有点）
 * 3. 障碍物检测范围（用于标记障碍物的最大距离）
 * 4. 射线追踪范围（用于清除自由空间的最大距离）
 *
 * 该类被 ObservationBuffer 用于缓存和管理多个传感器的观测数据。
 *
 * @author ROS Navigation Stack contributors
 */

#ifndef COSTMAP_2D_OBSERVATION_H_
#define COSTMAP_2D_OBSERVATION_H_

#include <costmap_2d/costmap_2d.h>
#include <costmap_2d/point_cloud.h>
#include <memory>

namespace costmap_2d
{

/**
 * @class Observation
 * @brief 观测数据类 - 封装单次传感器观测的所有信息
 *
 * 该类用于存储从激光雷达、点云等传感器获取的观测数据，是障碍物检测和自由空间清除的基础数据结构。
 * 
 * @note 使用智能指针管理点云数据，避免内存泄漏。
 */
class Observation
{
public:
  /**
   * @brief 默认构造函数 - 创建一个空的观测对象
   * 
   * 初始化点云指针为空，障碍物范围和射线追踪范围均为 0。
   */
  Observation() :
    cloud_(new PointCloud()), obstacle_range_(0.0), raytrace_range_(0.0)
  {
  }

  /**
   * @brief 析构函数
   * 
   * 释放点云数据占用的内存。
   */
  virtual ~Observation()
  {
    delete cloud_;
  }

  /**
   * @brief 构造函数 - 从原点和点云创建观测对象
   * 
   * @param origin 传感器原点位置（全局坐标系）
   * @param cloud 点云数据（传感器检测到的点集合）
   * @param obstacle_range 障碍物检测范围（米）- 超过此范围的点不标记为障碍物
   * @param raytrace_range 射线追踪范围（米）- 超过此范围不进行自由空间清除
   */
  Observation(Point& origin, const PointCloud &cloud,
              double obstacle_range, double raytrace_range) :
      origin_(origin), cloud_(new PointCloud(cloud)),
      obstacle_range_(obstacle_range), raytrace_range_(raytrace_range)
  {
  }

  /**
   * @brief 拷贝构造函数
   * 
   * 深拷贝观测对象，确保点云数据独立。
   * 
   * @param obs 要拷贝的观测对象
   */
  Observation(const Observation& obs) :
      origin_(obs.origin_), cloud_(new PointCloud(*(obs.cloud_))),
      obstacle_range_(obs.obstacle_range_), raytrace_range_(obs.raytrace_range_)
  {
  }

  /**
   * @brief 构造函数 - 从点云创建观测对象（简化版本）
   * 
   * 适用于只关心障碍物检测，不关心射线追踪的场景。
   * 
   * @param cloud 点云数据
   * @param obstacle_range 障碍物检测范围（米）
   */
  Observation(const PointCloud &cloud, double obstacle_range) :
      cloud_(new PointCloud(cloud)), obstacle_range_(obstacle_range), raytrace_range_(0.0)
  {
  }

  // ===== 成员变量 =====
  Point origin_;           ///< 传感器原点位置（全局坐标系）
  PointCloud* cloud_;      ///< 点云数据指针（动态分配）
  double obstacle_range_;  ///< 障碍物检测范围（米）
  double raytrace_range_;  ///< 射线追踪范围（米）
};

}  // namespace costmap_2d

#endif  // COSTMAP_2D_OBSERVATION_H_