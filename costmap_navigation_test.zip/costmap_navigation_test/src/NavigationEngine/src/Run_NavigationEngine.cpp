#include <ros/ros.h>
#include <nav_msgs/OccupancyGrid.h>
#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <costmap_2d/lock_free_queue.h>
#include <costmap_2d/costmap_interface.h>
#include "NavigationEngine.h"

void mapCallback(const nav_msgs::OccupancyGrid::ConstPtr& msg)
{
    costmapNS::OccupancyGridData grid_data;
    grid_data.setGridInfo(msg->info.width, msg->info.height,
                          msg->info.resolution,
                          msg->info.origin.position.x,
                          msg->info.origin.position.y);
    grid_data.setFrameId(msg->header.frame_id);
    
    for (size_t i = 0; i < msg->data.size(); ++i)
    {
        grid_data[i] = msg->data[i];
    }
    
    costmapNS::OccupancyGridDataQueue.push(grid_data);
    
    static int count = 0;
    if (++count % 10 == 0)
    {
        ROS_INFO("[mapCallback] Pushed map data, size: %dx%d", 
                 msg->info.width, msg->info.height);
    }
}

void laserScanCallback(const sensor_msgs::LaserScan::ConstPtr& msg)
{
    costmapNS::LaserScanData scan;
    scan.angle_min_ = msg->angle_min;
    scan.angle_max_ = msg->angle_max;
    scan.angle_increment_ = msg->angle_increment;
    scan.range_min_ = msg->range_min;
    scan.range_max_ = msg->range_max;
    scan.timestamp_ns_ = static_cast<uint64_t>(msg->header.stamp.sec) * 1000000000ULL + 
                         static_cast<uint64_t>(msg->header.stamp.nsec);
    scan.frame_id_ = msg->header.frame_id;
    scan.ranges_.resize(msg->ranges.size());
    for (size_t i = 0; i < msg->ranges.size(); ++i)
    {
        scan.ranges_[i] = msg->ranges[i];
    }
    
    costmapNS::LaserScanDataQueue.push(scan);
}

void poseCallback(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& msg)
{
    costmapNS::RobotPose pose;
    pose.x_ = msg->pose.pose.position.x;
    pose.y_ = msg->pose.pose.position.y;
    
    double qx = msg->pose.pose.orientation.x;
    double qy = msg->pose.pose.orientation.y;
    double qz = msg->pose.pose.orientation.z;
    double qw = msg->pose.pose.orientation.w;
    pose.theta_ = atan2(2.0 * (qw * qz + qx * qy), 1.0 - 2.0 * (qy * qy + qz * qz));
    
    pose.timestamp_ns_ = static_cast<uint64_t>(msg->header.stamp.sec) * 1000000000ULL + 
                         static_cast<uint64_t>(msg->header.stamp.nsec);
    
    costmapNS::PoseStampedQueue.push(pose);
}

nav_msgs::OccupancyGrid toRosOccupancyGrid(const costmapNS::OccupancyGridMsg& msg)
{
    nav_msgs::OccupancyGrid ros_msg;
    
    ros_msg.header.stamp = ros::Time::now();
    ros_msg.header.frame_id = msg.header_frame;
    
    ros_msg.info.resolution = msg.resolution;
    ros_msg.info.width = msg.width;
    ros_msg.info.height = msg.height;
    ros_msg.info.origin.position.x = msg.origin_x;
    ros_msg.info.origin.position.y = msg.origin_y;
    ros_msg.info.origin.position.z = 0.0;
    ros_msg.info.origin.orientation.w = 1.0;
    
    ros_msg.data = msg.data;
    
    return ros_msg;
}

int main(int argc, char** argv){
    ros::init(argc, argv, "navigation_engine_node");
    ros::NodeHandle nh;
    
    ROS_INFO("========================================");
    ROS_INFO("  Navigation Engine Node");
    ROS_INFO("========================================");
    
    ros::Subscriber map_sub = nh.subscribe("/map", 10, mapCallback);
    ros::Subscriber laser_sub = nh.subscribe("/scan", 10, laserScanCallback);
    ros::Subscriber pose_sub = nh.subscribe("/amcl_pose", 10, poseCallback);
    
    ROS_INFO("[Subscriber] 订阅话题: /map, /scan, /amcl_pose");
    
    ros::Publisher global_costmap_pub = nh.advertise<nav_msgs::OccupancyGrid>("/global_costmap_zy", 1, true);
    ros::Publisher local_costmap_pub = nh.advertise<nav_msgs::OccupancyGrid>("/local_costmap_zy", 1, true);
    
    ROS_INFO("[Publisher] 发布话题: /global_costmap_zy, /local_costmap_zy");
    
    navigation_engine::NavigationEngine engine;
    
    ROS_INFO("[NavigationEngine] Initializing...");
    if (!engine.initialize())
    {
        ROS_ERROR("[NavigationEngine] Failed to initialize");
        return -1;
    }
    
    ROS_INFO("[NavigationEngine] Starting...");
    engine.start();
    
    ROS_INFO("[NavigationEngine] ========== 开始处理 ==========");
    
    ros::Rate rate(10);
    int update_count = 0;
    
    while (ros::ok())
    {
        ros::spinOnce();
        
        costmapNS::costmap_interface* global_interface = engine.getGlobalCostmapInterface();
        costmapNS::costmap_interface* local_interface = engine.getLocalCostmapInterface();
        
        if (global_interface)
        {
            costmapNS::OccupancyGridMsg global_msg = global_interface->generateCostmapMsg();
            if (!global_msg.data.empty())
            {
                global_costmap_pub.publish(toRosOccupancyGrid(global_msg));
            }
            
            costmapNS::LayeredCostmap* global_layered = global_interface->getLayeredCostmap();
            if (global_layered && global_layered->getCostmap() && ++update_count % 50 == 0)
            {
                costmapNS::Costmap2D* g_costmap = global_layered->getCostmap();
                ROS_INFO("[Demo] 全局地图: %dx%d, 分辨率: %.3f, 原点: (%.2f, %.2f)",
                         g_costmap->getSizeInCellsX(), g_costmap->getSizeInCellsY(),
                         g_costmap->getResolution(),
                         g_costmap->getOriginX(), g_costmap->getOriginY());
            }
        }
        
        if (local_interface)
        {
            costmapNS::OccupancyGridMsg local_msg = local_interface->generateCostmapMsg();
            if (!local_msg.data.empty())
            {
                local_costmap_pub.publish(toRosOccupancyGrid(local_msg));
            }
            
            costmapNS::LayeredCostmap* local_layered = local_interface->getLayeredCostmap();
            if (local_layered && local_layered->getCostmap() && update_count % 50 == 0)
            {
                costmapNS::Costmap2D* l_costmap = local_layered->getCostmap();
                ROS_INFO("[Demo] 局部地图: %dx%d, 分辨率: %.3f, 原点: (%.2f, %.2f)",
                         l_costmap->getSizeInCellsX(), l_costmap->getSizeInCellsY(),
                         l_costmap->getResolution(),
                         l_costmap->getOriginX(), l_costmap->getOriginY());
            }
        }
        
        rate.sleep();
    }
    
    ROS_INFO("[NavigationEngine] Stopping...");
    engine.stop();
    
    ROS_INFO("[NavigationEngine] 退出");
    return 0;
}