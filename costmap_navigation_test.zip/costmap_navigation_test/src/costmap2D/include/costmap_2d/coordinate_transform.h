#ifndef COSTMAP_2D_COORDINATE_TRANSFORM_H_
#define COSTMAP_2D_COORDINATE_TRANSFORM_H_

#include <string>
#include <cmath>
#include <map>
#include <memory>
#include <costmap_2d/costmap_2d.h>

namespace costmapNS
{

/**
 * @struct Quaternion
 * @brief 四元数结构体，用于表示旋转姿态
 */
struct Quaternion
{
  double x;  ///< 四元数X分量
  double y;  ///< 四元数Y分量
  double z;  ///< 四元数Z分量
  double w;  ///< 四元数W分量（实部）

  /**
   * @brief 默认构造函数 - 单位四元数
   */
  Quaternion() : x(0.0), y(0.0), z(0.0), w(1.0) {}

  /**
   * @brief 构造函数
   */
  Quaternion(double x, double y, double z, double w) : x(x), y(y), z(z), w(w) {}
};

/**
 * @struct Transform
 * @brief 坐标系变换结构，包含平移和旋转
 */
struct Transform
{
  double x;          ///< X平移（米）
  double y;          ///< Y平移（米）
  double z;          ///< Z平移（米）
  Quaternion rotation; ///< 旋转四元数

  /**
   * @brief 默认构造函数 - 恒等变换
   */
  Transform() : x(0.0), y(0.0), z(0.0), rotation() {}

  /**
   * @brief 构造函数（仅2D变换）
   */
  Transform(double x, double y, double yaw) 
    : x(x), y(y), z(0.0)
  {
    // 将Yaw角转换为四元数
    double half_yaw = yaw / 2.0;
    rotation.x = 0.0;
    rotation.y = 0.0;
    rotation.z = sin(half_yaw);
    rotation.w = cos(half_yaw);
  }

  /**
   * @brief 构造函数（完整3D变换）
   */
  Transform(double x, double y, double z, const Quaternion& rot) 
    : x(x), y(y), z(z), rotation(rot) {}
};

/**
 * @class TransformBuffer
 * @brief 坐标变换缓冲区
 * 
 * 用途：替代 tf2_ros::Buffer，用于存储和查询坐标系变换关系。
 * 
 * 核心功能：
 * 1. 存储机器人当前位姿（世界坐标）
 * 2. 存储坐标系变换关系
 * 3. 支持点的坐标变换（从一个坐标系转换到另一个坐标系）
 * 4. 支持欧拉角和四元数转换
 */
class TransformBuffer
{
public:
  /**
   * @brief 默认构造函数
   */
  TransformBuffer() 
    : robot_pose_x_(0.0), robot_pose_y_(0.0), robot_pose_theta_(0.0) 
  {}

  /**
   * @brief 更新机器人位置（2D）
   * @param x 世界坐标X（米）
   * @param y 世界坐标Y（米）
   * @param theta 航向角（弧度）
   */
  void updateRobotPose(double x, double y, double theta)
  {
    robot_pose_x_ = x;
    robot_pose_y_ = y;
    robot_pose_theta_ = theta;
  }

  /**
   * @brief 获取机器人X坐标
   */
  double getRobotX() const { return robot_pose_x_; }

  /**
   * @brief 获取机器人Y坐标
   */
  double getRobotY() const { return robot_pose_y_; }

  /**
   * @brief 获取机器人航向角
   */
  double getRobotTheta() const { return robot_pose_theta_; }

  /**
   * @brief 添加坐标系变换
   * @param parent_frame 父坐标系名称
   * @param child_frame 子坐标系名称
   * @param transform 从父到子的变换
   */
  void setTransform(const std::string& parent_frame, 
                    const std::string& child_frame, 
                    const Transform& transform)
  {
    std::string key = parent_frame + "->" + child_frame;
    transforms_[key] = transform;
  }

  /**
   * @brief 获取坐标系变换
   * @param parent_frame 父坐标系名称
   * @param child_frame 子坐标系名称
   * @param transform 输出变换
   * @return true 如果变换存在
   */
  bool lookupTransform(const std::string& parent_frame, 
                       const std::string& child_frame,
                       Transform& transform) const
  {
    std::string key = parent_frame + "->" + child_frame;
    auto it = transforms_.find(key);
    if (it != transforms_.end())
    {
      transform = it->second;
      return true;
    }
    return false;
  }

  /**
   * @brief 将点从一个坐标系变换到另一个坐标系（2D）
   * @param source_frame 源坐标系
   * @param target_frame 目标坐标系
   * @param x 源点X坐标
   * @param y 源点Y坐标
   * @param tx 变换后的X坐标
   * @param ty 变换后的Y坐标
   * @return true 如果变换成功
   */
  bool transformPoint(const std::string& source_frame,
                      const std::string& target_frame,
                      double x, double y,
                      double& tx, double& ty) const
  {
    // 简单实现：如果源和目标相同，直接返回
    if (source_frame == target_frame)
    {
      tx = x;
      ty = y;
      return true;
    }

    // 查找变换
    Transform transform;
    std::string key = source_frame + "->" + target_frame;
    auto it = transforms_.find(key);
    
    if (it != transforms_.end())
    {
      transform = it->second;
      applyTransform(x, y, transform, tx, ty);
      return true;
    }

    // 尝试反向变换
    key = target_frame + "->" + source_frame;
    it = transforms_.find(key);
    if (it != transforms_.end())
    {
      Transform inv_transform = inverseTransform(it->second);
      applyTransform(x, y, inv_transform, tx, ty);
      return true;
    }

    return false;
  }

  /**
   * @brief 将激光雷达点转换到机器人坐标系（2D）
   * @param laser_x 激光坐标系中的X坐标
   * @param laser_y 激光坐标系中的Y坐标
   * @param base_x 机器人坐标系中的X坐标（输出）
   * @param base_y 机器人坐标系中的Y坐标（输出）
   * @return true 如果变换成功
   */
  bool laserToBaseLink(double laser_x, double laser_y, 
                       double& base_x, double& base_y) const
  {
    return transformPoint("laser", "base_link", laser_x, laser_y, base_x, base_y);
  }

  /**
   * @brief 将机器人坐标系点转换到世界坐标系（2D）
   * @param base_x 机器人坐标系中的X坐标
   * @param base_y 机器人坐标系中的Y坐标
   * @param world_x 世界坐标系中的X坐标（输出）
   * @param world_y 世界坐标系中的Y坐标（输出）
   */
  void baseLinkToWorld(double base_x, double base_y,
                       double& world_x, double& world_y) const
  {
    // 机器人坐标系原点在世界坐标系中的位置是(robot_pose_x_, robot_pose_y_)
    // 机器人的航向角是robot_pose_theta_
    double cos_theta = cos(robot_pose_theta_);
    double sin_theta = sin(robot_pose_theta_);
    
    // 旋转然后平移
    world_x = base_x * cos_theta - base_y * sin_theta + robot_pose_x_;
    world_y = base_x * sin_theta + base_y * cos_theta + robot_pose_y_;
  }

  /**
   * @brief 将世界坐标系点转换到机器人坐标系（2D）
   * @param world_x 世界坐标系中的X坐标
   * @param world_y 世界坐标系中的Y坐标
   * @param base_x 机器人坐标系中的X坐标（输出）
   * @param base_y 机器人坐标系中的Y坐标（输出）
   */
  void worldToBaseLink(double world_x, double world_y,
                       double& base_x, double& base_y) const
  {
    double cos_theta = cos(robot_pose_theta_);
    double sin_theta = sin(robot_pose_theta_);
    
    // 先平移再旋转（反向变换）
    double dx = world_x - robot_pose_x_;
    double dy = world_y - robot_pose_y_;
    
    base_x = dx * cos_theta + dy * sin_theta;
    base_y = -dx * sin_theta + dy * cos_theta;
  }

  /**
   * @brief 将点从激光坐标系转换到世界坐标系（2D）
   * @param laser_x 激光坐标系中的X坐标
   * @param laser_y 激光坐标系中的Y坐标
   * @param world_x 世界坐标系中的X坐标（输出）
   * @param world_y 世界坐标系中的Y坐标（输出）
   * @return true 如果变换成功
   */
  bool laserToWorld(double laser_x, double laser_y,
                    double& world_x, double& world_y) const
  {
    double base_x, base_y;
    if (!laserToBaseLink(laser_x, laser_y, base_x, base_y))
      return false;
    
    baseLinkToWorld(base_x, base_y, world_x, world_y);
    return true;
  }

  /**
   * @brief 欧拉角转四元数
   * @param roll 横滚角（弧度）
   * @param pitch 俯仰角（弧度）
   * @param yaw 航向角（弧度）
   * @return 四元数
   */
  static Quaternion eulerToQuaternion(double roll, double pitch, double yaw)
  {
    double cr = cos(roll / 2.0);
    double sr = sin(roll / 2.0);
    double cp = cos(pitch / 2.0);
    double sp = sin(pitch / 2.0);
    double cy = cos(yaw / 2.0);
    double sy = sin(yaw / 2.0);

    Quaternion q;
    q.w = cr * cp * cy + sr * sp * sy;
    q.x = sr * cp * cy - cr * sp * sy;
    q.y = cr * sp * cy + sr * cp * sy;
    q.z = cr * cp * sy - sr * sp * cy;
    return q;
  }

  /**
   * @brief 四元数转欧拉角
   * @param q 四元数
   * @param roll 横滚角（输出）
   * @param pitch 俯仰角（输出）
   * @param yaw 航向角（输出）
   */
  static void quaternionToEuler(const Quaternion& q, 
                                double& roll, double& pitch, double& yaw)
  {
    // Roll (x-axis rotation)
    double sinr_cosp = 2.0 * (q.w * q.x + q.y * q.z);
    double cosr_cosp = 1.0 - 2.0 * (q.x * q.x + q.y * q.y);
    roll = atan2(sinr_cosp, cosr_cosp);

    // Pitch (y-axis rotation)
    double sinp = 2.0 * (q.w * q.y - q.z * q.x);
    if (fabs(sinp) >= 1.0)
      pitch = copysign(M_PI / 2.0, sinp);
    else
      pitch = asin(sinp);

    // Yaw (z-axis rotation)
    double siny_cosp = 2.0 * (q.w * q.z + q.x * q.y);
    double cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z);
    yaw = atan2(siny_cosp, cosy_cosp);
  }

  /**
   * @brief 获取变换数量
   */
  size_t getTransformCount() const { return transforms_.size(); }

  /**
   * @brief 清空所有变换
   */
  void clear() { transforms_.clear(); }

private:
  /**
   * @brief 应用2D变换
   */
  void applyTransform(double x, double y, const Transform& transform,
                      double& tx, double& ty) const
  {
    // 提取Yaw角
    double roll, pitch, yaw;
    quaternionToEuler(transform.rotation, roll, pitch, yaw);
    
    double cos_yaw = cos(yaw);
    double sin_yaw = sin(yaw);
    
    // 先旋转再平移
    tx = x * cos_yaw - y * sin_yaw + transform.x;
    ty = x * sin_yaw + y * cos_yaw + transform.y;
  }

  /**
   * @brief 求逆变换
   */
  Transform inverseTransform(const Transform& transform) const
  {
    Transform inv;
    
    // 提取Yaw角
    double roll, pitch, yaw;
    quaternionToEuler(transform.rotation, roll, pitch, yaw);
    
    // 逆旋转
    double cos_yaw = cos(-yaw);
    double sin_yaw = sin(-yaw);
    
    // 逆平移 = -R^T * t
    inv.x = -(transform.x * cos_yaw - transform.y * sin_yaw);
    inv.y = -(transform.x * sin_yaw + transform.y * cos_yaw);
    inv.z = -transform.z;
    
    // 逆旋转四元数（共轭）
    inv.rotation.x = -transform.rotation.x;
    inv.rotation.y = -transform.rotation.y;
    inv.rotation.z = -transform.rotation.z;
    inv.rotation.w = transform.rotation.w;
    
    return inv;
  }

  double robot_pose_x_;       ///< 机器人当前位置X（世界坐标，米）
  double robot_pose_y_;       ///< 机器人当前位置Y（世界坐标，米）
  double robot_pose_theta_;   ///< 机器人当前航向角（弧度）
  
  std::map<std::string, Transform> transforms_;  ///< 坐标系变换缓存
};

}  // namespace costmapNS

#endif  // COSTMAP_2D_COORDINATE_TRANSFORM_H_