#ifndef COSTMAP_2D_LAYER_H_
#define COSTMAP_2D_LAYER_H_

#include <costmap_2d/costmap_2d.h>
#include <costmap_2d/layered_costmap.h>
#include <string>
#include <costmap_2d/coordinate_transform.h>

namespace costmapNS
{

// 前置声明：分层代价地图
class LayeredCostmap;

/**
 * @class Layer
 * @brief 代价地图图层抽象基类
 * 
 * 这是 ROS 导航栈中代价地图的核心抽象层，所有具体图层（StaticLayer、ObstacleLayer、
 * InflationLayer 等）都继承自此类。采用插件化架构，通过 virtual 接口实现多态。
 * 
 * 核心设计思想（来自论文 "Layered Costmaps for Context-Sensitive Navigation"）：
 * 1. 将代价地图分解为多个独立图层
 * 2. 每个图层负责处理特定类型的信息
 * 3. 图层按顺序融合到主代价地图
 * 
 * 图层更新流程：
 * 1. LayeredCostmap 调用 updateBounds() 收集所有图层的更新边界
 * 2. LayeredCostmap 调用 updateCosts() 将图层数据融合到主地图
 */
class Layer
{
public:
  /**
   * @brief 默认构造函数
   */
  Layer();

  /**
   * @brief 初始化图层
   * 
   * 由 LayeredCostmap 调用，完成图层的基础初始化。
   * 此函数会设置 tf_、name_、layered_costmap_，然后调用 onInitialize()。
   * 
   * @param parent 父分层代价地图指针
   * @param name 图层名称（用于命名空间）
   * @param tf TF坐标变换缓冲区
   */
  void initialize(LayeredCostmap* parent, std::string name, TransformBuffer *tf);

  /**
   * @brief 更新边界（核心虚函数）
   * 
   * 由 LayeredCostmap 调用，用于计算此图层需要更新的区域边界。
   * 每个图层可以扩大边界范围，最终取所有图层的并集。
   * 
   * @param robot_x 机器人X坐标（世界坐标）
   * @param robot_y 机器人Y坐标（世界坐标）
   * @param robot_yaw 机器人航向角（弧度）
   * @param min_x 输出：最小X边界（可扩大）
   * @param min_y 输出：最小Y边界（可扩大）
   * @param max_x 输出：最大X边界（可扩大）
   * @param max_y 输出：最大Y边界（可扩大）
   */
  virtual void updateBounds(double robot_x, double robot_y, double robot_yaw, double* min_x, double* min_y,
                            double* max_x, double* max_y) {}

  /**
   * @brief 更新代价（核心虚函数）
   * 
   * 由 LayeredCostmap 调用，将此图层的数据融合到主代价地图。
   * 只在 updateBounds() 计算的边界范围内进行更新。
   * 
   * @param master_grid 主代价地图
   * @param min_i 更新区域最小列索引
   * @param min_j 更新区域最小行索引
   * @param max_i 更新区域最大列索引
   * @param max_j 更新区域最大行索引
   */
  virtual void updateCosts(Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j) {}

  /**
   * @brief 停用图层
   * 
   * 停止发布器、关闭订阅器等清理操作。
   */
  virtual void deactivate() {}

  /**
   * @brief 激活图层
   * 
   * 重新启动发布器、订阅器等初始化操作。
   */
  virtual void activate() {}

  /**
   * @brief 重置图层
   * 
   * 将图层恢复到初始状态。
   */
  virtual void reset() {}

  /**
   * @brief 析构函数
   */
  virtual ~Layer() {}

  /**
   * @brief 检查图层数据是否最新
   * 
   * 如果图层数据不是最新的，规划器可能需要等待或使用旧数据。
   * 子类应通过设置 current_ 成员变量来管理状态。
   * 
   * @return 数据是否最新
   */
  bool isCurrent() const
  {
    return current_;
  }

  /**
   * @brief 检查图层是否启用
   * 
   * 用户可通过动态重配置启用/禁用图层。
   * 禁用的图层不会收到 updateCosts()、updateBounds()、isCurrent() 调用。
   * 但 activate()、deactivate()、reset() 仍会被调用。
   * 
   * @return 图层是否启用
   */
  inline bool isEnabled() const noexcept
  {
    return enabled_;
  }

  /**
   * @brief 设置图层启用状态
   * 
   * @param enabled 是否启用图层
   */
  inline void setEnabled(bool enabled) noexcept
  {
    enabled_ = enabled;
  }

  /**
   * @brief 获取图层名称
   * 
   * @return 图层名称
   */
  inline const std::string& getName() const noexcept
  {
    return name_;
  }

  /**
   * @brief 匹配父代价地图尺寸
   * 
   * 当父代价地图尺寸改变时，LayeredCostmap 调用此函数。
   * 子类应实现此函数以同步尺寸。
   */
  virtual void matchSize() {}

  /**
   * @brief 足迹变化回调
   * 
   * 当机器人足迹改变时（通过 LayeredCostmap::setFootprint()），
   * LayeredCostmap 调用此函数。子类可覆盖此函数以响应足迹变化。
   */
  virtual void onFootprintChanged() {}

  /**
   * @brief 获取机器人足迹（便捷函数）
   * 
   * 等价于 layered_costmap_->getFootprint()
   * 
   * @return 机器人足迹多边形
   */
  const std::vector<Point>& getFootprint() const;

protected:
  /**
   * @brief 子类初始化（虚函数）
   * 
   * 在 initialize() 末尾调用。此时 tf_、name_、layered_costmap_ 已设置。
   * 子类应在此实现特定的初始化逻辑。
   */
  virtual void onInitialize() {}

  /**
   * @brief 父分层代价地图指针
   * 
   * 用于访问父地图的属性（如尺寸、分辨率、原点、TF等）。
   */
  LayeredCostmap* layered_costmap_;

  /**
   * @brief 数据是否最新标志
   * 
   * 子类应在数据更新时设置为 true，数据过期时设置为 false。
   */
  bool current_;

  /**
   * @brief 图层是否启用标志
   * 
   * 通过动态重配置控制，禁用的图层不会参与代价地图更新。
   */
  bool enabled_;

  /**
   * @brief 图层名称
   * 
   * 用于 ROS 参数命名空间（如 ~/global_costmap/static_layer）。
   */
  std::string name_;

  /**
   * @brief 坐标变换缓冲区
   *
   * 用于坐标系转换。实际类型为 TransformBuffer。
   */
  TransformBuffer *tf_;

private:
  /**
   * @brief 机器人足迹缓存
   * 
   * 用于优化 getFootprint() 调用。
   */
  std::vector<Point> footprint_spec_;
};

}  // namespace costmapNS

#endif  // COSTMAP_2D_LAYER_H_
