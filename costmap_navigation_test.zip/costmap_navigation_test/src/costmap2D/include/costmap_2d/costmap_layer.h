#ifndef COSTMAP_2D_COSTMAP_LAYER_H_
#define COSTMAP_2D_COSTMAP_LAYER_H_

/**
 * @file costmap_layer.h
 * @brief 代价地图图层实现基类
 * 
 * CostmapLayer 继承自 Layer（图层接口）和 Costmap2D（代价地图数据结构），
 * 提供了图层间代价融合的核心算法和边界管理机制。
 */

#include <costmap_2d/layer.h>
#include <costmap_2d/layered_costmap.h>

namespace costmapNS
{

/**
 * @class CostmapLayer
 * @brief 代价地图图层实现基类
 * 
 * 双重继承设计：
 * - Layer: 提供图层接口（updateBounds, updateCosts 等）
 * - Costmap2D: 提供代价地图数据存储和坐标转换能力
 * 
 * 主要功能：
 * 1. 提供四种代价融合策略
 * 2. 支持扩展边界管理
 * 3. 实现尺寸同步机制
 * 
 * 子类包括：StaticLayer, ObstacleLayer, InflationLayer
 */
class CostmapLayer : public Layer, public Costmap2D
{
public:
  /**
   * @brief 构造函数
   * 
   * 初始化扩展边界为无效值：
   * - extra_min_x_ = 1e6（极大值）
   * - extra_max_x_ = -1e6（极小值）
   * - extra_min_y_ = 1e6（极大值）
   * - extra_max_y_ = -1e6（极小值）
   */
  CostmapLayer() : has_extra_bounds_(false),
    extra_min_x_(1e6), extra_max_x_(-1e6),
    extra_min_y_(1e6), extra_max_y_(-1e6) {}

  /**
   * @brief 判断图层是否离散化
   * 
   * CostmapLayer 基于栅格化代价地图，因此返回 true。
   * 
   * @return true（始终离散化）
   */
  bool isDiscretized()
  {
    return true;
  }

  /**
   * @brief 匹配父地图尺寸
   * 
   * 将此图层的尺寸、分辨率、原点与父 LayeredCostmap 同步。
   * 由 LayeredCostmap 在尺寸变化时调用。
   */
  virtual void matchSize();

  /**
   * @brief 清除指定区域的代价
   * 
   * 将指定矩形区域内的代价重置为默认值（NO_INFORMATION）。
   * 
   * @param start_x 起始 X 坐标（地图坐标）
   * @param start_y 起始 Y 坐标（地图坐标）
   * @param end_x 结束 X 坐标（地图坐标）
   * @param end_y 结束 Y 坐标（地图坐标）
   * @param invert_area 是否反转区域（默认 false）
   */
  virtual void clearArea(int start_x, int start_y, int end_x, int end_y, bool invert_area=false);

  /**
   * @brief 添加扩展边界
   * 
   * 如果外部源修改了代价地图中的某些区域，应调用此方法确保这些区域被包含在更新范围内。
   * 
   * @param mx0 边界框最小 X 值（世界坐标，米）
   * @param my0 边界框最小 Y 值（世界坐标，米）
   * @param mx1 边界框最大 X 值（世界坐标，米）
   * @param my1 边界框最大 Y 值（世界坐标，米）
   */
  void addExtraBounds(double mx0, double my0, double mx1, double my1);

protected:
  /**
   * @brief 无条件覆盖更新
   * 
   * 将本图层指定区域的所有值（包括 NO_INFORMATION）写入主地图。
   * 
   * @param master_grid 主代价地图
   * @param min_i 区域最小列索引
   * @param min_j 区域最小行索引
   * @param max_i 区域最大列索引
   * @param max_j 区域最大行索引
   */
  void updateWithTrueOverwrite(costmapNS::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);

  /**
   * @brief 有条件覆盖更新
   * 
   * 将本图层指定区域的有效值（不包括 NO_INFORMATION）写入主地图。
   * 
   * @param master_grid 主代价地图
   * @param min_i 区域最小列索引
   * @param min_j 区域最小行索引
   * @param max_i 区域最大列索引
   * @param max_j 区域最大行索引
   */
  void updateWithOverwrite(costmapNS::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);

  /**
   * @brief 最大值融合更新
   * 
   * 将主地图值与本图层值取最大值进行融合：
   * - 如果主地图值为 NO_INFORMATION，则用图层值覆盖
   * - 如果图层值为 NO_INFORMATION，则保持主地图值不变
   * - 否则取两者中的较大值
   * 
   * @param master_grid 主代价地图
   * @param min_i 区域最小列索引
   * @param min_j 区域最小行索引
   * @param max_i 区域最大列索引
   * @param max_j 区域最大行索引
   */
  void updateWithMax(costmapNS::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);

  /**
   * @brief 加法融合更新
   * 
   * 将主地图值与本图层值相加进行融合：
   * - 如果主地图值为 NO_INFORMATION，则用图层值覆盖
   * - 如果图层值为 NO_INFORMATION，则保持主地图值不变
   * - 如果相加大于 INSCRIBED_INFLATED_OBSTACLE，则设为 INSCRIBED_INFLATED_OBSTACLE - 1
   * 
   * @param master_grid 主代价地图
   * @param min_i 区域最小列索引
   * @param min_j 区域最小行索引
   * @param max_i 区域最大列索引
   * @param max_j 区域最大行索引
   */
  void updateWithAddition(costmapNS::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);

  /**
   * @brief 触摸检测（扩展边界框）
   * 
   * 将指定点 (x,y) 添加到边界框中，动态扩展更新区域。
   * 
   * @param x X 坐标（世界坐标，米）
   * @param y Y 坐标（世界坐标，米）
   * @param min_x 边界框最小 X（输入/输出）
   * @param min_y 边界框最小 Y（输入/输出）
   * @param max_x 边界框最大 X（输入/输出）
   * @param max_y 边界框最大 Y（输入/输出）
   */
  void touch(double x, double y, double* min_x, double* min_y, double* max_x, double* max_y);

  /**
   * @brief 使用扩展边界
   * 
   * 将 addExtraBounds() 设置的扩展边界合并到当前边界框中。
   * 应在 updateBounds() 方法开始时调用。
   * 
   * @param min_x 边界框最小 X（输入/输出）
   * @param min_y 边界框最小 Y（输入/输出）
   * @param max_x 边界框最大 X（输入/输出）
   * @param max_y 边界框最大 Y（输入/输出）
   */
  void useExtraBounds(double* min_x, double* min_y, double* max_x, double* max_y);

  bool has_extra_bounds_;  ///< 是否存在扩展边界

private:
  double extra_min_x_;  ///< 扩展边界最小 X 值（世界坐标，米）
  double extra_max_x_;  ///< 扩展边界最大 X 值（世界坐标，米）
  double extra_min_y_;  ///< 扩展边界最小 Y 值（世界坐标，米）
  double extra_max_y_;  ///< 扩展边界最大 Y 值（世界坐标，米）
};

}  // namespace costmapNS
#endif  // COSTMAP_2D_COSTMAP_LAYER_H_