#ifndef COSTMAP_2D_FOOTPRINT_H
#define COSTMAP_2D_FOOTPRINT_H

#include <costmap_2d/costmap_math.h>
#include <vector>

namespace costmapNS
{

/**
 * @brief 计算足迹多边形的内切圆和外接圆半径
 *
 * 内切圆半径：机器人中心到足迹边缘的最小距离（用于局部路径规划）
 * 外接圆半径：机器人中心到足迹边缘的最大距离（用于全局路径规划）
 *
 * 算法：
 * 1. 遍历足迹的每个顶点和每条边
 * 2. 计算机器人中心(0,0)到每个顶点的距离
 * 3. 计算机器人中心到每条边的垂直距离
 * 4. 最小距离即为内切圆半径，最大距离即为外接圆半径
 *
 * @param footprint 足迹多边形（相对于机器人中心的局部坐标）
 * @param min_dist 输出参数：内切圆半径
 * @param max_dist 输出参数：外接圆半径
 */
void calculateMinAndMaxDistances(const std::vector<Point>& footprint,
                                 double& min_dist, double& max_dist);

/**
 * @brief 根据机器人位姿计算世界坐标系下的足迹
 *
 * 使用旋转变换将机器人局部坐标系下的足迹转换到世界坐标系
 *
 * 变换公式：
 * x' = x + cos(theta) * x_local - sin(theta) * y_local
 * y' = y + sin(theta) * x_local + cos(theta) * y_local
 *
 * @param x 机器人X坐标（世界坐标，米）
 * @param y 机器人Y坐标（世界坐标，米）
 * @param theta 机器人航向角（弧度）
 * @param footprint_spec 足迹原型（机器人局部坐标）
 * @param oriented_footprint 输出：世界坐标系下的足迹
 */
void transformFootprint(double x, double y, double theta, const std::vector<Point>& footprint_spec,
                        std::vector<Point>& oriented_footprint);

/**
 * @brief 为足迹添加padding（就地修改）
 *
 * 沿每个点的方向向外扩展指定的padding距离
 *
 * @param footprint 要修改的足迹（输入/输出）
 * @param padding 扩展距离（米）
 */
void padFootprint(std::vector<Point>& footprint, double padding);

/**
 * @brief 从半径创建圆形足迹
 *
 * 使用16个点近似表示圆形
 *
 * @param radius 圆的半径（米）
 * @return 圆形足迹的点向量
 */
std::vector<Point> makeFootprintFromRadius(double radius);

}  // namespace costmapNS

#endif  // COSTMAP_2D_FOOTPRINT_H