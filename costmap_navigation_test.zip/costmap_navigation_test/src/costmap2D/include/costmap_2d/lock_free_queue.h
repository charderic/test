#ifndef COSTMAP_2D_LOCK_FREE_QUEUE_H_
#define COSTMAP_2D_LOCK_FREE_QUEUE_H_

#include <atomic>
#include <memory>
#include <costmap_2d/static_layer.h>
#include <costmap_2d/obstacle_layer.h>

namespace costmapNS
{

template<typename T>
class LockFreeQueue
{
private:
    struct Node
    {
        T data;
        std::atomic<Node*> next;
        
        Node(const T& val) : data(val), next(nullptr) {}
        Node(T&& val) : data(std::move(val)), next(nullptr) {}
    };
    
    std::atomic<Node*> head_;
    std::atomic<Node*> tail_;
    
public:
    LockFreeQueue()
    {
        Node* dummy = new Node(T());
        head_.store(dummy);
        tail_.store(dummy);
    }
    
    ~LockFreeQueue()
    {
        while (Node* node = head_.load())
        {
            head_.store(node->next.load());
            delete node;
        }
    }
    
    void push(const T& data)
    {
        Node* new_node = new Node(data);
        Node* old_tail = tail_.load();
        
        while (true)
        {
            Node* next = old_tail->next.load();
            if (next != nullptr)
            {
                tail_.compare_exchange_weak(old_tail, next);
                continue;
            }
            
            if (old_tail->next.compare_exchange_weak(next, new_node))
            {
                tail_.compare_exchange_weak(old_tail, new_node);
                return;
            }
            
            old_tail = tail_.load();
        }
    }
    
    void push(T&& data)
    {
        Node* new_node = new Node(std::move(data));
        Node* old_tail = tail_.load();
        
        while (true)
        {
            Node* next = old_tail->next.load();
            if (next != nullptr)
            {
                tail_.compare_exchange_weak(old_tail, next);
                continue;
            }
            
            if (old_tail->next.compare_exchange_weak(next, new_node))
            {
                tail_.compare_exchange_weak(old_tail, new_node);
                return;
            }
            
            old_tail = tail_.load();
        }
    }
    
    bool tryPop(T& data)
    {
        Node* old_head = head_.load();
        
        while (true)
        {
            Node* next = old_head->next.load();
            if (next == nullptr)
                return false;
            
            if (head_.compare_exchange_weak(old_head, next))
            {
                data = std::move(next->data);
                delete old_head;
                return true;
            }
        }
    }
    
    bool empty() const
    {
        return head_.load()->next.load() == nullptr;
    }
};

extern LockFreeQueue<OccupancyGridData> OccupancyGridDataQueue;
extern LockFreeQueue<LaserScanData> LaserScanDataQueue;
extern LockFreeQueue<RobotPose> PoseStampedQueue;

}  // namespace costmapNS

#endif  // COSTMAP_2D_LOCK_FREE_QUEUE_H_