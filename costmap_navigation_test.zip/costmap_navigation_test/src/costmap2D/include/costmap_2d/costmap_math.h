#ifndef COSTMAP_2D_COSTMAP_MATH_H_
#define COSTMAP_2D_COSTMAP_MATH_H_

/**
 * @file costmap_math.h
 * @brief 代价地图数学工具函数库
 *
 * 本模块提供代价地图操作所需的基础数学工具函数，包括：
 * 1. 符号函数（sign, sign0）
 * 2. 距离计算（distance, distanceToLine）
 * 3. 多边形相交检测（intersects）
 *
 * 特点：
 * - 纯C++实现，无ROS依赖
 * - 提供自定义Point结构体替代geometry_msgs::Point
 * - 高效的几何计算算法
 */

#include <math.h>
#include <algorithm>
#include <vector>

namespace costmapNS
{

// Point 结构体定义在 costmap_2d.h 中，此处引用以确保一致性
// 注意：不要在此处重复定义 Point

}  // namespace costmapNS

namespace costmapNS
{

/**
 * @brief 符号函数
 *
 * 返回-1如果x<0，否则返回+1。
 * 注意：当x=0时返回+1。
 *
 * @param x 输入值
 * @return -1.0 (x<0) 或 +1.0 (x>=0)
 */
inline double sign(double x)
{
  return x < 0.0 ? -1.0 : 1.0;
}

/**
 * @brief 带零判断的符号函数
 *
 * 与sign()类似，但当x=0时返回0。
 *
 * @param x 输入值
 * @return -1.0 (x<0), 0.0 (x=0), 或 +1.0 (x>0)
 */
inline double sign0(double x)
{
  return x < 0.0 ? -1.0 : (x > 0.0 ? 1.0 : 0.0);
}

/**
 * @brief 计算两点间的欧几里得距离
 *
 * 使用hypot函数计算，避免数值溢出问题。
 *
 * @param x0 第一个点的X坐标
 * @param y0 第一个点的Y坐标
 * @param x1 第二个点的X坐标
 * @param y1 第二个点的Y坐标
 * @return 两点间的距离
 */
inline double distance(double x0, double y0, double x1, double y1)
{
  return hypot(x1 - x0, y1 - y0);
}

/**
 * @brief 计算点到线段的最短距离
 *
 * 使用投影法计算点到线段的垂直距离。
 * 如果投影点在线段外，则返回最近端点的距离。
 *
 * @param pX 测试点的X坐标
 * @param pY 测试点的Y坐标
 * @param x0 线段起点X坐标
 * @param y0 线段起点Y坐标
 * @param x1 线段终点X坐标
 * @param y1 线段终点Y坐标
 * @return 点到线段的最短距离
 */
double distanceToLine(double pX, double pY, double x0, double y0, double x1, double y1);

/**
 * @brief 点是否在多边形内部（射线法）
 *
 * 使用经典的射线法（Ray Casting Algorithm）判断点是否在多边形内部。
 * 从测试点向右发射一条水平射线，统计与多边形边界的交点数。
 * 如果交点数为奇数，则点在内部；否则在外部。
 *
 * @param polygon 多边形顶点向量（按顺序排列）
 * @param testx 测试点X坐标
 * @param testy 测试点Y坐标
 * @return true表示点在多边形内部
 */
bool intersects(std::vector<Point>& polygon, float testx, float testy);

/**
 * @brief 判断两个多边形是否相交
 *
 * 通过检查一个多边形的任意顶点是否在另一个多边形内部来判断相交。
 * 如果任意一个多边形的顶点在另一个内部，则认为两多边形相交。
 *
 * @param polygon1 第一个多边形
 * @param polygon2 第二个多边形
 * @return true表示两多边形相交
 */
bool intersects(std::vector<Point>& polygon1, std::vector<Point>& polygon2);

}  // namespace costmapNS

#endif  // COSTMAP_2D_COSTMAP_MATH_H_
