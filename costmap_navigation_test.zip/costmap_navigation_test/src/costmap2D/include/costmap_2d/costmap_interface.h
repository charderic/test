#ifndef COSTMAP_2D_COSTMAP_INTERFACE_H_
#define COSTMAP_2D_COSTMAP_INTERFACE_H_

#include <costmap_2d/layered_costmap.h>
#include <costmap_2d/static_layer.h>
#include <costmap_2d/obstacle_layer.h>
#include <costmap_2d/inflation_layer.h>
#include <costmap_2d/lock_free_queue.h>
#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>

namespace costmapNS
{

/**
 * @brief 代价地图消息结构体（替代 ROS nav_msgs::OccupancyGrid）
 */
struct OccupancyGridMsg
{
    std::string header_frame;  // 坐标系名称
    
    double resolution;          // 分辨率（米/栅格）
    unsigned int width;         // 宽度（栅格数）
    unsigned int height;        // 高度（栅格数）
    double origin_x;           // 原点X坐标（世界坐标，米）
    double origin_y;           // 原点Y坐标（世界坐标，米）
    double origin_theta;       // 原点偏转角度（弧度）
    
    std::vector<int8_t> data;  // 栅格数据
    
    OccupancyGridMsg() : resolution(0.0), width(0), height(0), 
                        origin_x(0.0), origin_y(0.0), origin_theta(0.0) {}
};

class costmap_interface
{
public:
    costmap_interface(const std::string& CostmapName);
    
    ~costmap_interface();
    
    bool initialize();
    
    void start();
    
    void stop();
    
    OccupancyGridMsg generateCostmapMsg();
    
    bool isStarted() const { return running_; }
    
    std::string getCostmapName() const { return CostmapName_; }
    
    LayeredCostmap* getLayeredCostmap() { return layered_costmap_; }
    
private:
    void processGlobalCostmap();
    
    void processLocalCostmap();
    
    bool loadConfigFromYAML(const std::string& filename);
    
    void updateGlobalCostmap();
    
    void updateLocalCostmap(const LaserScanData& laser_data, const RobotPose& pose_data);
    
    void convertToOccupancyGridMsg(OccupancyGridMsg& msg);
    
    std::string CostmapName_;
    LayeredCostmap* layered_costmap_;
    
    boost::shared_ptr<StaticLayer> static_layer_;
    boost::shared_ptr<ObstacleLayer> obstacle_layer_;
    boost::shared_ptr<InflationLayer> inflation_layer_;
    
    bool rolling_window_;
    double costmap_resolution_;
    double costmap_origin_x_;
    double costmap_origin_y_;
    double costmap_origin_theta_;
    double costmap_width_;
    double costmap_height_;
    bool track_unknown_space_;
    
    double inflation_radius_;
    double cost_scaling_factor_;
    double obstacle_range_;
    double raytrace_range_;
    double timestamp_tolerance_;
    double robot_radius_;
    double circumscribed_radius_;
    
    bool initialized_;
    bool running_;
    
    boost::thread* process_thread_;
    
    boost::mutex data_mutex_;
    OccupancyGridData latest_map_data_;
    LaserScanData latest_laser_data_;
    RobotPose latest_pose_data_;
    
    bool map_received_;
    bool laser_received_;
    bool pose_received_;
    
    uint64_t used_laser_timestamp_;
    uint64_t used_pose_timestamp_;
};

}  // namespace costmapNS

#endif  // COSTMAP_2D_COSTMAP_INTERFACE_H_