#include <costmap_2d/lock_free_queue.h>

namespace costmapNS
{

LockFreeQueue<OccupancyGridData> OccupancyGridDataQueue;
LockFreeQueue<LaserScanData> LaserScanDataQueue;
LockFreeQueue<RobotPose> PoseStampedQueue;

}  // namespace costmapNS