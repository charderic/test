# Costmap2D - 分层代价地图库

一个基于ROS Navigation Stack重构的分层代价地图库，核心功能已去除ROS依赖，可独立使用。

## 特性

- ✅ **核心无ROS依赖**：`Costmap2D`、`LayeredCostmap`、`costmap_interface`及各图层完全独立
- ✅ **分层架构**：支持静态层、障碍物层、膨胀层等多种图层
- ✅ **滚动窗口模式**：局部代价地图可跟随机器人移动
- ✅ **无锁队列**：高效线程安全的数据传输
- ✅ **时间戳对齐**：激光数据与位姿数据精确配对
- ✅ **自定义数据结构**：替代ROS消息类型（`LaserScanData`、`RobotPose`、`OccupancyGridData`）

## 核心接口 - costmap_interface

`costmap_interface` 是代价地图的高级封装接口，提供完整的配置加载、初始化、启动和数据处理功能。

### 基本用法

`costmap_interface` 通过全局无锁队列接收外部数据（激光扫描、机器人位姿、静态地图），启动后自动从队列中读取数据并更新代价地图。

```cpp
#include <costmap_2d/costmap_interface.h>

using namespace costmapNS;

int main() {
     //===========================================================================================
     extern LockFreeQueue<OccupancyGridData> OccupancyGridDataQueue;
     extern LockFreeQueue<LaserScanData> LaserScanDataQueue;
     extern LockFreeQueue<RobotPose> PoseStampedQueue;
    
    // 创建全局代价地图接口
    costmap_interface global_costmap("global_costmap");
    costmap_interface local_costmap("local_costmap");
    
    // 初始化（加载配置、创建图层）
    global_costmap.initialize();
    local_costmap.initialize();
    
    // 启动（开始从队列读取数据并处理）
    global_costmap.start();
    local_costmap.start();
    
    // 在其他线程中向队列推送数据
    // 全局地图需要：OccupancyGridDataQueue（静态地图数据）
    // 局部地图需要：LaserScanDataQueue（激光数据） + PoseStampedQueue（位姿数据）
    
    // 获取代价地图消息
    OccupancyGridMsg global_msg = global_costmap.generateCostmapMsg();
    OccupancyGridMsg local_msg = local_costmap.generateCostmapMsg();
    
    // 停止
    global_costmap.stop();
    local_costmap.stop();
    
    return 0;
}
```

### 接口方法

| 方法 | 功能 |
|------|------|
| `costmap_interface(name)` | 构造函数，传入代价地图名称 |
| `initialize()` | 初始化，加载配置文件并创建图层 |
| `start()` | 启动数据处理线程 |
| `stop()` | 停止数据处理线程 |
| `generateCostmapMsg()` | 生成代价地图消息（`OccupancyGridMsg`） |
| `isStarted()` | 判断是否正在运行 |
| `getCostmapName()` | 获取代价地图名称 |
| `getLayeredCostmap()` | 获取底层 `LayeredCostmap` 指针 |

### 配置文件

`costmap_interface` 会根据名称自动查找配置文件：

```yaml
global_costmap:
  global_frame: map
  robot_base_frame: base_link
  resolution: 0.05
  width: 20.0
  height: 20.0
  origin_x: -10.0
  origin_y: -10.0
  rolling_window: false
  track_unknown: true
  robot_radius: 0.3
  circumscribed_radius: 0.5
  timestamp_tolerance: 0.5

static_layer:
  enabled: true
  map_topic: /map

obstacle_layer:
  enabled: true
  max_obstacle_height: 2.0
  raytrace_range: 6.0
  obstacle_range: 6.0

inflation_layer:
  enabled: true
  inflation_radius: 0.5
  cost_scaling_factor: 10.0
```

### 无锁队列数据输入

`costmap_interface` 通过全局无锁队列接收外部数据：

| 队列 | 数据类型 | 用途 |
|------|----------|------|
| `OccupancyGridDataQueue` | `OccupancyGridData` | 静态地图数据 |
| `LaserScanDataQueue` | `LaserScanData` | 激光扫描数据 |
| `PoseStampedQueue` | `RobotPose` | 机器人位姿数据 |

#### 数据结构定义

```cpp
struct OccupancyGridData {
    std::string frame_id;
    uint64_t timestamp_ns;
    double resolution;
    unsigned int width;
    unsigned int height;
    double origin_x;
    double origin_y;
    std::vector<int8_t> data;
};

struct LaserScanData {
    std::string frame_id;
    uint64_t timestamp_ns;
    double angle_min;
    double angle_max;
    double angle_increment;
    double time_increment;
    double scan_time;
    double range_min;
    double range_max;
    std::vector<double> ranges;
    std::vector<double> intensities;
};

struct RobotPose {
    std::string frame_id;
    uint64_t timestamp_ns;
    double x_;
    double y_;
    double theta_;
};
```

#### 输入数据示例

```cpp
// 推送激光扫描数据
LaserScanData scan;
scan.frame_id = "laser";
scan.timestamp_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
    std::chrono::system_clock::now().time_since_epoch()).count();
scan.angle_min = -M_PI;
scan.angle_max = M_PI;
scan.angle_increment = 0.01;
scan.range_min = 0.1;
scan.range_max = 10.0;
scan.ranges.resize(628);
// ... 填充数据
LaserScanDataQueue.push(scan);

// 推送机器人位姿
RobotPose pose;
pose.frame_id = "base_link";
pose.timestamp_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
    std::chrono::system_clock::now().time_since_epoch()).count();
pose.x_ = 0.0;
pose.y_ = 0.0;
pose.theta_ = 0.0;
PoseStampedQueue.push(pose);
```

### 输出数据

`generateCostmapMsg()` 返回 `OccupancyGridMsg` 结构体：

```cpp
struct OccupancyGridMsg {
    std::string header_frame;  // 坐标系名称
    double resolution;          // 分辨率（米/栅格）
    unsigned int width;         // 宽度（栅格数）
    unsigned int height;        // 高度（栅格数）
    double origin_x;           // 原点X坐标（世界坐标，米）
    double origin_y;           // 原点Y坐标（世界坐标，米）
    double origin_theta;       // 原点偏转角度（弧度）
    std::vector<int8_t> data;  // 栅格数据（-1未知, 0自由, 1-99膨胀, 100障碍）
};
```

## 项目结构

```
costmap2D/
├── include/costmap_2d/         # 头文件
│   ├── costmap_2d.h           # 核心栅格地图数据结构
│   ├── layered_costmap.h      # 分层代价地图主控类
│   ├── layer.h                # 图层抽象基类
│   ├── costmap_layer.h        # 图层实现基类
│   ├── static_layer.h         # 静态地图层（无ROS依赖）
│   ├── obstacle_layer.h       # 障碍物层（无ROS依赖）
│   ├── inflation_layer.h      # 膨胀层
│   ├── costmap_interface.h    # 高级封装接口（无ROS依赖）
│   ├── lock_free_queue.h      # 无锁队列实现
│   ├── footprint.h            # 机器人底盘足迹
│   ├── cost_values.h          # 代价常量定义
│   ├── costmap_math.h         # 数学工具函数
│   └── point_cloud.h          # 点云数据结构
├── src/                        # 核心源文件
│   ├── costmap_2d.cpp
│   ├── layered_costmap.cpp
│   ├── layer.cpp
│   ├── costmap_layer.cpp
│   ├── costmap_math.cpp
│   ├── footprint.cpp
│   ├── costmap_interface.cpp  # costmap_interface实现
│   └── lock_free_queue.cpp    # 无锁队列全局实例
├── plugins/                    # 图层插件实现
│   ├── static_layer.cpp
│   ├── obstacle_layer.cpp
│   └── inflation_layer.cpp
├── config/                     # 配置文件
│   ├── global_costmap.yaml    # 全局代价地图配置
│   └── local_costmap.yaml     # 局部代价地图配置
├── examples/                   # 示例程序（依赖ROS）
│   ├── costmap_interface_demo.cpp  # costmap_interface综合演示
│   ├── global_costmap_demo.cpp     # 全局代价地图演示
│   └── local_costmap_demo.cpp      # 局部代价地图演示
├── CMakeLists.txt             # 构建配置
└── README.md                  # 本文件
```

## 核心组件

### 1. Costmap2D - 栅格地图核心

替代ROS的`costmap2D::Costmap2D`，提供：

- **基础功能**：地图初始化、重置、调整大小
- **坐标转换**：世界坐标 ↔ 栅格索引（支持旋转）
- **代价管理**：自由空间(0)、致命障碍(254)、未知区域(255)
- **多边形操作**：多边形填充、射线追踪清除

### 2. LayeredCostmap - 分层地图管理

管理多个图层，支持动态添加/移除图层：

- **图层管理**：添加、激活、失活图层
- **地图更新**：统一更新所有图层
- **边界管理**：动态调整地图边界
- **滚动窗口**：支持局部地图跟随机器人移动

### 3. 图层插件

| 图层 | 功能 | 说明 |
|------|------|------|
| **StaticLayer** | 静态地图层 | 加载静态地图，使用`OccupancyGridData` |
| **ObstacleLayer** | 障碍物层 | 处理激光扫描数据，标记障碍物，射线清除 |
| **InflationLayer** | 膨胀层 | 围绕障碍物生成安全缓冲区，代价指数衰减 |

## 编译安装

### 依赖

- CMake >= 3.10
- C++11编译器
- Eigen3
- Boost (线程库)
- (可选) ROS Noetic（用于编译Demo）

### Ubuntu安装依赖

```bash
sudo apt-get update
sudo apt-get install cmake libeigen3-dev libboost-all-dev
```

### 编译（无ROS）

```bash
mkdir build && cd build
cmake ..
make
```

### 编译（有ROS）

```bash
source /opt/ros/noetic/setup.bash
mkdir build && cd build
cmake ..
make
```

### 安装

```bash
sudo make install
```

## 使用示例

### 使用 costmap_interface（推荐）

```cpp
#include <costmap_2d/costmap_interface.h>

using namespace costmapNS;

int main() {
    costmap_interface global_costmap("global_costmap");
    costmap_interface local_costmap("local_costmap");
    
    global_costmap.initialize();
    local_costmap.initialize();
    
    global_costmap.start();
    local_costmap.start();
    
    while (true) {
        OccupancyGridMsg global_msg = global_costmap.generateCostmapMsg();
        OccupancyGridMsg local_msg = local_costmap.generateCostmapMsg();
        
        // 处理代价地图数据...
        
        usleep(100000);  // 100ms
    }
    
    global_costmap.stop();
    local_costmap.stop();
    
    return 0;
}
```

### 直接使用 LayeredCostmap

```cpp
#include <costmap_2d/layered_costmap.h>
#include <costmap_2d/static_layer.h>
#include <costmap_2d/inflation_layer.h>

using namespace costmap2D;

int main() {
    LayeredCostmap layered_costmap("global", false, true);
    
    StaticLayer* static_layer = new StaticLayer();
    static_layer->initialize(&layered_costmap);
    layered_costmap.addLayer(static_layer);
    
    InflationLayer* inflation_layer = new InflationLayer();
    inflation_layer->initialize(&layered_costmap);
    layered_costmap.addLayer(inflation_layer);
    
    layered_costmap.resizeMap(100, 100, 0.05, 0.0, 0.0);
    
    return 0;
}
```

### 运行Demo程序

```bash
# costmap_interface综合演示（订阅/map, /scan, /amcl_pose）
./build/costmap_interface_demo

# 全局代价地图（订阅/map话题）
./build/global_costmap_demo [map_topic]

# 局部代价地图（订阅/scan和/amcl_pose话题）
./build/local_costmap_demo
```

## 配置说明

### 全局代价地图配置

```yaml
global_costmap:
  global_frame: map                    # 全局坐标系
  robot_base_frame: base_link          # 机器人基座坐标系
  resolution: 0.05                    # 分辨率（米/栅格）
  width: 20.0                         # 宽度（米）
  height: 20.0                        # 高度（米）
  origin_x: -10.0                     # 原点X（米）
  origin_y: -10.0                     # 原点Y（米）
  rolling_window: false               # 是否滚动窗口模式
  track_unknown: true                 # 是否跟踪未知区域
  robot_radius: 0.3                   # 机器人内切圆半径
  circumscribed_radius: 0.5           # 机器人外接圆半径

static_layer:
  enabled: true

obstacle_layer:
  enabled: false                      # 全局地图通常不需要障碍物层

inflation_layer:
  enabled: true
  inflation_radius: 0.5               # 膨胀半径（米）
  cost_scaling_factor: 10.0           # 代价衰减系数
```

### 局部代价地图配置

```yaml
local_costmap:
  global_frame: odom                  # 使用里程计坐标系
  robot_base_frame: base_link
  resolution: 0.05
  width: 5.0                          # 较小的局部范围
  height: 5.0
  origin_x: -2.5
  origin_y: -2.5
  rolling_window: true                # 必须启用滚动窗口
  track_unknown: false
  robot_radius: 0.3
  circumscribed_radius: 0.5
  timestamp_tolerance: 1.0            # 时间戳容差（秒）

static_layer:
  enabled: false                      # 局部地图不需要静态层

obstacle_layer:
  enabled: true
  max_obstacle_height: 2.0
  raytrace_range: 6.0
  obstacle_range: 6.0

inflation_layer:
  enabled: true
  inflation_radius: 0.5
  cost_scaling_factor: 10.0
```

## 代价值定义

| 值 | 含义 |
|----|------|
| `0` | 自由空间 |
| `1-252` | 膨胀代价（数值越大越危险） |
| `253` | 致命障碍前的代价 |
| `254` | 致命障碍 |
| `255` | 未知区域 |

转换为输出数据（`OccupancyGridMsg.data`）时：
- `-1`：未知区域（255）
- `0`：自由空间（0）
- `1-99`：膨胀代价（1-252线性映射）
- `100`：致命障碍（254）

## API参考

### costmap_interface

```cpp
// 构造函数
costmap_interface(const std::string& CostmapName);

// 初始化与控制
bool initialize();
void start();
void stop();

// 状态查询
bool isStarted() const;
std::string getCostmapName() const;
LayeredCostmap* getLayeredCostmap();

// 数据输出
OccupancyGridMsg generateCostmapMsg();
```

### Costmap2D

```cpp
// 构造函数
Costmap2D(unsigned int size_x, unsigned int size_y, double resolution,
          double origin_x, double origin_y, unsigned char default_value = 0);

// 坐标转换
bool worldToMap(double wx, double wy, unsigned int& mx, unsigned int& my) const;
void mapToWorld(unsigned int mx, unsigned int my, double& wx, double& wy) const;

// 代价访问
unsigned char getCost(unsigned int mx, unsigned int my) const;
void setCost(unsigned int mx, unsigned int my, unsigned char cost);

// 地图操作
void resizeMap(unsigned int size_x, unsigned int size_y, double resolution,
               double origin_x, double origin_y);
void raytraceLine(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1);
```

### LayeredCostmap

```cpp
LayeredCostmap(std::string global_frame, bool rolling_window, bool track_unknown);

void addLayer(Layer* layer);
void resizeMap(unsigned int size_x, unsigned int size_y, double resolution,
               double origin_x, double origin_y);
void updateMap(double robot_x, double robot_y, double robot_yaw);
void setInscribedRadius(double radius);
void setCircumscribedRadius(double radius);
```

### StaticLayer

```cpp
void incomingMap(const OccupancyGridData& new_map);
void initialize(LayeredCostmap* parent);
void updateBounds(double robot_x, double robot_y, double robot_yaw,
                  double* min_x, double* min_y, double* max_x, double* max_y);
void updateCosts(Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);
```

### ObstacleLayer

```cpp
void incomingLaserScan(const LaserScanData& scan, const RobotPose& robot_pose,
                       double sensor_mount_angle = 0.0);
void initialize(LayeredCostmap* parent);
void updateBounds(double robot_x, double robot_y, double robot_yaw,
                  double* min_x, double* min_y, double* max_x, double* max_y);
void updateCosts(Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);
void setRollingWindow(bool rolling);
```

### InflationLayer

```cpp
void initialize(LayeredCostmap* parent);
void updateBounds(double robot_x, double robot_y, double robot_yaw,
                  double* min_x, double* min_y, double* max_x, double* max_y);
void updateCosts(Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);
```

### LockFreeQueue

```cpp
template<typename T>
class LockFreeQueue {
    void push(const T& data);
    bool pop(T& data);
    bool empty();
    size_t size();
};

// 全局队列实例
extern LockFreeQueue<OccupancyGridData> OccupancyGridDataQueue;
extern LockFreeQueue<LaserScanData> LaserScanDataQueue;
extern LockFreeQueue<RobotPose> PoseStampedQueue;
```

## 应用场景

- 机器人导航系统
- 局部路径规划
- 避障算法
- 自主移动机器人
- 多机器人协作

## 许可证

本项目采用BSD许可证，兼容原ROS costmap_2d的许可证。

## 作者

基于ROS Navigation Stack的costmap_2d包重构，移除ROS依赖，提供独立的数据结构和接口。

## 贡献

欢迎提交Issue和Pull Request！
