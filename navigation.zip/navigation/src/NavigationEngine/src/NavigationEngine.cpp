#include "NavigationEngine.h"

namespace navigation_engine
{

NavigationEngine::NavigationEngine()
    : global_costmap_(nullptr),
      local_costmap_(nullptr),
      initialized_(false),
      running_(false)
{
}

NavigationEngine::~NavigationEngine()
{
    stop();
    
    delete global_costmap_;
    delete local_costmap_;
    global_costmap_ = nullptr;
    local_costmap_ = nullptr;
}

bool NavigationEngine::initialize()
{
    if (initialized_)
        return true;
    
    global_costmap_ = new costmapNS::costmap_interface("global_costmap");
    local_costmap_ = new costmapNS::costmap_interface("local_costmap");
    
    if (!global_costmap_->initialize())
    {
        delete global_costmap_;
        delete local_costmap_;
        global_costmap_ = nullptr;
        local_costmap_ = nullptr;
        return false;
    }
    
    if (!local_costmap_->initialize())
    {
        global_costmap_->stop();
        delete global_costmap_;
        delete local_costmap_;
        global_costmap_ = nullptr;
        local_costmap_ = nullptr;
        return false;
    }
    
    initialized_ = true;
    return true;
}

void NavigationEngine::start()
{
    if (!initialized_)
        return;
    
    if (running_)
        return;
    
    global_costmap_->start();
    local_costmap_->start();
    
    running_ = true;
}

void NavigationEngine::stop()
{
    if (!running_)
        return;
    
    if (local_costmap_)
        local_costmap_->stop();
    
    if (global_costmap_)
        global_costmap_->stop();
    
    running_ = false;
}

costmapNS::LayeredCostmap* NavigationEngine::getGlobalCostmap()
{
    if (global_costmap_)
        return global_costmap_->getLayeredCostmap();
    return nullptr;
}

costmapNS::LayeredCostmap* NavigationEngine::getLocalCostmap()
{
    if (local_costmap_)
        return local_costmap_->getLayeredCostmap();
    return nullptr;
}

}