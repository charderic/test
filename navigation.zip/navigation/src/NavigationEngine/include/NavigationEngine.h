#ifndef NAVIGATION_ENGINE_H_
#define NAVIGATION_ENGINE_H_

#include <costmap_2d/costmap_interface.h>
#include <string>

//主状态机与调度器类
namespace navigation_engine
{

class NavigationEngine
{
public:
    NavigationEngine();
    ~NavigationEngine();
    
    bool initialize();
    
    void start();
    
    void stop();
    
    costmapNS::LayeredCostmap* getGlobalCostmap();
    
    costmapNS::LayeredCostmap* getLocalCostmap();

private:
    costmapNS::costmap_interface* global_costmap_;
    costmapNS::costmap_interface* local_costmap_;
    bool initialized_;
    bool running_;

};

}

#endif  // NAVIGATION_ENGINE_H_