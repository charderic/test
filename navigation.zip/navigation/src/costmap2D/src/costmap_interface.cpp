#include <costmap_2d/costmap_interface.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <unistd.h>
#include <limits.h>

namespace costmapNS
{

costmap_interface::costmap_interface(const std::string& CostmapName)
    : CostmapName_(CostmapName),
      layered_costmap_(nullptr),
      rolling_window_(false),
      costmap_resolution_(0.05),
      costmap_origin_x_(0.0),
      costmap_origin_y_(0.0),
      costmap_origin_theta_(0.0),
      costmap_width_(5.0),
      costmap_height_(5.0),
      track_unknown_space_(false),
      inflation_radius_(0.5),
      cost_scaling_factor_(2.0),
      obstacle_range_(5.0),
      raytrace_range_(6.0),
      timestamp_tolerance_(0.2),
      robot_radius_(0.3),
      circumscribed_radius_(0.5),
      initialized_(false),
      running_(false),
      process_thread_(nullptr),
      map_received_(false),
      laser_received_(false),
      pose_received_(false),
      used_laser_timestamp_(0),
      used_pose_timestamp_(0)
{
}

costmap_interface::~costmap_interface()
{
    stop();
    
    if (layered_costmap_)
    {
        delete layered_costmap_;
    }
}

bool costmap_interface::initialize()
{
    std::string config_file = "config/" + CostmapName_ + ".yaml";
    
    std::ifstream test_file(config_file);
    if (!test_file.is_open())
    {
        config_file = "../config/" + CostmapName_ + ".yaml";
        std::ifstream test_file2(config_file);
        if (!test_file2.is_open())
        {
            char buffer[PATH_MAX];
            if (getcwd(buffer, PATH_MAX))
            {
                std::string current_dir(buffer);
                size_t pos = current_dir.find("/build");
                if (pos != std::string::npos)
                {
                    config_file = current_dir.substr(0, pos) + "/src/costmap2D/config/" + CostmapName_ + ".yaml";
                }
            }
        }
    }
    
    std::cout << "[" << CostmapName_ << "] Loading config from: " << config_file << std::endl;
    
    if (!loadConfigFromYAML(config_file))
    {
        std::cerr << "Failed to load config from " << config_file << ", using default values" << std::endl;
    }
    
    std::string global_frame = "map";
    
    layered_costmap_ = new LayeredCostmap(global_frame, rolling_window_, track_unknown_space_);
    
    if (CostmapName_ == "global_costmap")
    {
        static_layer_.reset(new StaticLayer());
        
        layered_costmap_->setInscribedRadius(robot_radius_);
        layered_costmap_->setCircumscribedRadius(circumscribed_radius_);
        
        inflation_layer_.reset(new InflationLayer(inflation_radius_, cost_scaling_factor_, track_unknown_space_));
        
        layered_costmap_->addPlugin(static_layer_);
        layered_costmap_->addPlugin(inflation_layer_);
        
        inflation_layer_->initialize(layered_costmap_, "inflation_layer", NULL);
        inflation_layer_->setEnabled(true);
        
        static_layer_->initialize(layered_costmap_, "static_layer", NULL);
        static_layer_->setEnabled(true);
    }
    else if (CostmapName_ == "local_costmap")
    {
        obstacle_layer_.reset(new ObstacleLayer());
        
        layered_costmap_->setInscribedRadius(robot_radius_);
        layered_costmap_->setCircumscribedRadius(circumscribed_radius_);
        
        inflation_layer_.reset(new InflationLayer(inflation_radius_, cost_scaling_factor_, track_unknown_space_));
        
        layered_costmap_->addPlugin(obstacle_layer_);
        layered_costmap_->addPlugin(inflation_layer_);
        
        Costmap2D* costmap = layered_costmap_->getCostmap();
        costmap->resizeMap(
            static_cast<unsigned int>(costmap_width_ / costmap_resolution_),
            static_cast<unsigned int>(costmap_height_ / costmap_resolution_),
            costmap_resolution_,
            costmap_origin_x_,
            costmap_origin_y_);
        
        inflation_layer_->initialize(layered_costmap_, "inflation_layer", NULL);
        inflation_layer_->matchSize();
        inflation_layer_->setEnabled(true);
        
        obstacle_layer_->initialize(layered_costmap_, "obstacle_layer", NULL);
        obstacle_layer_->matchSize();
        obstacle_layer_->setEnabled(true);
        obstacle_layer_->activate();
        
        obstacle_layer_->setObstacleRange(obstacle_range_);
        obstacle_layer_->setRaytraceRange(raytrace_range_);
        obstacle_layer_->setTimestampTolerance(static_cast<uint64_t>(timestamp_tolerance_ * 1e9));
        
        obstacle_layer_->setRollingWindow(rolling_window_);
    }
    
    initialized_ = true;
    std::cout << "[" << CostmapName_ << "] costmap_interface initialized successfully" << std::endl;
    
    return true;
}

void costmap_interface::start()
{
    if (!initialized_)
    {
        std::cerr << "[" << CostmapName_ << "] costmap_interface not initialized, call initialize() first" << std::endl;
        return;
    }
    
    if (running_)
    {
        std::cerr << "[" << CostmapName_ << "] costmap_interface already running" << std::endl;
        return;
    }
    
    running_ = true;
    
    if (CostmapName_ == "global_costmap")
    {
        process_thread_ = new boost::thread(&costmap_interface::processGlobalCostmap, this);
    }
    else if (CostmapName_ == "local_costmap")
    {
        process_thread_ = new boost::thread(&costmap_interface::processLocalCostmap, this);
    }
    
    std::cout << "[" << CostmapName_ << "] costmap_interface started" << std::endl;
}

void costmap_interface::stop()
{
    running_ = false;
    
    if (process_thread_ && process_thread_->joinable())
    {
        process_thread_->join();
        delete process_thread_;
        process_thread_ = nullptr;
    }
    
    if (obstacle_layer_)
    {
        obstacle_layer_->deactivate();
    }
    
    std::cout << "[" << CostmapName_ << "] costmap_interface stopped" << std::endl;
}

void costmap_interface::processGlobalCostmap()
{
    while (running_)
    {
        OccupancyGridData grid_data;
        if (OccupancyGridDataQueue.tryPop(grid_data))
        {
            {
                boost::unique_lock<boost::mutex> lock(data_mutex_);
                latest_map_data_ = grid_data;
                map_received_ = true;
            }
            
            if (static_layer_)
            {
                static_layer_->incomingMap(grid_data);
            }
            
            updateGlobalCostmap();
        }
        
        usleep(10000);
    }
}

void costmap_interface::processLocalCostmap()
{
    while (running_)
    {
        LaserScanData laser_data;
        RobotPose pose_data;
        
        bool laser_updated = LaserScanDataQueue.tryPop(laser_data);
        bool pose_updated = PoseStampedQueue.tryPop(pose_data);
        
        if (laser_updated)
        {
            {
                boost::unique_lock<boost::mutex> lock(data_mutex_);
                latest_laser_data_ = laser_data;
                laser_received_ = true;
            }
        }
        
        if (pose_updated)
        {
            {
                boost::unique_lock<boost::mutex> lock(data_mutex_);
                latest_pose_data_ = pose_data;
                pose_received_ = true;
            }
        }
        
        bool data_ready = false;
        LaserScanData paired_laser;
        RobotPose paired_pose;
        
        {
            boost::unique_lock<boost::mutex> lock(data_mutex_);
            if (laser_received_ && pose_received_)
            {
                bool laser_new = (latest_laser_data_.timestamp_ns_ > used_laser_timestamp_);
                bool pose_new = (latest_pose_data_.timestamp_ns_ > used_pose_timestamp_);
                
                if (laser_new && pose_new)
                {
                    paired_laser = latest_laser_data_;
                    paired_pose = latest_pose_data_;
                    data_ready = true;
                }
            }
        }
        
        if (data_ready)
        {
            {
                boost::unique_lock<boost::mutex> lock(data_mutex_);
                used_laser_timestamp_ = paired_laser.timestamp_ns_;
                used_pose_timestamp_ = paired_pose.timestamp_ns_;
            }
            
            updateLocalCostmap(paired_laser, paired_pose);
        }
        
        usleep(10000);
    }
}

void costmap_interface::updateGlobalCostmap()
{
    if (!layered_costmap_) return;
    
    Costmap2D* costmap = layered_costmap_->getCostmap();
    
    double robot_x = costmap->getOriginX() + costmap->getSizeInMetersX() / 2.0;
    double robot_y = costmap->getOriginY() + costmap->getSizeInMetersY() / 2.0;
    
    layered_costmap_->updateMap(robot_x, robot_y, 0.0);
}

void costmap_interface::updateLocalCostmap(const LaserScanData& laser_data, const RobotPose& pose_data)
{
    if (!layered_costmap_ || !obstacle_layer_) return;
    
    int64_t time_diff = static_cast<int64_t>(laser_data.timestamp_ns_) - static_cast<int64_t>(pose_data.timestamp_ns_);
    if (time_diff < 0) time_diff = -time_diff;
    
    uint64_t tolerance_ns = static_cast<uint64_t>(timestamp_tolerance_) * 1000000000ULL;
    
    if (time_diff > tolerance_ns)
    {
        std::cerr << "[" << CostmapName_ << "] 时间戳不对齐: scan=" << laser_data.timestamp_ns_ 
                 << " pose=" << pose_data.timestamp_ns_ 
                 << " diff=" << (time_diff / 1000000) << " ms, 容差=" << timestamp_tolerance_ << " s" << std::endl;
    }
    
    obstacle_layer_->incomingLaserScan(laser_data, pose_data, 0.0);
    
    layered_costmap_->updateMap(pose_data.x_, pose_data.y_, pose_data.theta_);
}

OccupancyGridMsg costmap_interface::generateCostmapMsg()
{
    OccupancyGridMsg msg;
    
    if (!layered_costmap_)
    {
        return msg;
    }
    
    convertToOccupancyGridMsg(msg);
    
    return msg;
}

void costmap_interface::convertToOccupancyGridMsg(OccupancyGridMsg& msg)
{
    if (!layered_costmap_) return;
    
    Costmap2D* costmap = layered_costmap_->getCostmap();
    
    msg.header_frame = layered_costmap_->getGlobalFrameID();
    
    msg.resolution = costmap->getResolution();
    msg.width = costmap->getSizeInCellsX();
    msg.height = costmap->getSizeInCellsY();
    msg.origin_x = costmap->getOriginX();
    msg.origin_y = costmap->getOriginY();
    msg.origin_theta = 0.0;
    
    msg.data.resize(msg.width * msg.height);
    
    unsigned char* data = costmap->getCharMap();
    for (size_t i = 0; i < msg.data.size(); ++i)
    {
        unsigned char val = data[i];
        if (val == NO_INFORMATION)
            msg.data[i] = -1;
        else if (val == LETHAL_OBSTACLE)
            msg.data[i] = 100;
        else if (val == INSCRIBED_INFLATED_OBSTACLE)
            msg.data[i] = 99;
        else if (val >= 1 && val < 253)
            msg.data[i] = static_cast<int8_t>(val * 98 / 253) + 1;
        else if (val == FREE_SPACE)
            msg.data[i] = 0;
        else
            msg.data[i] = static_cast<int8_t>(val * 100 / 255);
    }
}

bool costmap_interface::loadConfigFromYAML(const std::string& filename)
{
    std::ifstream file(filename);
    if (!file.is_open())
    {
        std::cerr << "Cannot open config file: " << filename << std::endl;
        return false;
    }
    
    std::string line;
    std::string current_section;
    
    std::cout << "[" << CostmapName_ << "] Loading config from: " << filename << std::endl;
    
    while (std::getline(file, line))
    {
        size_t pos = line.find("#");
        if (pos != std::string::npos)
            line = line.substr(0, pos);
        
        pos = line.find(":");
        if (pos == std::string::npos)
            continue;
        
        std::string key = line.substr(0, pos);
        std::string value = line.substr(pos + 1);
        
        key.erase(0, key.find_first_not_of(" \t"));
        key.erase(key.find_last_not_of(" \t") + 1);
        value.erase(0, value.find_first_not_of(" \t"));
        value.erase(value.find_last_not_of(" \t") + 1);
        
        if (value.empty())
        {
            current_section = key;
            std::cout << "[" << CostmapName_ << "] Found section: " << current_section << std::endl;
            continue;
        }
        
        if (current_section == "global_costmap" || current_section == "local_costmap")
        {
            std::cout << "[" << CostmapName_ << "] Setting " << key << " = " << value << std::endl;
            
            if (key == "rolling_window")
                rolling_window_ = (value == "true");
            else if (key == "track_unknown_space")
                track_unknown_space_ = (value == "true");
            else if (key == "costmap_resolution")
                costmap_resolution_ = std::stod(value);
            else if (key == "costmap_origin_x")
                costmap_origin_x_ = std::stod(value);
            else if (key == "costmap_origin_y")
                costmap_origin_y_ = std::stod(value);
            else if (key == "costmap_origin_theta")
                costmap_origin_theta_ = std::stod(value);
            else if (key == "costmap_width")
                costmap_width_ = std::stod(value);
            else if (key == "costmap_height")
                costmap_height_ = std::stod(value);
            else if (key == "robot_radius")
                robot_radius_ = std::stod(value);
            else if (key == "circumscribed_radius")
                circumscribed_radius_ = std::stod(value);
        }
        else if (current_section == "inflation_layer")
        {
            std::cout << "[" << CostmapName_ << "] Setting inflation_layer." << key << " = " << value << std::endl;
            
            if (key == "inflation_radius")
                inflation_radius_ = std::stod(value);
            else if (key == "cost_scaling_factor")
                cost_scaling_factor_ = std::stod(value);
        }
        else if (current_section == "obstacle_layer")
        {
            std::cout << "[" << CostmapName_ << "] Setting obstacle_layer." << key << " = " << value << std::endl;
            
            if (key == "obstacle_range")
                obstacle_range_ = std::stod(value);
            else if (key == "raytrace_range")
                raytrace_range_ = std::stod(value);
            else if (key == "timestamp_tolerance")
                timestamp_tolerance_ = std::stod(value);
        }
    }
    
    file.close();
    
    std::cout << "[" << CostmapName_ << "] Config loaded: rolling_window=" 
              << (rolling_window_ ? "true" : "false") 
              << ", timestamp_tolerance=" << std::fixed << std::setprecision(2) << timestamp_tolerance_ << std::endl;
    
    return true;
}

}  // namespace costmapNS