/**
 * @file grid_map_example.cpp
 * @brief GridMap使用示例
 * 
 * 演示如何使用独立的GridMap数据结构替代ROS的OccupancyGrid
 */

#include "../include/grid_map.h"
#include "../include/grid_map_loader.h"
#include <iostream>
#include <iomanip>

using namespace grid_map;

void printMapInfo(const GridMap& map) {
    std::cout << "=== 地图信息 ===" << std::endl;
    std::cout << "尺寸: " << map.getWidth() << " x " << map.getHeight() << " 栅格" << std::endl;
    std::cout << "分辨率: " << map.getResolution() << " 米/栅格" << std::endl;
    std::cout << "原点: [" << map.getOrigin().position.x << ", " 
              << map.getOrigin().position.y << ", " 
              << map.getOrigin().yaw << "]" << std::endl;
    std::cout << std::endl;
    
    // 统计栅格数量
    size_t total_cells = static_cast<size_t>(map.getWidth()) * map.getHeight();
    int free_cells = map.countFreeCells();
    int occupied_cells = map.countOccupiedCells();
    int unknown_cells = map.countUnknownCells();
    
    std::cout << "=== 栅格统计 ===" << std::endl;
    std::cout << "总栅格数:    " << total_cells << std::endl;
    std::cout << "空闲栅格数:  " << free_cells << " (" 
              << std::fixed << std::setprecision(2) 
              << (free_cells * 100.0 / total_cells) << "%)" << std::endl;
    std::cout << "障碍栅格数:  " << occupied_cells << " (" 
              << std::fixed << std::setprecision(2) 
              << (occupied_cells * 100.0 / total_cells) << "%)" << std::endl;
    std::cout << "未知栅格数:  " << unknown_cells << " (" 
              << std::fixed << std::setprecision(2) 
              << (unknown_cells * 100.0 / total_cells) << "%)" << std::endl;
    std::cout << std::endl;
}

void printPixelValues(const GridMap& map, int start_x, int start_y, int width, int height) {
    std::cout << "=== 像素值 (" << start_x << "," << start_y 
              << ") 大小: " << width << "x" << height << " ===" << std::endl;
    
    for (int y = start_y; y < start_y + height && y < map.getHeight(); ++y) {
        for (int x = start_x; x < start_x + width && x < map.getWidth(); ++x) {
            GridIndex idx(x, y);
            int8_t value = map.getCellSafe(idx, -2);
            
            if (value == -2) {
                std::cout << "   ";  // 超出边界
            } else if (value == GridMap::UNKNOWN) {
                std::cout << " ? ";  // 未知
            } else if (value >= GridMap::OCCUPIED) {
                std::cout << "███";  // 障碍
            } else {
                std::cout << "   ";  // 自由
            }
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

void testCoordinateConversion(const GridMap& map) {
    std::cout << "=== 坐标转换测试 ===" << std::endl;
    
    // 测试几个世界坐标点
    std::vector<Point2D> world_points = {
        Point2D(0.0, 0.0),
        Point2D(10.0, 10.0),
        Point2D(-10.0, -10.0),
        Point2D(5.5, 3.2)
    };
    
    for (const auto& wp : world_points) {
        GridIndex grid_idx = map.worldToGrid(wp);
        Point2D wp_back = map.gridToWorld(grid_idx);
        
        std::cout << "世界坐标: (" << wp.x << ", " << wp.y << ") ";
        std::cout << "-> 栅格索引: [" << grid_idx.x << ", " << grid_idx.y << "] ";
        std::cout << "-> 反算世界坐标: (" << wp_back.x << ", " << wp_back.y << ")";
        
        double error = grid_map::GridMap::euclideanDistance(wp, wp_back);
        std::cout << " 误差: " << error << " 米" << std::endl;
    }
    std::cout << std::endl;
}

void testMapOperations(GridMap& map) {
    std::cout << "=== 地图操作测试 ===" << std::endl;
    
    // 获取地图中心
    GridIndex center(map.getWidth() / 2, map.getHeight() / 2);
    std::cout << "地图中心栅格: [" << center.x << ", " << center.y << "]" << std::endl;
    
    // 查询中心栅格状态
    if (map.isFree(center)) {
        std::cout << "中心栅格状态: 自由空间" << std::endl;
    } else if (map.isOccupied(center)) {
        std::cout << "中心栅格状态: 障碍物" << std::endl;
    } else {
        std::cout << "中心栅格状态: 未知区域" << std::endl;
    }
    
    // 获取邻居栅格
    std::vector<GridIndex> neighbors = map.getFreeNeighbors(center, 1);
    std::cout << "周围自由栅格数: " << neighbors.size() << std::endl;
    
    // 测试距离计算
    GridIndex idx1(0, 0);
    GridIndex idx2(10, 10);
    std::cout << "栅格 [" << idx1.x << "," << idx1.y << "] 和 [" 
              << idx2.x << "," << idx2.y << "] 之间:" << std::endl;
    std::cout << "  曼哈顿距离: " << map.manhattanDistance(idx1, idx2) << std::endl;
    std::cout << "  欧几里得距离: " << map.euclideanDistance(idx1, idx2) << std::endl;
    std::cout << std::endl;
}

void testMapModification(GridMap& map) {
    std::cout << "=== 地图修改测试 ===" << std::endl;
    
    // 创建一个测试地图副本
    GridMap test_map = map;
    
    // 在地图中心清除一个区域
    GridIndex center(test_map.getWidth() / 2, test_map.getHeight() / 2);
    std::cout << "清除中心 5x5 区域..." << std::endl;
    test_map.clearArea(center, 2);
    
    // 标记一个障碍物
    GridIndex obstacle(center.x + 10, center.y);
    std::cout << "在 [" << obstacle.x << "," << obstacle.y << "] 标记障碍物..." << std::endl;
    test_map.markObstacle(obstacle, 1);
    
    // 显示修改后的统计信息
    std::cout << "修改后 - 自由栅格: " << test_map.countFreeCells() 
              << ", 障碍栅格: " << test_map.countOccupiedCells() << std::endl;
    std::cout << std::endl;
}

int main(int argc, char** argv) {
    try {
        std::cout << "========================================" << std::endl;
        std::cout << "  GridMap 独立地图数据结构示例" << std::endl;
        std::cout << "========================================" << std::endl;
        std::cout << std::endl;
        
        // 加载地图
        std::string yaml_file = "maps/hospital_map.yaml";
        if (argc > 1) {
            yaml_file = argv[1];
        }
        
        std::cout << "加载地图: " << yaml_file << std::endl;
        GridMap map;
        loadMap(yaml_file, map);
        
        // 打印地图信息
        printMapInfo(map);
        
        // 显示部分像素值（地图中心区域）
        int display_size = 20;
        int start_x = std::max(0, map.getWidth() / 2 - display_size / 2);
        int start_y = std::max(0, map.getHeight() / 2 - display_size / 2);
        printPixelValues(map, start_x, start_y, display_size, display_size);
        
        // 测试坐标转换
        testCoordinateConversion(map);
        
        // 测试地图操作
        testMapOperations(map);
        
        // 测试地图修改
        testMapModification(map);
        
        // 保存地图（可选）
        // std::cout << "保存地图到 output_map..." << std::endl;
        // saveMap(map, "output_map");
        
        std::cout << "========================================" << std::endl;
        std::cout << "  示例程序运行完成" << std::endl;
        std::cout << "========================================" << std::endl;
        
        return 0;
        
    } catch (const std::exception& e) {
        std::cerr << "错误: " << e.what() << std::endl;
        return 1;
    }
}