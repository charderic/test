/**
 * @file grid_map.cpp
 * @brief 栅格地图数据结构实现
 */

#include "grid_map.h"
#include <algorithm>
#include <queue>

namespace grid_map {

// 为静态常量提供定义（用于链接）
const int8_t GridMap::FREE_SPACE;
const int8_t GridMap::OCCUPIED;
const int8_t GridMap::UNKNOWN;
const int8_t GridMap::MARKER;

// ===== 构造函数和析构函数 =====

GridMap::GridMap()
    : width_(0), height_(0), resolution_(0.0), origin_(0.0, 0.0, 0.0) {
}

GridMap::GridMap(int width, int height, double resolution, const MapOrigin& origin)
    : width_(width), height_(height), resolution_(resolution), origin_(origin) {
    if (width <= 0 || height <= 0 || resolution <= 0.0) {
        throw std::invalid_argument("Invalid map parameters");
    }
    data_.resize(width * height, UNKNOWN);
}

GridMap::~GridMap() {
}

void GridMap::initialize(int width, int height, double resolution, const MapOrigin& origin) {
    if (width <= 0 || height <= 0 || resolution <= 0.0) {
        throw std::invalid_argument("Invalid map parameters");
    }
    
    width_ = width;
    height_ = height;
    resolution_ = resolution;
    origin_ = origin;
    data_.resize(width * height, UNKNOWN);
}

void GridMap::reset() {
    std::fill(data_.begin(), data_.end(), UNKNOWN);
}

void GridMap::resize(int new_width, int new_height, bool keep_data) {
    if (new_width <= 0 || new_height <= 0) {
        throw std::invalid_argument("Invalid map size");
    }
    
    std::vector<int8_t> new_data(new_width * new_height, UNKNOWN);
    
    if (keep_data && isInitialized()) {
        // 保留原有数据（左上角对齐）
        int copy_width = std::min(width_, new_width);
        int copy_height = std::min(height_, new_height);
        
        for (int y = 0; y < copy_height; ++y) {
            for (int x = 0; x < copy_width; ++x) {
                GridIndex old_idx(x, y);
                GridIndex new_idx(x, y);
                new_data[toLinearIndex(new_idx)] = data_[toLinearIndex(old_idx)];
            }
        }
    }
    
    width_ = new_width;
    height_ = new_height;
    data_ = new_data;
}

// ===== 栅格访问 =====

int8_t GridMap::getCell(const GridIndex& index) const {
    if (!isInside(index)) {
        throw std::out_of_range("Grid index out of bounds");
    }
    return data_[toLinearIndex(index)];
}

void GridMap::setCell(const GridIndex& index, int8_t value) {
    if (!isInside(index)) {
        throw std::out_of_range("Grid index out of bounds");
    }
    data_[toLinearIndex(index)] = value;
}

int8_t GridMap::getCellSafe(const GridIndex& index, int8_t default_value) const {
    if (!isInside(index)) {
        return default_value;
    }
    return data_[toLinearIndex(index)];
}

// ===== 坐标转换 =====

GridIndex GridMap::worldToGrid(const Point2D& world_point) const {
    if (!isInitialized()) {
        throw std::runtime_error("Map not initialized");
    }
    
    // 考虑原点旋转
    double cos_yaw = std::cos(origin_.yaw);
    double sin_yaw = std::sin(origin_.yaw);
    
    // 转换到地图坐标系
    double dx = world_point.x - origin_.position.x;
    double dy = world_point.y - origin_.position.y;
    
    // 旋转变换
    double map_x = cos_yaw * dx + sin_yaw * dy;
    double map_y = -sin_yaw * dx + cos_yaw * dy;
    
    // 转换为栅格索引
    int grid_x = static_cast<int>(std::floor(map_x / resolution_));
    int grid_y = static_cast<int>(std::floor(map_y / resolution_));
    
    return GridIndex(grid_x, grid_y);
}

Point2D GridMap::gridToWorld(const GridIndex& grid_index) const {
    if (!isInitialized()) {
        throw std::runtime_error("Map not initialized");
    }
    
    // 栅格中心坐标
    double map_x = (grid_index.x + 0.5) * resolution_;
    double map_y = (grid_index.y + 0.5) * resolution_;
    
    // 考虑原点旋转
    double cos_yaw = std::cos(origin_.yaw);
    double sin_yaw = std::sin(origin_.yaw);
    
    // 旋转变换
    double world_x = cos_yaw * map_x - sin_yaw * map_y + origin_.position.x;
    double world_y = sin_yaw * map_x + cos_yaw * map_y + origin_.position.y;
    
    return Point2D(world_x, world_y);
}

bool GridMap::isInside(const GridIndex& index) const {
    return index.x >= 0 && index.x < width_ && 
           index.y >= 0 && index.y < height_;
}

bool GridMap::isInside(const Point2D& world_point) const {
    if (!isInitialized()) {
        return false;
    }
    GridIndex grid_idx = worldToGrid(world_point);
    return isInside(grid_idx);
}

// ===== 地图查询 =====

bool GridMap::isFree(const GridIndex& index) const {
    int8_t value = getCellSafe(index, OCCUPIED);
    return value < OCCUPIED && value != UNKNOWN;
}

bool GridMap::isOccupied(const GridIndex& index) const {
    int8_t value = getCellSafe(index, FREE_SPACE);
    return value >= OCCUPIED;
}

bool GridMap::isUnknown(const GridIndex& index) const {
    int8_t value = getCellSafe(index, FREE_SPACE);
    return value == UNKNOWN;
}

std::vector<GridIndex> GridMap::getFreeNeighbors(const GridIndex& center, int radius) const {
    std::vector<GridIndex> neighbors;
    
    for (int dy = -radius; dy <= radius; ++dy) {
        for (int dx = -radius; dx <= radius; ++dx) {
            if (dx == 0 && dy == 0) continue;
            
            GridIndex neighbor(center.x + dx, center.y + dy);
            if (isInside(neighbor) && isFree(neighbor)) {
                neighbors.push_back(neighbor);
            }
        }
    }
    
    return neighbors;
}

int GridMap::manhattanDistance(const GridIndex& a, const GridIndex& b) {
    return std::abs(a.x - b.x) + std::abs(a.y - b.y);
}

double GridMap::euclideanDistance(const GridIndex& a, const GridIndex& b) const {
    int dx = a.x - b.x;
    int dy = a.y - b.y;
    return std::sqrt(static_cast<double>(dx * dx + dy * dy)) * resolution_;
}

double GridMap::euclideanDistance(const Point2D& a, const Point2D& b) {
    double dx = a.x - b.x;
    double dy = a.y - b.y;
    return std::sqrt(dx * dx + dy * dy);
}

// ===== 地图统计 =====

int GridMap::countFreeCells() const {
    int count = 0;
    for (const auto& cell : data_) {
        if (cell < OCCUPIED && cell != UNKNOWN) {
            ++count;
        }
    }
    return count;
}

int GridMap::countOccupiedCells() const {
    int count = 0;
    for (const auto& cell : data_) {
        if (cell >= OCCUPIED) {
            ++count;
        }
    }
    return count;
}

int GridMap::countUnknownCells() const {
    int count = 0;
    for (const auto& cell : data_) {
        if (cell == UNKNOWN) {
            ++count;
        }
    }
    return count;
}

double GridMap::getCoverage() const {
    if (data_.empty()) return 0.0;
    return static_cast<double>(countFreeCells()) / data_.size();
}

double GridMap::getOccupancyRate() const {
    if (data_.empty()) return 0.0;
    return static_cast<double>(countOccupiedCells()) / data_.size();
}

// ===== 地图操作 =====

void GridMap::clearArea(const GridIndex& center, int radius) {
    for (int dy = -radius; dy <= radius; ++dy) {
        for (int dx = -radius; dx <= radius; ++dx) {
            GridIndex idx(center.x + dx, center.y + dy);
            if (isInside(idx)) {
                data_[toLinearIndex(idx)] = FREE_SPACE;
            }
        }
    }
}

void GridMap::markObstacle(const GridIndex& center, int radius) {
    for (int dy = -radius; dy <= radius; ++dy) {
        for (int dx = -radius; dx <= radius; ++dx) {
            GridIndex idx(center.x + dx, center.y + dy);
            if (isInside(idx)) {
                data_[toLinearIndex(idx)] = OCCUPIED;
            }
        }
    }
}

// ===== 私有辅助函数 =====

size_t GridMap::toLinearIndex(const GridIndex& index) const {
    return static_cast<size_t>(index.y * width_ + index.x);
}

GridIndex GridMap::fromLinearIndex(size_t linear_index) const {
    return GridIndex(
        static_cast<int>(linear_index % width_),
        static_cast<int>(linear_index / width_)
    );
}

} // namespace grid_map