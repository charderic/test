/**
 * @file point_cloud.h
 * @brief 独立点云数据结构 - 不依赖 ROS
 * 
 * 该设计平替 sensor_msgs::PointCloud2，提供核心点云存储和访问功能。
 * 
 * 核心特性：
 * 1. 存储 x, y, z 坐标（使用 costmap2D::Point）
 * 2. 支持迭代器访问
 * 3. 内存连续存储，提高缓存命中率
 * 4. 可选的强度值（intensity）
 */

#ifndef COSTMAP_2D_POINT_CLOUD_H_
#define COSTMAP_2D_POINT_CLOUD_H_

#include <vector>
#include <cstdint>
#include <stdexcept>
#include <costmap_2d/costmap_2d.h>

namespace costmap2D
{

/**
 * @class PointCloud
 * @brief 点云数据容器
 * 
 * 提供点云数据的存储、访问和迭代功能。
 * 使用 costmap2D::Point 作为点数据结构。
 */
class PointCloud
{
public:
    // ===== 构造函数 =====
    
    /**
     * @brief 默认构造函数
     */
    PointCloud() : has_intensity_(false) {}
    
    /**
     * @brief 构造函数 - 指定是否包含强度值
     * @param has_intensity 是否包含强度值
     */
    explicit PointCloud(bool has_intensity) : has_intensity_(has_intensity) {}
    
    /**
     * @brief 构造函数 - 预分配空间
     * @param size 预分配的点数量
     * @param has_intensity 是否包含强度值
     */
    PointCloud(size_t size, bool has_intensity = false)
        : has_intensity_(has_intensity)
    {
        points_.reserve(size);
    }
    
    /**
     * @brief 拷贝构造函数
     * @param other 点云对象
     */
    PointCloud(const PointCloud& other)
        : points_(other.points_)
        , has_intensity_(other.has_intensity_)
    {
    }
    
    /**
     * @brief 赋值运算符
     * @param other 点云对象
     * @return *this
     */
    PointCloud& operator=(const PointCloud& other)
    {
        if (this != &other)
        {
            points_ = other.points_;
            has_intensity_ = other.has_intensity_;
        }
        return *this;
    }
    
    // ===== 数据访问 =====
    
    /**
     * @brief 添加一个点
     * @param x X 坐标
     * @param y Y 坐标
     * @param z Z 坐标
     * @param intensity 强度值（可选）
     */
    void addPoint(double x, double y, double z, double intensity = 0.0)
    {
        Point p;
        p.x = x;
        p.y = y;
        p.z = z;
        p.intensity = intensity;
        points_.push_back(p);
    }
    
    /**
     * @brief 添加一个点
     * @param point 点数据
     */
    void addPoint(const Point& point)
    {
        points_.push_back(point);
    }
    
    /**
     * @brief 获取点数量
     * @return 点数量
     */
    size_t size() const { return points_.size(); }
    
    /**
     * @brief 清空点云
     */
    void clear() { points_.clear(); }
    
    /**
     * @brief 预分配空间
     * @param size 预分配的点数量
     */
    void reserve(size_t size) { points_.reserve(size); }
    
    /**
     * @brief 检查是否为空
     * @return true 如果点云为空
     */
    bool empty() const { return points_.empty(); }
    
    /**
     * @brief 获取是否包含强度值
     * @return true 如果包含强度值
     */
    bool hasIntensity() const { return has_intensity_; }
    
    /**
     * @brief 设置是否包含强度值
     * @param has_intensity 是否包含强度值
     */
    void setHasIntensity(bool has_intensity) { has_intensity_ = has_intensity; }
    
    // ===== 索引访问 =====
    
    /**
     * @brief 获取指定索引的点（非 const）
     * @param index 点索引
     * @return 点引用
     */
    Point& operator[](size_t index)
    {
        if (index >= points_.size())
        {
            throw std::out_of_range("PointCloud index out of range");
        }
        return points_[index];
    }
    
    /**
     * @brief 获取指定索引的点（const）
     * @param index 点索引
     * @return 点引用
     */
    const Point& operator[](size_t index) const
    {
        if (index >= points_.size())
        {
            throw std::out_of_range("PointCloud index out of range");
        }
        return points_[index];
    }
    
    // ===== 迭代器支持 =====
    
    /**
     * @brief 迭代器类型定义
     */
    typedef std::vector<Point>::iterator iterator;
    typedef std::vector<Point>::const_iterator const_iterator;
    
    /**
     * @brief 获取起始迭代器
     * @return 起始迭代器
     */
    iterator begin() { return points_.begin(); }
    
    /**
     * @brief 获取结束迭代器
     * @return 结束迭代器
     */
    iterator end() { return points_.end(); }
    
    /**
     * @brief 获取起始迭代器（const）
     * @return 起始迭代器
     */
    const_iterator begin() const { return points_.begin(); }
    
    /**
     * @brief 获取结束迭代器（const）
     * @return 结束迭代器
     */
    const_iterator end() const { return points_.end(); }
    
    /**
     * @brief 获取起始迭代器（const）
     * @return 起始迭代器
     */
    const_iterator cbegin() const { return points_.cbegin(); }
    
    /**
     * @brief 获取结束迭代器（const）
     * @return 结束迭代器
     */
    const_iterator cend() const { return points_.cend(); }
    
    // ===== 数据指针访问 =====
    
    /**
     * @brief 获取点数据指针
     * @return 点数据指针
     */
    Point* data() { return points_.data(); }
    
    /**
     * @brief 获取点数据指针（const）
     * @return 点数据指针
     */
    const Point* data() const { return points_.data(); }
    
private:
    std::vector<Point> points_;  ///< 点数据数组（使用 costmap2D::Point）
    bool has_intensity_;          ///< 是否包含强度值
};

}  // namespace costmap2D

#endif  // COSTMAP_2D_POINT_CLOUD_H_