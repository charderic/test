/**
 * @file obstacle_layer1.h
 * @brief 障碍物层去ROS依赖版本
 * 
 * 功能：
 * 1. 自定义数据结构替代 ROS 消息（LaserScan, Pose）
 * 2. 存储传感器观测数据到队列
 * 3. 时间戳对齐机制
 * 4. 坐标变换到全局坐标系
 * 5. 障碍物标记与膨胀
 */

#ifndef COSTMAP_2D_OBSTACLE_LAYER1_H_
#define COSTMAP_2D_OBSTACLE_LAYER1_H_

#include <costmap_2d/costmap_layer.h>
#include <costmap_2d/layered_costmap.h>
#include <costmap_2d/point_cloud.h>
#include <costmap_2d/costmap_2d.h>
#include <boost/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <vector>
#include <queue>
#include <memory>
#include <cmath>
#include <ctime>

namespace costmap2D
{

/**
 * @struct LaserScanData
 * @brief 激光扫描数据结构 - 替代 sensor_msgs::LaserScan
 */
struct LaserScanData
{
  double angle_min_;           // 起始角度 (rad)
  double angle_max_;           // 结束角度 (rad)
  double angle_increment_;     // 角度增量 (rad)
  double time_increment_;      // 时间增量 (s)
  double scan_time_;           // 扫描时间 (s)
  double range_min_;           // 最小距离 (m)
  double range_max_;           // 最大距离 (m)
  std::vector<float> ranges_;  // 距离数组
  std::vector<float> intensities_; // 强度数组 (可选)
  
  std::string frame_id_;       // 坐标系
  uint64_t timestamp_ns_;     // 时间戳 (纳秒)
  
  LaserScanData() 
    : angle_min_(0), angle_max_(0), angle_increment_(0), time_increment_(0)
    , scan_time_(0), range_min_(0), range_max_(0), timestamp_ns_(0)
  {}
  
  bool isValid() const 
  { 
    return !ranges_.empty() && range_max_ > range_min_ && timestamp_ns_ > 0; 
  }
  
  size_t getSize() const { return ranges_.size(); }
};

/**
 * @struct RobotPose
 * @brief 机器人位姿数据结构 - 替代 geometry_msgs::Pose
 */
struct RobotPose
{
  double x_;           // X 坐标 (m)
  double y_;           // Y 坐标 (m)
  double theta_;        // 朝向角 (rad)
  uint64_t timestamp_ns_; // 时间戳 (纳秒)
  
  RobotPose() : x_(0), y_(0), theta_(0), timestamp_ns_(0) {}
  
  RobotPose(double x, double y, double theta, uint64_t ts)
    : x_(x), y_(y), theta_(theta), timestamp_ns_(ts) {}
  
  bool isValid() const { return timestamp_ns_ > 0; }
};

/**
 * @struct Point2D
 * @brief 2D 点结构
 */
struct Point2D
{
  double x, y;
  Point2D() : x(0), y(0) {}
  Point2D(double _x, double _y) : x(_x), y(_y) {}
};

/**
 * @class LaserScanQueue
 * @brief 激光扫描数据队列 - 线程安全存储
 */
class LaserScanQueue
{
public:
  void push(const LaserScanData& scan)
  {
    boost::mutex::scoped_lock lock(mutex_);
    queue_.push(scan);
  }
  
  bool tryPop(LaserScanData& scan)
  {
    boost::mutex::scoped_lock lock(mutex_);
    if (queue_.empty()) return false;
    scan = queue_.front();
    queue_.pop();
    return true;
  }
  
  bool empty() const
  {
    boost::mutex::scoped_lock lock(mutex_);
    return queue_.empty();
  }
  
  size_t size() const
  {
    boost::mutex::scoped_lock lock(mutex_);
    return queue_.size();
  }
  
  void clear()
  {
    boost::mutex::scoped_lock lock(mutex_);
    while (!queue_.empty()) queue_.pop();
  }

private:
  std::queue<LaserScanData> queue_;
  mutable boost::mutex mutex_;
};

/**
 * @class RobotPoseQueue
 * @brief 机器人位姿数据队列 - 线程安全存储
 */
class RobotPoseQueue
{
public:
  void push(const RobotPose& pose)
  {
    boost::mutex::scoped_lock lock(mutex_);
    queue_.push(pose);
  }
  
  bool tryPop(RobotPose& pose)
  {
    boost::mutex::scoped_lock lock(mutex_);
    if (queue_.empty()) return false;
    pose = queue_.front();
    queue_.pop();
    return true;
  }
  
  bool empty() const
  {
    boost::mutex::scoped_lock lock(mutex_);
    return queue_.empty();
  }
  
  size_t size() const
  {
    boost::mutex::scoped_lock lock(mutex_);
    return queue_.size();
  }
  
  void clear()
  {
    boost::mutex::scoped_lock lock(mutex_);
    while (!queue_.empty()) queue_.pop();
  }

private:
  std::queue<RobotPose> queue_;
  mutable boost::mutex mutex_;
};

// 前向声明
class Observation;

/**
 * @class ObstacleLayer
 * @brief 障碍物层类 - 处理动态障碍物的检测与更新
 * 
 * 继承自 CostmapLayer，替代 ROS 版本的 ObstacleLayer。
 * 核心功能：
 * 1. 处理激光扫描数据，标记障碍物
 * 2. 射线追踪清除自由空间
 * 3. 与 InflationLayer 协作输出膨胀后的代价地图
 */
class ObstacleLayer : public CostmapLayer
{
public:
  /**
   * @brief 默认构造函数
   */
  ObstacleLayer();
  
  /**
   * @brief 析构函数
   */
  virtual ~ObstacleLayer();
  
  /**
   * @brief 初始化图层
   * @param parent 父分层代价地图指针
   * @param name 图层名称
   * @param tf 坐标变换缓冲区 (暂时未用)
   */
  virtual void onInitialize();
  
  /**
   * @brief 更新边界
   * @param robot_x 机器人 X 坐标 (世界坐标)
   * @param robot_y 机器人 Y 坐标 (世界坐标)
   * @param robot_yaw 机器人航向角 (弧度)
   * @param min_x 输出：最小 X 边界
   * @param min_y 输出：最小 Y 边界
   * @param max_x 输出：最大 X 边界
   * @param max_y 输出：最大 Y 边界
   */
  virtual void updateBounds(double robot_x, double robot_y, double robot_yaw,
                           double* min_x, double* min_y, double* max_x, double* max_y);
  
  /**
   * @brief 更新代价
   * @param master_grid 主代价地图
   * @param min_i 更新区域最小列索引
   * @param min_j 更新区域最小行索引
   * @param max_i 更新区域最大列索引
   * @param max_j 更新区域最大行索引
   */
  virtual void updateCosts(costmap2D::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);
  
  /**
   * @brief 激活图层
   */
  virtual void activate();
  
  /**
   * @brief 停用图层
   */
  virtual void deactivate();
  
  /**
   * @brief 重置图层
   */
  virtual void reset();
  
  /**
   * @brief 处理激光扫描数据
   * @param scan 激光扫描数据
   * @param robot_pose 机器人位姿
   * @param sensor_mount_angle 传感器安装角度偏移 (rad)
   */
  void incomingLaserScan(const LaserScanData& scan, const RobotPose& robot_pose, double sensor_mount_angle = 0.0);
  
  /**
   * @brief 设置障碍物检测范围
   * @param range 范围 (米)
   */
  void setObstacleRange(double range) { obstacle_range_ = range; }
  
  /**
   * @brief 设置射线追踪范围
   * @param range 范围 (米)
   */
  void setRaytraceRange(double range) { raytrace_range_ = range; }
  
  /**
   * @brief 设置时间戳对齐容差
   * @param tolerance_ns 容差 (纳秒)
   */
  void setTimestampTolerance(uint64_t tolerance_ns) { timestamp_tolerance_ns_ = tolerance_ns; }

protected:
  /**
   * @brief 获取标记观测数据
   */
  bool getMarkingObservations(std::vector<Observation>& marking_observations) const;
  
  /**
   * @brief 获取清除观测数据
   */
  bool getClearingObservations(std::vector<Observation>& clearing_observations) const;
  
  /**
   * @brief 射线追踪清除自由空间
   */
  void raytraceFreespace(const Observation& clearing_observation, double* min_x, double* min_y,
                         double* max_x, double* max_y);

private:
  /**
   * @brief 将激光扫描转换为点云
   */
  PointCloud laserScanToPointCloud(const LaserScanData& scan);
  
  /**
   * @brief 将点从传感器坐标系转换到全局坐标系
   */
  void transformPoint(double wx, double wy, double ox, double oy, double theta,
                     double& tx, double& ty);
  
  /**
   * @brief 射线追踪划线 (Bresenham算法)
   */
  void raytraceLine(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1);

  // ===== 配置参数 =====
  double obstacle_range_;     // 障碍物检测范围 (m)
  double raytrace_range_;     // 射线追踪范围 (m)
  double max_obstacle_height_; // 最大障碍物高度 (m)
  uint64_t timestamp_tolerance_ns_; // 时间戳对齐容差 (ns)
  
  // ===== 观测数据 =====
  std::vector<Observation> observations_; // 当前观测数据列表
  
  // ===== 状态标志 =====
  bool rolling_window_;  // 是否滚动窗口模式
  bool footprint_clearing_enabled_; // 是否启用足迹清除
  std::vector<Point> transformed_footprint_; // 转换后的足迹
};

/**
 * @class Observation
 * @brief 观测数据类 - 封装单次传感器观测信息
 */
class Observation
{
public:
  Point origin_;          // 传感器原点 (全局坐标系)
  boost::shared_ptr<PointCloud> cloud_;     // 点云数据
  double obstacle_range_; // 障碍物范围
  double raytrace_range_; // 射线追踪范围
  
  Observation() : cloud_(new PointCloud()), obstacle_range_(0), raytrace_range_(0) {}
  
  Observation(Point& origin, boost::shared_ptr<PointCloud>& cloud, double obs_range, double ray_range)
    : origin_(origin), cloud_(cloud)
    , obstacle_range_(obs_range), raytrace_range_(ray_range) {}
  
  virtual ~Observation() { /* 使用 shared_ptr 自动释放 */ }
};

} // namespace costmap2D

#endif // COSTMAP_2D_OBSTACLE_LAYER1_H_
