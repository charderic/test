/**
 * @file static_layer1.h
 * @brief 无 ROS 依赖的静态层头文件
 * 
 * 设计要点：
 * 1. 使用自定义 OccupancyGridData 数据结构替代 nav_msgs::OccupancyGrid
 * 2. incomingMap 改为普通成员函数（非回调），入参为自定义数据结构
 * 3. 完全去除 ROS 依赖
 */

#ifndef COSTMAP_2D_STATIC_LAYER1_H_
#define COSTMAP_2D_STATIC_LAYER1_H_

#include <costmap_2d/costmap_layer.h>
#include <costmap_2d/layered_costmap.h>
#include <vector>
#include <string>

namespace costmap2D
{

// ============================================================================
// 常量定义
// ============================================================================

/**
 * @brief OccupancyGrid 栅格值常量
 * 
 * 与 nav_msgs::OccupancyGrid 保持一致：
 * - -1: 未知区域
 * - 0: 自由空间
 * - 1~100: 占用概率
 */
namespace OccupancyValues
{
  const int8_t FREE_SPACE = 0;        ///< 自由空间
  const int8_t UNKNOWN = -1;          ///< 未知区域
  const int8_t OCCUPIED = 100;       ///< 障碍物（占用）
}

// ============================================================================
// 数据结构定义
// ============================================================================

/**
 * @struct OccupancyGridMeta
 * @brief 栅格地图元信息结构
 * 
 * 替代 nav_msgs::MapMetaData，存储地图的基本参数信息。
 */
struct OccupancyGridMeta
{
  std::string frame_id;    ///< 坐标系名称（如 "map"）
  double timestamp;         ///< 时间戳（秒，从 epoch 开始）
  
  OccupancyGridMeta() : timestamp(0.0) {}
};

/**
 * @class OccupancyGridData
 * @brief 栅格地图数据类
 * 
 * 替代 nav_msgs::OccupancyGrid（包含 data 和 info 两部分）。
 * 继承自 std::vector<int8_t>，直接存储原始栅格数据。
 * 
 * 栅格值定义：
 *   - -1: 未知区域
 *   - 0: 自由空间
 *   - 1~100: 占用概率（数值越大，障碍物概率越高）
 */
class OccupancyGridData : public std::vector<int8_t>
{
public:
  /**
   * @brief 构造函数
   */
  OccupancyGridData();
  
  /**
   * @brief 析构函数
   */
  virtual ~OccupancyGridData();
  
  // ===== 元信息 =====
  
  const OccupancyGridMeta& getMeta() const { return meta_; }
  OccupancyGridMeta& getMeta() { return meta_; }
  
  const std::string& getFrameId() const { return meta_.frame_id; }
  void setFrameId(const std::string& frame_id) { meta_.frame_id = frame_id; }
  
  double getTimestamp() const { return meta_.timestamp; }
  void setTimestamp(double timestamp) { meta_.timestamp = timestamp; }
  
  // ===== 地图信息 =====
  
  unsigned int getWidth() const { return size_x_; }
  unsigned int getHeight() const { return size_y_; }
  double getResolution() const { return resolution_; }
  double getOriginX() const { return origin_x_; }
  double getOriginY() const { return origin_y_; }
  
  /**
   * @brief 设置地图基本信息
   * @param width 宽度（像素）
   * @param height 高度（像素）
   * @param resolution 分辨率（米/像素）
   * @param origin_x 原点X（米）
   * @param origin_y 原点Y（米）
   */
  void setGridInfo(unsigned int width, unsigned int height, double resolution,
                   double origin_x, double origin_y);
  
  /**
   * @brief 检查数据是否有效
   * @return true 如果尺寸和数据匹配
   */
  bool isValid() const;
  
  /**
   * @brief 清空数据
   */
  void clear();
  
protected:
  OccupancyGridMeta meta_;              ///< 元信息
  unsigned int size_x_;                  ///< 宽度
  unsigned int size_y_;                  ///< 高度
  double resolution_;                    ///< 分辨率
  double origin_x_;                      ///< 原点X
  double origin_y_;                      ///< 原点Y
};

// ============================================================================
// StaticLayer 类
// ============================================================================

/**
 * @class StaticLayer
 * @brief 静态地图层
 * 
 * 继承自 CostmapLayer，负责加载和处理静态地图。
 */
class StaticLayer : public CostmapLayer
{
public:
  /**
   * @brief 构造函数
   */
  StaticLayer();
  
  /**
   * @brief 析构函数
   */
  virtual ~StaticLayer();
  
  /**
   * @brief 初始化静态层
   */
  virtual void onInitialize();
  
  /**
   * @brief 激活静态层
   */
  virtual void activate();
  
  /**
   * @brief 停用静态层
   */
  virtual void deactivate();
  
  /**
   * @brief 重置静态层
   */
  virtual void reset();
  
  /**
   * @brief 更新边界
   */
  virtual void updateBounds(double robot_x, double robot_y, double robot_yaw, 
                          double* min_x, double* min_y, double* max_x, double* max_y);
  
  /**
   * @brief 更新代价
   */
  virtual void updateCosts(costmap2D::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);
  
  /**
   * @brief 匹配主代价地图尺寸
   */
  virtual void matchSize();
  
  // ===== incomingMap 改为公开的普通成员函数 =====
  
  /**
   * @brief 处理新地图数据（非回调函数）
   * 
   * 替代原来的 ROS 回调函数 incomingMap(const nav_msgs::OccupancyGridConstPtr&)
   * 此函数为普通成员函数，可直接调用。
   * 
   * @param new_map 新地图数据
   */
  void incomingMap(const OccupancyGridData& new_map);
  
  // ===== 辅助方法 =====
  
  /**
   * @brief 直接设置地图数据
   * @param grid 栅格地图数据
   */
  void setMap(const OccupancyGridData& grid);

protected:
  /**
   * @brief 将地图原始值转换为代价地图值
   * 
   * OccupancyGrid 值（-1, 0-100）→ Costmap2D 值（0, 255, 1-253）
   * 
   * @param value 地图原始值
   * @return 转换后的代价值
   */
  unsigned char interpretValue(unsigned char value);
  
private:
  std::string global_frame_;        ///< 全局坐标系名称
  std::string map_frame_;           ///< 地图坐标系名称
  bool map_received_;               ///< 是否已收到地图
  bool has_updated_data_;           ///< 是否有新数据需要更新
  bool first_map_only_;            ///< 是否只使用第一张地图
  bool track_unknown_space_;        ///< 是否跟踪未知空间
  bool use_maximum_;               ///< 是否取最大值融合
  bool trinary_costmap_;           ///< 是否使用三值化模式
  unsigned char lethal_threshold_;  ///< 障碍物阈值
  int8_t unknown_cost_value_;      ///< 未知区域原始值
  
  // ===== 更新区域 =====
  unsigned int update_x_;           ///< 更新区域左上角X
  unsigned int update_y_;           ///< 更新区域左上角Y
  unsigned int update_width_;       ///< 更新区域宽度
  unsigned int update_height_;      ///< 更新区域高度
};

// ============================================================================
// 实现：OccupancyGridData
// ============================================================================

inline OccupancyGridData::OccupancyGridData()
  : std::vector<int8_t>(), size_x_(0), size_y_(0), resolution_(0.0), origin_x_(0.0), origin_y_(0.0)
{
}

inline OccupancyGridData::~OccupancyGridData()
{
}

inline void OccupancyGridData::setGridInfo(unsigned int width, unsigned int height, 
                                           double resolution, double origin_x, double origin_y)
{
  size_x_ = width;
  size_y_ = height;
  resolution_ = resolution;
  origin_x_ = origin_x;
  origin_y_ = origin_y;
  resize(width * height);
}

inline bool OccupancyGridData::isValid() const
{
  return size_x_ > 0 && size_y_ > 0 && size() == size_x_ * size_y_;
}

inline void OccupancyGridData::clear()
{
  std::vector<int8_t>::clear();
  meta_ = OccupancyGridMeta();
  size_x_ = size_y_ = 0;
  resolution_ = origin_x_ = origin_y_ = 0.0;
}

}  // namespace costmap2D

#endif  // COSTMAP_2D_STATIC_LAYER1_H_
