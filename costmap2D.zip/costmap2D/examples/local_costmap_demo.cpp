/**
 * @file local_costmap_demo.cpp
 * @brief 局部代价地图 Demo - 订阅真实 ROS 话题
 * 
 * 功能：
 * 1. 订阅 /scan (激光扫描) 和 /amcl_pose (机器人位姿)
 * 2. 将 ROS 消息转换为自定义数据结构
 * 3. 时间戳对齐机制
 * 4. 通过 ObstacleLayer 处理障碍物
 * 5. 通过 InflationLayer 膨胀输出局部代价地图
 * 
 * 输出：
 * - /Zylocalmap: 局部代价地图话题 (ROS)
 */

#include <ros/ros.h>
#include <nav_msgs/OccupancyGrid.h>
#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <costmap_2d/obstacle_layer.h>
#include <costmap_2d/inflation_layer.h>
#include <costmap_2d/layered_costmap.h>
#include <iostream>
#include <vector>
#include <cmath>
#include <boost/thread.hpp>

namespace costmap2D
{

/**
 * @brief 获取当前时间戳 (纳秒)
 */
uint64_t getCurrentTimestampNs()
{
  struct timespec ts;
  clock_gettime(CLOCK_REALTIME, &ts);
  return static_cast<uint64_t>(ts.tv_sec) * 1000000000ULL + static_cast<uint64_t>(ts.tv_nsec);
}

} // namespace costmap2D

// 全局变量用于存储订阅到的数据
static costmap2D::LaserScanData g_laser_scan;
static costmap2D::RobotPose g_robot_pose;
static bool g_laser_received = false;
static bool g_pose_received = false;
static boost::mutex g_data_mutex;

// 记录已使用的时间戳，用于等待更新
static uint64_t g_used_laser_timestamp = 0;
static uint64_t g_used_pose_timestamp = 0;

// 时间戳对齐容差 (纳秒)
static uint64_t g_timestamp_tolerance_ns = 200000000;  // 200ms

/**
 * @brief 激光扫描回调函数
 * 将 ROS LaserScan 消息转换为自定义 LaserScanData 结构
 */
void laserScanCallback(const sensor_msgs::LaserScan::ConstPtr& msg)
{
  boost::unique_lock<boost::mutex> lock(g_data_mutex);
  
  costmap2D::LaserScanData scan;
  
  // 转换角度范围
  scan.angle_min_ = msg->angle_min;
  scan.angle_max_ = msg->angle_max;
  scan.angle_increment_ = msg->angle_increment;
  scan.range_min_ = msg->range_min;
  scan.range_max_ = msg->range_max;
  
  // 使用消息时间戳
  scan.timestamp_ns_ = static_cast<uint64_t>(msg->header.stamp.sec) * 1000000000ULL + 
                       static_cast<uint64_t>(msg->header.stamp.nsec);
  scan.frame_id_ = msg->header.frame_id;
  
  // 转换距离数据
  scan.ranges_.resize(msg->ranges.size());
  for (size_t i = 0; i < msg->ranges.size(); ++i)
  {
    scan.ranges_[i] = msg->ranges[i];
  }
  
  g_laser_scan = scan;
  g_laser_received = true;
}

/**
 * @brief 机器人位姿回调函数
 * 将 ROS PoseWithCovarianceStamped 消息转换为自定义 RobotPose 结构
 */
void poseCallback(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& msg)
{
  boost::unique_lock<boost::mutex> lock(g_data_mutex);
  
  costmap2D::RobotPose pose;
  
  // 转换位置
  pose.x_ = msg->pose.pose.position.x;
  pose.y_ = msg->pose.pose.position.y;
  
  // 转换朝向 (从四元数)
  double qx = msg->pose.pose.orientation.x;
  double qy = msg->pose.pose.orientation.y;
  double qz = msg->pose.pose.orientation.z;
  double qw = msg->pose.pose.orientation.w;
  
  // 四元数转欧拉角 (yaw)
  pose.theta_ = atan2(2.0 * (qw * qz + qx * qy), 1.0 - 2.0 * (qy * qy + qz * qz));
  
  // 使用消息时间戳
  pose.timestamp_ns_ = static_cast<uint64_t>(msg->header.stamp.sec) * 1000000000ULL + 
                       static_cast<uint64_t>(msg->header.stamp.nsec);
  
  g_robot_pose = pose;
  g_pose_received = true;
}

int main(int argc, char** argv)
{
  // ========== ROS 初始化 ==========
  ros::init(argc, argv, "local_costmap_demo");
  ros::NodeHandle nh;
  ros::NodeHandle private_nh("~");
  
  // 获取参数
  std::string laser_topic = "/scan";
  std::string pose_topic = "/amcl_pose";
  std::string costmap_topic = "/LocalCostMap";
  
  private_nh.param<std::string>("laser_topic", laser_topic, "/scan");
  private_nh.param<std::string>("pose_topic", pose_topic, "/amcl_pose");
  private_nh.param<std::string>("costmap_topic", costmap_topic, "/LocalCostMap");
  
  int timestamp_tolerance_ms = 600000;  // 10分钟容差（因为不同系统时间可能不同步）
  private_nh.param<int>("timestamp_tolerance_ms", timestamp_tolerance_ms, 600000);
  g_timestamp_tolerance_ns = static_cast<uint64_t>(timestamp_tolerance_ms) * 1000000;
  
  // 传感器安装角度偏移（弧度），根据激光雷达实际安装方向调整
  double sensor_mount_angle = 0.0;
  private_nh.param<double>("sensor_mount_angle", sensor_mount_angle, 0.0);
  ROS_INFO("  传感器安装角度偏移: %.2f rad (%.2f deg)", sensor_mount_angle, sensor_mount_angle * 180.0 / M_PI);
  
  double inflation_radius = 0.5;
  double cost_scaling = 10.0;
  private_nh.param<double>("inflation_radius", inflation_radius, 0.5);
  private_nh.param<double>("cost_scaling", cost_scaling, 10.0);
  
  ROS_INFO("========================================");
  ROS_INFO("  ObstacleLayer + InflationLayer Demo");
  ROS_INFO("========================================");
  ROS_INFO("  激光话题: %s", laser_topic.c_str());
  ROS_INFO("  位姿话题: %s", pose_topic.c_str());
  ROS_INFO("  代价地图话题: %s", costmap_topic.c_str());
  ROS_INFO("  时间戳容差: %.1f ms", g_timestamp_tolerance_ns / 1e6);
  ROS_INFO("========================================");
  
  // ========== 创建分层代价地图 (局部地图) ==========
  ROS_INFO("[Demo] 创建局部代价地图...");
  
  // 局部地图配置 - 滚动窗口，机器人始终在中心
  double local_width = 5.0;    // 5米宽
  double local_height = 5.0;    // 5米高
  double resolution = 0.05;     // 5cm 分辨率
  
  // 启用滚动窗口 (rolling_window = true)
  // 参数: global_frame_id="map", rolling_window=true, track_unknown=false
  costmap2D::LayeredCostmap layered_costmap("map", true, false);
  
  // 设置主代价地图尺寸 (滚动窗口地图，原点在左下角)
  layered_costmap.getCostmap()->resizeMap(
    static_cast<unsigned int>(local_width / resolution),
    static_cast<unsigned int>(local_height / resolution),
    resolution, 0, 0);
  
  // ========== 创建图层 ==========
  ROS_INFO("[Demo] 创建 ObstacleLayer...");
  costmap2D::ObstacleLayer* obstacle_layer = new costmap2D::ObstacleLayer();
  
  ROS_INFO("[Demo] 创建 InflationLayer...");
  costmap2D::InflationLayer* inflation_layer = new costmap2D::InflationLayer(inflation_radius, cost_scaling, false);
  
  // 使用 shared_ptr 管理
  boost::shared_ptr<costmap2D::Layer> obs_ptr(obstacle_layer);
  boost::shared_ptr<costmap2D::Layer> inf_ptr(inflation_layer);
  
  // ========== 添加图层 (顺序很重要!) ==========
  // ObstacleLayer 先添加（先生成障碍物）
  layered_costmap.addPlugin(obs_ptr);
  // InflationLayer 后添加（后膨胀）
  layered_costmap.addPlugin(inf_ptr);
  
  // ========== 初始化图层 ==========
  // 1. 先初始化 InflationLayer（参考 inflation_demo.cpp）
  ROS_INFO("[Demo] 初始化 InflationLayer...");
  inflation_layer->initialize(&layered_costmap, "inflation_layer", NULL);
  inflation_layer->matchSize();  // 确保 InflationLayer 正确初始化缓存
  inflation_layer->setEnabled(true);  // 启用膨胀层
  
  // 2. 再初始化 ObstacleLayer
  ROS_INFO("[Demo] 初始化 ObstacleLayer...");
  obstacle_layer->initialize(&layered_costmap, "obstacle_layer", NULL);
  
  // 手动调用 matchSize() 确保 ObstacleLayer 正确初始化 costmap_
  obstacle_layer->matchSize();
  
  obstacle_layer->setEnabled(true);
  obstacle_layer->activate();
  
  // 设置障碍物层参数
  obstacle_layer->setObstacleRange(5.0);   // 5米检测范围
  obstacle_layer->setRaytraceRange(6.0);   // 6米追踪范围
  obstacle_layer->setTimestampTolerance(g_timestamp_tolerance_ns);
  
  // ========== 创建订阅者 ==========
  ROS_INFO("[Demo] 订阅激光话题: %s", laser_topic.c_str());
  ros::Subscriber laser_sub = nh.subscribe(laser_topic, 10, laserScanCallback);
  
  ROS_INFO("[Demo] 订阅位姿话题: %s", pose_topic.c_str());
  ros::Subscriber pose_sub = nh.subscribe(pose_topic, 10, poseCallback);
  
  // ========== 创建代价地图发布器 ==========
  ros::Publisher costmap_pub = nh.advertise<nav_msgs::OccupancyGrid>(costmap_topic, 1, true);
  ROS_INFO("[Demo] 发布代价地图话题: %s", costmap_topic.c_str());
  
  // ========== 代价地图元数据 ==========
  nav_msgs::MapMetaData map_meta;
  map_meta.resolution = resolution;
  map_meta.width = layered_costmap.getCostmap()->getSizeInCellsX();
  map_meta.height = layered_costmap.getCostmap()->getSizeInCellsY();
  map_meta.origin.position.x = 0;
  map_meta.origin.position.y = 0;
  map_meta.origin.position.z = 0.0;
  map_meta.origin.orientation.w = 1.0;
  
  // 等待数据
  ROS_INFO("[Demo] 等待接收激光和位姿数据...");
  int wait_count = 0;
  while (ros::ok())
  {
    ros::spinOnce();
    
    boost::unique_lock<boost::mutex> lock(g_data_mutex);
    bool ready = g_laser_received && g_pose_received;
    lock.unlock();
    
    if (ready)
    {
      ROS_INFO("[Demo] 接收到数据，开始处理!");
      break;
    }
    
    if (++wait_count > 100)
    {
      ROS_WARN("[Demo] 等待超时，继续运行...");
      break;
    }
    
    ros::Duration(0.1).sleep();
  }
  
  ROS_INFO("[Demo] ========== 开始处理 ==========");
  
  // ========== 主循环 ==========
  ros::Rate rate(10);  // 10 Hz
  int update_count = 0;
  
  while (ros::ok())
  {
    ros::spinOnce();
    
    // 获取数据副本进行对齐处理
    costmap2D::LaserScanData laser_data;
    costmap2D::RobotPose pose_data;
    bool data_ready = false;
    bool data_new = false;
    
    {
      boost::unique_lock<boost::mutex> lock(g_data_mutex);
      if (g_laser_received && g_pose_received)
      {
        // 检查是否有新数据
        bool laser_new = (g_laser_scan.timestamp_ns_ > g_used_laser_timestamp);
        bool pose_new = (g_robot_pose.timestamp_ns_ > g_used_pose_timestamp);
        
        if (laser_new && pose_new)
        {
          laser_data = g_laser_scan;
          pose_data = g_robot_pose;
          data_ready = true;
          data_new = true;
        }
      }
    }
    
    if (!data_ready)
    {
      rate.sleep();
      continue;
    }
    
    // ========== 时间戳对齐检查 ==========
    int64_t time_diff = static_cast<int64_t>(laser_data.timestamp_ns_) - static_cast<int64_t>(pose_data.timestamp_ns_);
    if (time_diff < 0) time_diff = -time_diff;
    
    if (time_diff > g_timestamp_tolerance_ns)
    {
      // 时间戳不对齐，判断哪个时间戳更小，等待新数据
      const char* wait_topic = NULL;
      {
        boost::unique_lock<boost::mutex> lock(g_data_mutex);
        if (laser_data.timestamp_ns_ < pose_data.timestamp_ns_)
        {
          // 激光时间戳更小，等待新的激光数据
          wait_topic = "laser";
        }
        else
        {
          // 位姿时间戳更小，等待新的位姿数据
          wait_topic = "pose";
        }
      }
      
      if (update_count % 50 == 0)
      {
        ROS_WARN("[Demo] 时间戳不对齐: %ld ms, 等待 %s 新数据...", time_diff / 1000000, wait_topic);
      }
      rate.sleep();
      continue;
    }
    
    // ========== 记录已使用的时间戳 ==========
    {
      boost::unique_lock<boost::mutex> lock(g_data_mutex);
      g_used_laser_timestamp = laser_data.timestamp_ns_;
      g_used_pose_timestamp = pose_data.timestamp_ns_;
    }
    
    // ========== 处理激光扫描 ==========
    obstacle_layer->incomingLaserScan(laser_data, pose_data, sensor_mount_angle);
    
    // ========== 更新代价地图 ==========
    layered_costmap.updateMap(pose_data.x_, pose_data.y_, pose_data.theta_);
    
    // 调试：打印机器人位置和地图原点
    static int debug_count = 0;
    if (debug_count++ < 3) {
      costmap2D::Costmap2D* costmap = layered_costmap.getCostmap();
      printf("[Demo] 机器人位置: (%.2f, %.2f), 地图原点: (%.2f, %.2f), 地图尺寸: %dx%d\n",
             pose_data.x_, pose_data.y_, 
             costmap->getOriginX(), costmap->getOriginY(),
             costmap->getSizeInCellsX(), costmap->getSizeInCellsY());
    }
    
    // ========== 发布代价地图 ==========
    nav_msgs::OccupancyGrid costmap_msg;
    costmap_msg.header.stamp = ros::Time::now();
    costmap_msg.header.frame_id = "map";
    
    // 更新代价地图元数据，使用当前地图的真实原点（支持滚动窗口）
    nav_msgs::MapMetaData current_map_meta;
    current_map_meta.resolution = resolution;
    current_map_meta.width = layered_costmap.getCostmap()->getSizeInCellsX();
    current_map_meta.height = layered_costmap.getCostmap()->getSizeInCellsY();
    current_map_meta.origin.position.x = layered_costmap.getCostmap()->getOriginX();
    current_map_meta.origin.position.y = layered_costmap.getCostmap()->getOriginY();
    current_map_meta.origin.position.z = 0.0;
    current_map_meta.origin.orientation.w = 1.0;
    costmap_msg.info = current_map_meta;
    
    costmap_msg.data.resize(current_map_meta.width * current_map_meta.height);
    unsigned char* data = layered_costmap.getCostmap()->getCharMap();
    int count_100 = 0, count_99 = 0, count_other = 0, count_0 = 0, count_255 = 0;
    for (size_t i = 0; i < costmap_msg.data.size(); ++i)
    {
      unsigned char val = data[i];
      if (val == costmap2D::NO_INFORMATION)
      {
        costmap_msg.data[i] = -1;
        count_255++;
      }
      else if (val == costmap2D::LETHAL_OBSTACLE)
      {
        costmap_msg.data[i] = 100;
        count_100++;
      }
      else if (val == costmap2D::INSCRIBED_INFLATED_OBSTACLE)
      {
        costmap_msg.data[i] = 99;
        count_99++;
      }
      else if (val >= 1 && val < 253)
      {
        // 膨胀区域: 线性映射到 1-98
        costmap_msg.data[i] = static_cast<int8_t>(val * 98 / 253) + 1;
        count_other++;
      }
      else if (val == costmap2D::FREE_SPACE)
      {
        costmap_msg.data[i] = 0;
        count_0++;
      }
      else
        costmap_msg.data[i] = static_cast<int8_t>(val * 100 / 255);
    }
    
    std::cout << "[Demo] 发布代价地图: 100=" << count_100 << " 99=" << count_99 << " 膨胀=" << count_other << " 0=" << count_0 << " 255=" << count_255 << std::endl;
    
    costmap_pub.publish(costmap_msg);
    
    // 打印状态
    if (++update_count % 50 == 0)
    {
      std::cout << "[Demo] 机器人位置: (" << pose_data.x_ << ", " << pose_data.y_ 
                << ") theta=" << pose_data.theta_ << std::endl;
      
      // 统计障碍物
      costmap2D::Costmap2D* master = layered_costmap.getCostmap();
      unsigned char* map_data = master->getCharMap();
      unsigned int size = master->getSizeInCellsX() * master->getSizeInCellsY();
      
      int obs_count = 0, inflated_count = 0;
      for (unsigned int i = 0; i < size; ++i)
      {
        if (map_data[i] == costmap2D::LETHAL_OBSTACLE) obs_count++;
        else if (map_data[i] > costmap2D::FREE_SPACE) inflated_count++;
      }
      std::cout << "[Demo]   障碍物: " << obs_count << " 膨胀: " << inflated_count << std::endl;
    }
    
    rate.sleep();
  }
  
  obstacle_layer->deactivate();
  ROS_INFO("[Demo] Demo 退出");
  
  return 0;
}
