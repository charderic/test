/**
 * @file inflation_demo.cpp
 * @brief 静态层+膨胀层测试Demo
 *
 * 功能：
 * 1. 订阅 /map 话题（nav_msgs::OccupancyGrid）
 * 2. 创建 LayeredCostmap 分层代价地图
 * 3. 添加 StaticLayer 静态层插件（无ROS依赖版本）
 * 4. 添加 InflationLayer 膨胀层插件
 * 5. 生成并输出膨胀后的代价地图
 *
 * 使用方法：
 *   ./inflation_demo [map_topic]
 */

#include <ros/ros.h>
#include <costmap_2d/layered_costmap.h>
#include <costmap_2d/static_layer1.h>
#include <costmap_2d/inflation_layer.h>
#include <costmap_2d/cost_values.h>
#include <nav_msgs/OccupancyGrid.h>
#include <iostream>
#include <iomanip>
#include <boost/shared_ptr.hpp>

int main(int argc, char** argv)
{
  ros::init(argc, argv, "inflation_demo");
  ros::NodeHandle nh;

  std::string map_topic = "/map";
  if (argc > 1)
  {
    map_topic = argv[1];
  }

  ROS_INFO("等待接收地图: %s", map_topic.c_str());

  nav_msgs::OccupancyGridConstPtr map_msg = ros::topic::waitForMessage<nav_msgs::OccupancyGrid>(map_topic, nh, ros::Duration(30.0));
  
  if (!map_msg)
  {
    ROS_ERROR("超时未收到地图消息！");
    return -1;
  }

  ROS_INFO("收到地图: %s, 尺寸: %dx%d, 分辨率: %.3f m/pixel",
           map_msg->header.frame_id.c_str(),
           map_msg->info.width, map_msg->info.height,
           map_msg->info.resolution);

  // ===== 1. 将ROS地图消息转换为自定义数据结构 =====
  costmap_2d::OccupancyGridData grid_data;
  grid_data.setGridInfo(map_msg->info.width, map_msg->info.height,
                        map_msg->info.resolution,
                        map_msg->info.origin.position.x,
                        map_msg->info.origin.position.y);
  grid_data.setFrameId(map_msg->header.frame_id);
  
  for (size_t i = 0; i < map_msg->data.size(); ++i)
  {
    grid_data[i] = map_msg->data[i];
  }
  
  ROS_INFO("地图数据转换完成");

  // ===== 2. 创建分层代价地图 =====
  ROS_INFO("创建分层代价地图...");
  costmap_2d::LayeredCostmap* layered_costmap = new costmap_2d::LayeredCostmap("map", false, false);

  // ===== 3. 创建静态层 =====
  ROS_INFO("创建静态层...");
  boost::shared_ptr<costmap_2d::StaticLayer> static_layer(new costmap_2d::StaticLayer());
  layered_costmap->addPlugin(static_layer);
  ROS_INFO("静态层已添加");

  // ===== 4. 创建膨胀层 =====
  ROS_INFO("创建膨胀层...");
  boost::shared_ptr<costmap_2d::InflationLayer> inflation_layer(new costmap_2d::InflationLayer(0.5, 5.0, false));
  layered_costmap->addPlugin(inflation_layer);
  ROS_INFO("膨胀层已添加");

  // ===== 5. 初始化膨胀层 =====
  ROS_INFO("初始化膨胀层...");
  inflation_layer->initialize(layered_costmap, "inflation_layer", NULL);
  inflation_layer->setEnabled(true);
  ROS_INFO("膨胀层初始化完成");

  // ===== 6. 初始化静态层并传入地图数据 =====
  ROS_INFO("初始化静态层...");
  static_layer->initialize(layered_costmap, "static_layer", NULL);
  static_layer->setEnabled(true);
  
  // 传入地图数据
  static_layer->incomingMap(grid_data);
  ROS_INFO("静态层地图数据已加载");

  // ===== 7. 获取代价地图 =====
  ROS_INFO("获取代价地图...");
  costmap_2d::Costmap2D* costmap = layered_costmap->getCostmap();
  
  if (!costmap)
  {
    ROS_ERROR("获取代价地图失败！");
    delete layered_costmap;
    return -1;
  }
  ROS_INFO("代价地图获取成功，尺寸: %dx%d", costmap->getSizeInCellsX(), costmap->getSizeInCellsY());

  // ===== 8. 设置机器人位置（使用地图中心）=====
  double robot_x = costmap->getOriginX() + costmap->getSizeInMetersX() / 2.0;
  double robot_y = costmap->getOriginY() + costmap->getSizeInMetersY() / 2.0;
  double robot_yaw = 0.0;

  // ===== 9. 更新分层代价地图（包含膨胀）=====
  ROS_INFO("更新代价地图（执行膨胀）...");
  layered_costmap->updateMap(robot_x, robot_y, robot_yaw);
  ROS_INFO("代价地图更新完成");

  // ===== 10. 输出代价地图基本信息 =====
  std::cout << "\n========================================" << std::endl;
  std::cout << "        代价地图基本信息" << std::endl;
  std::cout << "========================================" << std::endl;
  std::cout << "尺寸(栅格):  " << costmap->getSizeInCellsX() << " x "
            << costmap->getSizeInCellsY() << std::endl;
  std::cout << "分辨率:      " << costmap->getResolution() << " 米/栅格" << std::endl;
  std::cout << "原点:        [" << costmap->getOriginX() << ", "
            << costmap->getOriginY() << "]" << std::endl;
  std::cout << "尺寸(米):    " << costmap->getSizeInMetersX() << " x "
            << costmap->getSizeInMetersY() << " 米" << std::endl;
  std::cout << "膨胀半径:    " << inflation_layer->getInflationRadius() << " 米" << std::endl;
  std::cout << "代价衰减权重: " << inflation_layer->getCostScalingFactor() << std::endl;
  std::cout << "========================================\n" << std::endl;

  // ===== 11. 输出代价地图统计 =====
  int free_count = 0;
  int lethal_count = 0;
  int inscribed_count = 0;
  int inflated_count = 0;
  int no_information_count = 0;

  for (unsigned int i = 0; i < costmap->getSizeInCellsX(); ++i)
  {
    for (unsigned int j = 0; j < costmap->getSizeInCellsY(); ++j)
    {
      unsigned char cost = costmap->getCost(i, j);
      if (cost == costmap_2d::FREE_SPACE)
        free_count++;
      else if (cost == costmap_2d::LETHAL_OBSTACLE)
        lethal_count++;
      else if (cost == costmap_2d::INSCRIBED_INFLATED_OBSTACLE)
        inscribed_count++;
      else if (cost == costmap_2d::NO_INFORMATION)
        no_information_count++;
      else if (cost > 0 && cost < costmap_2d::INSCRIBED_INFLATED_OBSTACLE)
        inflated_count++;
    }
  }

  unsigned int total_cells = costmap->getSizeInCellsX() * costmap->getSizeInCellsY();

  std::cout << "========================================" << std::endl;
  std::cout << "        代价地图统计信息" << std::endl;
  std::cout << "========================================" << std::endl;
  std::cout << "总栅格数:     " << total_cells << std::endl;
  std::cout << "自由空间:     " << std::setw(10) << free_count << " ("
            << std::fixed << std::setprecision(2) << (100.0 * free_count / total_cells) << "%)" << std::endl;
  std::cout << "致命障碍:     " << std::setw(10) << lethal_count << " ("
            << std::fixed << std::setprecision(2) << (100.0 * lethal_count / total_cells) << "%)" << std::endl;
  std::cout << "内切圆区域:   " << std::setw(10) << inscribed_count << " ("
            << std::fixed << std::setprecision(2) << (100.0 * inscribed_count / total_cells) << "%)" << std::endl;
  std::cout << "膨胀区域:     " << std::setw(10) << inflated_count << " ("
            << std::fixed << std::setprecision(2) << (100.0 * inflated_count / total_cells) << "%)" << std::endl;
  std::cout << "未知区域:     " << std::setw(10) << no_information_count << " ("
            << std::fixed << std::setprecision(2) << (100.0 * no_information_count / total_cells) << "%)" << std::endl;
  std::cout << "========================================\n" << std::endl;

  // ===== 12. 可视化显示中心区域 =====
  const int display_size = 15;
  int start_x = std::max(0, (int)costmap->getSizeInCellsX() / 2 - display_size / 2);
  int start_y = std::max(0, (int)costmap->getSizeInCellsY() / 2 - display_size / 2);

  std::cout << "代价地图可视化 (中心 " << display_size << "x" << display_size << " 区域):" << std::endl;
  std::cout << "坐标范围: [" << start_x << ", " << start_y << "] 到 ["
            << start_x + display_size - 1 << ", " << start_y + display_size - 1 << "]" << std::endl;
  std::cout << "(颜色越深表示代价越高)" << std::endl;
  std::cout << std::endl;

  for (int j = start_y + display_size - 1; j >= start_y; --j)
  {
    for (int i = start_x; i < start_x + display_size; ++i)
    {
      unsigned char cost = costmap->getCost(i, j);
      if (cost == costmap_2d::FREE_SPACE)
        std::cout << "  .";
      else if (cost == costmap_2d::LETHAL_OBSTACLE)
        std::cout << "  X";
      else if (cost == costmap_2d::INSCRIBED_INFLATED_OBSTACLE)
        std::cout << "  #";
      else if (cost == costmap_2d::NO_INFORMATION)
        std::cout << "  ?";
      else if (cost >= 200)
        std::cout << "  H";
      else if (cost >= 100)
        std::cout << "  M";
      else if (cost > 0)
        std::cout << "  L";
      else
        std::cout << "  .";
    }
    std::cout << std::endl;
  }

  std::cout << "\n图例:" << std::endl;
  std::cout << "  . = 自由空间 (0)" << std::endl;
  std::cout << "  L = 低代价膨胀区 (1-99)" << std::endl;
  std::cout << "  M = 中代价膨胀区 (100-199)" << std::endl;
  std::cout << "  H = 高代价膨胀区 (200-252)" << std::endl;
  std::cout << "  # = 内切圆区域 (" << (int)costmap_2d::INSCRIBED_INFLATED_OBSTACLE << ")" << std::endl;
  std::cout << "  X = 障碍物 (" << (int)costmap_2d::LETHAL_OBSTACLE << ")" << std::endl;
  std::cout << "  ? = 未知区域 (" << (int)costmap_2d::NO_INFORMATION << ")" << std::endl;
  std::cout << "========================================\n" << std::endl;

  // ===== 13. 发布代价地图到 /costmap_test =====
  ROS_INFO("发布代价地图到 /costmap_test ...");
  ros::Publisher costmap_pub = nh.advertise<nav_msgs::OccupancyGrid>("/costmap_test", 1, true);

  nav_msgs::OccupancyGrid costmap_msg;
  costmap_msg.header.frame_id = layered_costmap->getGlobalFrameID();
  costmap_msg.header.stamp = ros::Time::now();
  costmap_msg.info.resolution = costmap->getResolution();
  costmap_msg.info.width = costmap->getSizeInCellsX();
  costmap_msg.info.height = costmap->getSizeInCellsY();
  costmap_msg.info.origin.position.x = costmap->getOriginX();
  costmap_msg.info.origin.position.y = costmap->getOriginY();
  costmap_msg.info.origin.position.z = 0.0;
  costmap_msg.info.origin.orientation.w = 1.0;

  costmap_msg.data.resize(costmap->getSizeInCellsX() * costmap->getSizeInCellsY());

  unsigned char* costmap_data = costmap->getCharMap();
  for (unsigned int i = 0; i < costmap->getSizeInCellsX() * costmap->getSizeInCellsY(); ++i)
  {
    unsigned char cost = costmap_data[i];
    if (cost == costmap_2d::NO_INFORMATION)
      costmap_msg.data[i] = -1;
    else if (cost == costmap_2d::LETHAL_OBSTACLE)
      costmap_msg.data[i] = 100;
    else
      costmap_msg.data[i] = static_cast<int8_t>(cost * 99.0 / 253.0);
  }

  ros::Duration(0.5).sleep();
  costmap_pub.publish(costmap_msg);
  ROS_INFO("代价地图已发布到 /costmap_test，尺寸: %dx%d",
           costmap_msg.info.width, costmap_msg.info.height);

  // ===== 循环发布代价地图 =====
  ROS_INFO("开始循环发布代价地图 (按 Ctrl+C 退出)...");
  ros::Rate loop_rate(1.0);
  
  while (ros::ok())
  {
    costmap_msg.header.stamp = ros::Time::now();
    
    unsigned char* costmap_data = costmap->getCharMap();
    for (unsigned int i = 0; i < costmap->getSizeInCellsX() * costmap->getSizeInCellsY(); ++i)
    {
      unsigned char cost = costmap_data[i];
      if (cost == costmap_2d::NO_INFORMATION)
        costmap_msg.data[i] = -1;
      else if (cost == costmap_2d::LETHAL_OBSTACLE)
        costmap_msg.data[i] = 100;
      else
        costmap_msg.data[i] = static_cast<int8_t>(cost * 99.0 / 253.0);
    }
    
    costmap_pub.publish(costmap_msg);
    ros::spinOnce();
    loop_rate.sleep();
  }

  ROS_INFO("节点退出，清理资源...");
  delete layered_costmap;

  return 0;
}
