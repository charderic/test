/**
 * @file costmap_demo.cpp
 * @brief 全局+局部代价地图联合 Demo
 *
 * 功能：
 * 1. 创建 global_costmap（静态层 + 膨胀层），订阅 /map 话题
 * 2. 创建 local_costmap（障碍物层 + 膨胀层），订阅 /scan 和 /amcl_pose 话题
 * 3. 分别发布全局和局部代价地图
 *
 * 输出话题：
 * - /GlobalCostMap: 全局代价地图
 * - /LocalCostMap: 局部代价地图
 */

#include <ros/ros.h>
#include <ros/console.h>
#include <nav_msgs/OccupancyGrid.h>
#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <costmap_2d/layered_costmap.h>
#include <costmap_2d/static_layer.h>
#include <costmap_2d/obstacle_layer.h>
#include <costmap_2d/inflation_layer.h>
#include <costmap_2d/cost_values.h>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>

namespace costmap2D
{

uint64_t getCurrentTimestampNs()
{
  struct timespec ts;
  clock_gettime(CLOCK_REALTIME, &ts);
  return static_cast<uint64_t>(ts.tv_sec) * 1000000000ULL + static_cast<uint64_t>(ts.tv_nsec);
}

} // namespace costmap2D

static costmap2D::LaserScanData g_laser_scan;
static costmap2D::RobotPose g_robot_pose;
static bool g_laser_received = false;
static bool g_pose_received = false;
static bool g_map_received = false;
static boost::mutex g_data_mutex;

static uint64_t g_used_laser_timestamp = 0;
static uint64_t g_used_pose_timestamp = 0;
static uint64_t g_timestamp_tolerance_ns = 600000000000ULL;

void laserScanCallback(const sensor_msgs::LaserScan::ConstPtr& msg)
{
  boost::unique_lock<boost::mutex> lock(g_data_mutex);
  
  costmap2D::LaserScanData scan;
  scan.angle_min_ = msg->angle_min;
  scan.angle_max_ = msg->angle_max;
  scan.angle_increment_ = msg->angle_increment;
  scan.range_min_ = msg->range_min;
  scan.range_max_ = msg->range_max;
  scan.timestamp_ns_ = static_cast<uint64_t>(msg->header.stamp.sec) * 1000000000ULL + 
                       static_cast<uint64_t>(msg->header.stamp.nsec);
  scan.frame_id_ = msg->header.frame_id;
  scan.ranges_.resize(msg->ranges.size());
  for (size_t i = 0; i < msg->ranges.size(); ++i)
  {
    scan.ranges_[i] = msg->ranges[i];
  }
  
  g_laser_scan = scan;
  g_laser_received = true;
}

void poseCallback(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& msg)
{
  boost::unique_lock<boost::mutex> lock(g_data_mutex);
  
  costmap2D::RobotPose pose;
  pose.x_ = msg->pose.pose.position.x;
  pose.y_ = msg->pose.pose.position.y;
  
  double qx = msg->pose.pose.orientation.x;
  double qy = msg->pose.pose.orientation.y;
  double qz = msg->pose.pose.orientation.z;
  double qw = msg->pose.pose.orientation.w;
  pose.theta_ = atan2(2.0 * (qw * qz + qx * qy), 1.0 - 2.0 * (qy * qy + qz * qz));
  
  pose.timestamp_ns_ = static_cast<uint64_t>(msg->header.stamp.sec) * 1000000000ULL + 
                       static_cast<uint64_t>(msg->header.stamp.nsec);
  
  g_robot_pose = pose;
  g_pose_received = true;
}

int main(int argc, char** argv)
{
  ros::init(argc, argv, "costmap_demo");
  ros::NodeHandle nh;
  ros::NodeHandle private_nh("~");

  std::string map_topic = "/map";
  std::string laser_topic = "/scan";
  std::string pose_topic = "/amcl_pose";
  std::string global_costmap_topic = "/GlobalCostMap";
  std::string local_costmap_topic = "/LocalCostMap";
  
  private_nh.param<std::string>("map_topic", map_topic, "/map");
  private_nh.param<std::string>("laser_topic", laser_topic, "/scan");
  private_nh.param<std::string>("pose_topic", pose_topic, "/amcl_pose");
  private_nh.param<std::string>("global_costmap_topic", global_costmap_topic, "/GlobalCostMap");
  private_nh.param<std::string>("local_costmap_topic", local_costmap_topic, "/LocalCostMap");

  double global_inflation_radius = 0.5;
  double local_inflation_radius = 0.5;
  double cost_scaling = 10.0;
  double sensor_mount_angle = 0.0;
  
  private_nh.param<double>("global_inflation_radius", global_inflation_radius, 0.5);
  private_nh.param<double>("local_inflation_radius", local_inflation_radius, 0.5);
  private_nh.param<double>("cost_scaling", cost_scaling, 10.0);
  private_nh.param<double>("sensor_mount_angle", sensor_mount_angle, 0.0);

  int timestamp_tolerance_ms = 600000;
  private_nh.param<int>("timestamp_tolerance_ms", timestamp_tolerance_ms, 600000);
  g_timestamp_tolerance_ns = static_cast<uint64_t>(timestamp_tolerance_ms) * 1000000;

  ROS_INFO("========================================");
  ROS_INFO("  costmap_demo - 全局+局部代价地图联合演示");
  ROS_INFO("========================================");
  ROS_INFO("  地图话题: %s", map_topic.c_str());
  ROS_INFO("  激光话题: %s", laser_topic.c_str());
  ROS_INFO("  位姿话题: %s", pose_topic.c_str());
  ROS_INFO("  全局代价地图话题: %s", global_costmap_topic.c_str());
  ROS_INFO("  局部代价地图话题: %s", local_costmap_topic.c_str());
  ROS_INFO("  全局膨胀半径: %.2f m", global_inflation_radius);
  ROS_INFO("  局部膨胀半径: %.2f m", local_inflation_radius);
  ROS_INFO("  代价衰减权重: %.2f", cost_scaling);
  ROS_INFO("========================================");

  // ===== 1. 创建全局代价地图 =====
  ROS_INFO("[GlobalCostMap] 创建全局代价地图...");
  costmap2D::LayeredCostmap* global_costmap = new costmap2D::LayeredCostmap("map", false, false);
  
  boost::shared_ptr<costmap2D::StaticLayer> static_layer(new costmap2D::StaticLayer());
  boost::shared_ptr<costmap2D::InflationLayer> global_inflation_layer(
    new costmap2D::InflationLayer(global_inflation_radius, cost_scaling, false));
  
  global_costmap->addPlugin(static_layer);
  global_costmap->addPlugin(global_inflation_layer);
  
  global_inflation_layer->initialize(global_costmap, "inflation_layer", NULL);
  global_inflation_layer->setEnabled(true);
  
  static_layer->initialize(global_costmap, "static_layer", NULL);
  static_layer->setEnabled(true);

  // ===== 2. 创建局部代价地图 =====
  ROS_INFO("[LocalCostMap] 创建局部代价地图...");
  double local_width = 5.0;
  double local_height = 5.0;
  double local_resolution = 0.05;
  
  costmap2D::LayeredCostmap local_costmap("map", true, false);
  
  local_costmap.getCostmap()->resizeMap(
    static_cast<unsigned int>(local_width / local_resolution),
    static_cast<unsigned int>(local_height / local_resolution),
    local_resolution, 0, 0);

  costmap2D::ObstacleLayer* obstacle_layer = new costmap2D::ObstacleLayer();
  costmap2D::InflationLayer* local_inflation_layer = 
    new costmap2D::InflationLayer(local_inflation_radius, cost_scaling, false);
  
  boost::shared_ptr<costmap2D::Layer> obs_ptr(obstacle_layer);
  boost::shared_ptr<costmap2D::Layer> inf_ptr(local_inflation_layer);
  
  local_costmap.addPlugin(obs_ptr);
  local_costmap.addPlugin(inf_ptr);
  
  local_inflation_layer->initialize(&local_costmap, "inflation_layer", NULL);
  local_inflation_layer->matchSize();
  local_inflation_layer->setEnabled(true);
  
  obstacle_layer->initialize(&local_costmap, "obstacle_layer", NULL);
  obstacle_layer->matchSize();
  obstacle_layer->setEnabled(true);
  obstacle_layer->activate();
  
  obstacle_layer->setObstacleRange(5.0);
  obstacle_layer->setRaytraceRange(6.0);
  obstacle_layer->setTimestampTolerance(g_timestamp_tolerance_ns);

  // ===== 3. 订阅话题 =====
  ROS_INFO("[Subscriber] 订阅激光话题: %s", laser_topic.c_str());
  ros::Subscriber laser_sub = nh.subscribe(laser_topic, 10, laserScanCallback);
  
  ROS_INFO("[Subscriber] 订阅位姿话题: %s", pose_topic.c_str());
  ros::Subscriber pose_sub = nh.subscribe(pose_topic, 10, poseCallback);

  // ===== 4. 创建发布器 =====
  ros::Publisher global_costmap_pub = nh.advertise<nav_msgs::OccupancyGrid>(global_costmap_topic, 1, true);
  ros::Publisher local_costmap_pub = nh.advertise<nav_msgs::OccupancyGrid>(local_costmap_topic, 1, true);

  // ===== 5. 等待地图数据（可选）=====
  ROS_INFO("[GlobalCostMap] 等待接收地图: %s", map_topic.c_str());
  nav_msgs::OccupancyGridConstPtr map_msg = ros::topic::waitForMessage<nav_msgs::OccupancyGrid>(map_topic, nh, ros::Duration(5.0));
  
  costmap2D::Costmap2D* global_costmap_ptr = global_costmap->getCostmap();
  
  if (!map_msg)
  {
    ROS_WARN("[GlobalCostMap] 未收到地图消息，使用空地图继续运行...");
    global_costmap_ptr->resizeMap(100, 100, 0.05, 0, 0);
  }
  else
  {
    ROS_INFO("[GlobalCostMap] 收到地图: %s, 尺寸: %dx%d, 分辨率: %.3f m/pixel",
             map_msg->header.frame_id.c_str(),
             map_msg->info.width, map_msg->info.height,
             map_msg->info.resolution);

    // ===== 6. 加载静态地图 =====
    costmap2D::OccupancyGridData grid_data;
    grid_data.setGridInfo(map_msg->info.width, map_msg->info.height,
                          map_msg->info.resolution,
                          map_msg->info.origin.position.x,
                          map_msg->info.origin.position.y);
    grid_data.setFrameId(map_msg->header.frame_id);
    
    for (size_t i = 0; i < map_msg->data.size(); ++i)
    {
      grid_data[i] = map_msg->data[i];
    }
    
    static_layer->incomingMap(grid_data);
    ROS_INFO("[GlobalCostMap] 静态层地图数据已加载");

    // ===== 7. 更新全局代价地图 =====
    double global_robot_x = global_costmap_ptr->getOriginX() + global_costmap_ptr->getSizeInMetersX() / 2.0;
    double global_robot_y = global_costmap_ptr->getOriginY() + global_costmap_ptr->getSizeInMetersY() / 2.0;
    
    global_costmap->updateMap(global_robot_x, global_robot_y, 0.0);
    ROS_INFO("[GlobalCostMap] 全局代价地图更新完成");
  }

  // ===== 8. 等待激光和位姿数据 =====
  ROS_INFO("[LocalCostMap] 等待接收激光和位姿数据...");
  int wait_count = 0;
  while (ros::ok())
  {
    ros::spinOnce();
    
    boost::unique_lock<boost::mutex> lock(g_data_mutex);
    bool ready = g_laser_received && g_pose_received;
    lock.unlock();
    
    if (ready)
    {
      ROS_INFO("[LocalCostMap] 接收到数据，开始处理!");
      break;
    }
    
    if (++wait_count > 100)
    {
      ROS_WARN("[LocalCostMap] 等待超时，继续运行...");
      break;
    }
    
    ros::Duration(0.1).sleep();
  }

  // ===== 9. 主循环 =====
  ROS_INFO("[Demo] ========== 开始处理 ==========");
  ros::Rate rate(10);
  int update_count = 0;
  
  while (ros::ok())
  {
    ros::spinOnce();
    
    costmap2D::LaserScanData laser_data;
    costmap2D::RobotPose pose_data;
    bool data_ready = false;
    
    {
      boost::unique_lock<boost::mutex> lock(g_data_mutex);
      if (g_laser_received && g_pose_received)
      {
        bool laser_new = (g_laser_scan.timestamp_ns_ > g_used_laser_timestamp);
        bool pose_new = (g_robot_pose.timestamp_ns_ > g_used_pose_timestamp);
        
        if (laser_new && pose_new)
        {
          laser_data = g_laser_scan;
          pose_data = g_robot_pose;
          data_ready = true;
        }
      }
    }
    
    // ===== 局部代价地图更新 =====
    if (data_ready)
    {
      int64_t time_diff = static_cast<int64_t>(laser_data.timestamp_ns_) - static_cast<int64_t>(pose_data.timestamp_ns_);
      if (time_diff < 0) time_diff = -time_diff;
      
      if (time_diff > g_timestamp_tolerance_ns)
      {
        if (update_count % 50 == 0)
        {
          ROS_WARN("[Demo] 时间戳不对齐: %ld ms, 继续处理...", time_diff / 1000000);
        }
      }
      
      {
        boost::unique_lock<boost::mutex> lock(g_data_mutex);
        g_used_laser_timestamp = laser_data.timestamp_ns_;
        g_used_pose_timestamp = pose_data.timestamp_ns_;
      }
      
      obstacle_layer->incomingLaserScan(laser_data, pose_data, sensor_mount_angle);
      local_costmap.updateMap(pose_data.x_, pose_data.y_, pose_data.theta_);
    }

    // ===== 发布全局代价地图 =====
    nav_msgs::OccupancyGrid global_msg;
    global_msg.header.stamp = ros::Time::now();
    global_msg.header.frame_id = global_costmap->getGlobalFrameID();
    global_msg.info.resolution = global_costmap_ptr->getResolution();
    global_msg.info.width = global_costmap_ptr->getSizeInCellsX();
    global_msg.info.height = global_costmap_ptr->getSizeInCellsY();
    global_msg.info.origin.position.x = global_costmap_ptr->getOriginX();
    global_msg.info.origin.position.y = global_costmap_ptr->getOriginY();
    global_msg.info.origin.position.z = 0.0;
    global_msg.info.origin.orientation.w = 1.0;
    
    global_msg.data.resize(global_costmap_ptr->getSizeInCellsX() * global_costmap_ptr->getSizeInCellsY());
    unsigned char* global_data = global_costmap_ptr->getCharMap();
    
    for (unsigned int i = 0; i < global_msg.data.size(); ++i)
    {
      unsigned char cost = global_data[i];
      if (cost == costmap2D::NO_INFORMATION)
        global_msg.data[i] = -1;
      else if (cost == costmap2D::LETHAL_OBSTACLE)
        global_msg.data[i] = 100;
      else
        global_msg.data[i] = static_cast<int8_t>(cost * 99.0 / 253.0);
    }
    
    global_costmap_pub.publish(global_msg);

    // ===== 发布局部代价地图 =====
    costmap2D::Costmap2D* local_costmap_ptr = local_costmap.getCostmap();
    
    nav_msgs::OccupancyGrid local_msg;
    local_msg.header.stamp = ros::Time::now();
    local_msg.header.frame_id = "map";
    local_msg.info.resolution = local_costmap_ptr->getResolution();
    local_msg.info.width = local_costmap_ptr->getSizeInCellsX();
    local_msg.info.height = local_costmap_ptr->getSizeInCellsY();
    local_msg.info.origin.position.x = local_costmap_ptr->getOriginX();
    local_msg.info.origin.position.y = local_costmap_ptr->getOriginY();
    local_msg.info.origin.position.z = 0.0;
    local_msg.info.origin.orientation.w = 1.0;
    
    local_msg.data.resize(local_costmap_ptr->getSizeInCellsX() * local_costmap_ptr->getSizeInCellsY());
    unsigned char* local_data = local_costmap_ptr->getCharMap();
    
    for (size_t i = 0; i < local_msg.data.size(); ++i)
    {
      unsigned char val = local_data[i];
      if (val == costmap2D::NO_INFORMATION)
        local_msg.data[i] = -1;
      else if (val == costmap2D::LETHAL_OBSTACLE)
        local_msg.data[i] = 100;
      else if (val == costmap2D::INSCRIBED_INFLATED_OBSTACLE)
        local_msg.data[i] = 99;
      else if (val >= 1 && val < 253)
        local_msg.data[i] = static_cast<int8_t>(val * 98 / 253) + 1;
      else if (val == costmap2D::FREE_SPACE)
        local_msg.data[i] = 0;
      else
        local_msg.data[i] = static_cast<int8_t>(val * 100 / 255);
    }
    
    local_costmap_pub.publish(local_msg);

    if (++update_count % 50 == 0)
    {
      boost::unique_lock<boost::mutex> lock(g_data_mutex);
      double rx = g_robot_pose.x_;
      double ry = g_robot_pose.y_;
      lock.unlock();
      
      ROS_INFO("[Demo] 机器人位置: (%.2f, %.2f), 全局地图尺寸: %dx%d, 局部地图尺寸: %dx%d",
               rx, ry,
               global_costmap_ptr->getSizeInCellsX(), global_costmap_ptr->getSizeInCellsY(),
               local_costmap_ptr->getSizeInCellsX(), local_costmap_ptr->getSizeInCellsY());
      
      int robot_grid_x, robot_grid_y;
      local_costmap_ptr->worldToMapNoBounds(rx, ry, robot_grid_x, robot_grid_y);
      
      ROS_INFO("[Demo] 机器人栅格位置: (%d, %d), 局部地图原点: (%.2f, %.2f)",
               robot_grid_x, robot_grid_y,
               local_costmap_ptr->getOriginX(), local_costmap_ptr->getOriginY());
      
      int local_width = local_costmap_ptr->getSizeInCellsX();
      int local_height = local_costmap_ptr->getSizeInCellsY();
      
      std::string cost_line = "[Demo] X方向代价值 (y=" + std::to_string(robot_grid_y) + "): ";
      for (int x = 0; x < local_width; ++x)
      {
        if (robot_grid_y >= 0 && robot_grid_y < local_height)
        {
          unsigned char cost = local_costmap_ptr->getCost(x, robot_grid_y);
          cost_line += std::to_string(static_cast<int>(cost)) + " ";
        }
        else
        {
          cost_line += "- ";
        }
      }
      ROS_INFO("%s", cost_line.c_str());
    }
    
    rate.sleep();
  }

  obstacle_layer->deactivate();
  delete global_costmap;
  
  ROS_INFO("[Demo] Demo 退出");
  return 0;
}