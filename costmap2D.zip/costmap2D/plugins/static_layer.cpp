/**
 * @file static_layer1.cpp
 * @brief 无 ROS 依赖的静态层实现文件
 * 
 * 设计要点：
 * 1. 使用 OccupancyGridData 替代 nav_msgs::OccupancyGrid
 * 2. incomingMap 改为普通成员函数（非回调），入参为自定义数据结构
 * 3. 完全去除 ROS 依赖
 */

#include <costmap_2d/static_layer.h>
#include <costmap_2d/costmap_math.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <cmath>

// 使用代价地图常量
using costmap2D::NO_INFORMATION;     // 未知空间（255）
using costmap2D::LETHAL_OBSTACLE;    // 致命障碍（254）
using costmap2D::FREE_SPACE;         // 自由空间（0）

namespace costmap2D
{

// ============================================================================
// StaticLayer 实现
// ============================================================================

StaticLayer::StaticLayer()
  : global_frame_("map")
  , map_frame_("map")
  , map_received_(false)
  , has_updated_data_(false)
  , first_map_only_(false)
  , track_unknown_space_(true)
  , use_maximum_(false)
  , trinary_costmap_(true)
  , lethal_threshold_(100)
  , unknown_cost_value_(-1)
  , update_x_(0)
  , update_y_(0)
  , update_width_(0)
  , update_height_(0)
{
}

StaticLayer::~StaticLayer()
{
}

void StaticLayer::onInitialize()
{
  current_ = true;
  
  // 获取全局坐标系名称
  global_frame_ = layered_costmap_->getGlobalFrameID();
  
  // 设置默认参数
  first_map_only_ = false;
  track_unknown_space_ = true;
  use_maximum_ = false;
  trinary_costmap_ = true;
  lethal_threshold_ = 100;
  unknown_cost_value_ = -1;
  
  std::cout << "[StaticLayer] 初始化完成" << std::endl;
}

void StaticLayer::activate()
{
  current_ = true;
  std::cout << "[StaticLayer] 已激活" << std::endl;
}

void StaticLayer::deactivate()
{
  current_ = false;
  std::cout << "[StaticLayer] 已停用" << std::endl;
}

void StaticLayer::reset()
{
  if (first_map_only_)
  {
    has_updated_data_ = true;
  }
  else
  {
    map_received_ = false;
    has_updated_data_ = false;
    onInitialize();
  }
}

void StaticLayer::matchSize()
{
  if (!layered_costmap_->isRolling())
  {
    Costmap2D* master = layered_costmap_->getCostmap();
    resizeMap(master->getSizeInCellsX(), master->getSizeInCellsY(), 
              master->getResolution(), master->getOriginX(), master->getOriginY());
  }
}

unsigned char StaticLayer::interpretValue(unsigned char value)
{
  // 处理未知区域
  if (track_unknown_space_ && value == (unsigned char)unknown_cost_value_)
    return NO_INFORMATION;  // 255
  else if (!track_unknown_space_ && value == (unsigned char)unknown_cost_value_)
    return FREE_SPACE;      // 0
  
  // 处理障碍物
  else if (value >= lethal_threshold_)
    return LETHAL_OBSTACLE; // 254
  
  // 三值化模式
  else if (trinary_costmap_)
    return FREE_SPACE;      // 0
  
  // SCALE模式：线性插值
  double scale = (double) value / lethal_threshold_;
  return static_cast<unsigned char>(scale * LETHAL_OBSTACLE);
}

void StaticLayer::setMap(const OccupancyGridData& grid)
{
  incomingMap(grid);
}

void StaticLayer::incomingMap(const OccupancyGridData& grid)
{
  unsigned int size_x = grid.getWidth();
  unsigned int size_y = grid.getHeight();
  
  std::cout << "[StaticLayer] incomingMap 被调用: " << size_x << "x" << size_y 
            << " at " << grid.getResolution() << " m/pix" << std::endl;
  
  Costmap2D* master = layered_costmap_->getCostmap();
  
  // 非滚动窗口模式：调整整个分层代价地图
  if (!layered_costmap_->isRolling() &&
      (master->getSizeInCellsX() != size_x ||
       master->getSizeInCellsY() != size_y ||
       master->getResolution() != grid.getResolution() ||
       master->getOriginX() != grid.getOriginX() ||
       master->getOriginY() != grid.getOriginY()))
  {
    std::cout << "[StaticLayer] 调整代价地图尺寸: " << size_x << "x" << size_y << std::endl;
    layered_costmap_->resizeMap(size_x, size_y, grid.getResolution(), 
                               grid.getOriginX(), grid.getOriginY(), true);
  }
  // 滚动窗口模式：只调整本地静态层尺寸
  else if (size_x_ != size_x || size_y_ != size_y ||
           resolution_ != grid.getResolution() ||
           origin_x_ != grid.getOriginX() ||
           origin_y_ != grid.getOriginY())
  {
    std::cout << "[StaticLayer] 调整静态层尺寸: " << size_x << "x" << size_y << std::endl;
    resizeMap(size_x, size_y, grid.getResolution(),
              grid.getOriginX(), grid.getOriginY());
  }
  
  // 遍历像素并转换值
  unsigned int index = 0;
  for (unsigned int i = 0; i < size_y; ++i)
  {
    for (unsigned int j = 0; j < size_x; ++j)
    {
      unsigned char value = static_cast<unsigned char>(grid[index]);
      costmap_[index] = interpretValue(value);
      ++index;
    }
  }
  
  // 保存地图坐标系
  map_frame_ = grid.getFrameId();
  
  // 标记整个地图已更新
  update_x_ = update_y_ = 0;
  update_width_ = size_x_;
  update_height_ = size_y_;
  map_received_ = true;
  has_updated_data_ = true;
  
  std::cout << "[StaticLayer] 地图处理完成" << std::endl;
}

void StaticLayer::updateBounds(double robot_x, double robot_y, double robot_yaw, 
                              double* min_x, double* min_y, double* max_x, double* max_y)
{
  // 非滚动窗口模式
  if (!layered_costmap_->isRolling())
  {
    if (!map_received_ || !has_updated_data_)
    {
      return;
    }
  }
  
  // 使用额外边界
  useExtraBounds(min_x, min_y, max_x, max_y);
  
  // 计算更新区域的边界
  double wx, wy;
  
  // 左下角
  mapToWorld(update_x_, update_y_, wx, wy);
  *min_x = std::min(wx, *min_x);
  *min_y = std::min(wy, *min_y);
  
  // 右上角
  mapToWorld(update_x_ + update_width_, update_y_ + update_height_, wx, wy);
  *max_x = std::max(wx, *max_x);
  *max_y = std::max(wy, *max_y);
  
  // 重置更新标志
  has_updated_data_ = false;
}

void StaticLayer::updateCosts(costmap2D::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j)
{
  if (!map_received_)
  {
    std::cout << "[StaticLayer] 警告: 未收到地图" << std::endl;
    return;
  }
  
  // 非滚动窗口模式
  if (!layered_costmap_->isRolling())
  {
    if (!use_maximum_)
    {
      updateWithTrueOverwrite(master_grid, min_i, min_j, max_i, max_j);
    }
    else
    {
      updateWithMax(master_grid, min_i, min_j, max_i, max_j);
    }
  }
  else
  {
    std::cout << "[StaticLayer] 警告: 滚动窗口模式暂不支持" << std::endl;
  }
}

}  // namespace costmap2D
