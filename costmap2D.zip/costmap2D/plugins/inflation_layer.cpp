/**
 * @file inflation_layer.cpp
 * @brief 膨胀层实现文件 - 障碍物膨胀算法的核心实现
 *
 * 本文件实现了InflationLayer类的所有成员函数，包括：
 * 1. 初始化和参数配置（代码预设值）
 * 2. 距离和代价缓存预计算
 * 3. 核心膨胀算法（BFS类扩散）
 */

#include <algorithm>
#include <limits>
#include <iostream>
#include <costmap_2d/inflation_layer.h>
#include <costmap_2d/costmap_math.h>
#include <costmap_2d/footprint.h>
#include <boost/thread.hpp>

// 使用代价地图常量
using costmap2D::LETHAL_OBSTACLE;   // 致命障碍（254）
using costmap2D::INSCRIBED_INFLATED_OBSTACLE;  // 内切圆内障碍（253）
using costmap2D::NO_INFORMATION;    // 未知区域（255）

namespace costmap2D
{

/**
 * @brief 默认构造函数
 *
 * 使用默认预设参数值：
 * - inflation_radius: 0.55 米
 * - cost_scaling_factor: 10.0
 * - inflate_unknown: false
 */
InflationLayer::InflationLayer()
  : resolution_(0)
  , inflation_radius_(0.55)    // 默认膨胀半径：0.55米
  , inscribed_radius_(0)
  , circumscribed_radius_(0)   // 默认外接圆半径：0（由LayeredCostmap设置）
  , weight_(10.0)              // 默认代价衰减权重：10.0
  , inflate_unknown_(false)    // 默认不膨胀未知区域
  , cell_inflation_radius_(0)
  , cached_cell_inflation_radius_(0)
  , seen_(NULL)
  , cached_costs_(NULL)
  , cached_distances_(NULL)
  , last_min_x_(-std::numeric_limits<float>::max())
  , last_min_y_(-std::numeric_limits<float>::max())
  , last_max_x_(std::numeric_limits<float>::max())
  , last_max_y_(std::numeric_limits<float>::max())
{
  // 创建递归互斥锁，支持嵌套锁定
  inflation_access_ = new boost::recursive_mutex();
}

/**
 * @brief 带参数的构造函数
 *
 * @param inflation_radius 膨胀半径（米）
 * @param cost_scaling_factor 代价衰减权重
 * @param inflate_unknown 是否膨胀未知区域
 */
InflationLayer::InflationLayer(double inflation_radius, double cost_scaling_factor, bool inflate_unknown)
  : resolution_(0)
  , inflation_radius_(inflation_radius)    // 用户指定的膨胀半径
  , inscribed_radius_(0)
  , circumscribed_radius_(0)               // 默认外接圆半径：0（由LayeredCostmap设置）
  , weight_(cost_scaling_factor)           // 用户指定的代价衰减权重
  , inflate_unknown_(inflate_unknown)      // 用户指定是否膨胀未知区域
  , cell_inflation_radius_(0)
  , cached_cell_inflation_radius_(0)
  , seen_(NULL)
  , cached_costs_(NULL)
  , cached_distances_(NULL)
  , last_min_x_(-std::numeric_limits<float>::max())
  , last_min_y_(-std::numeric_limits<float>::max())
  , last_max_x_(std::numeric_limits<float>::max())
  , last_max_y_(std::numeric_limits<float>::max())
{
  // 创建递归互斥锁，支持嵌套锁定
  inflation_access_ = new boost::recursive_mutex();
}

/**
 * @brief 初始化函数
 *
 * 执行以下操作：
 * 1. 设置图层为当前状态
 * 2. 初始化已访问标记数组
 *
 * 参数已在构造函数中预设，不再从ROS参数服务器读取。
 * 注意：matchSize() 不在此处调用，而是等待 StaticLayer 触发 resizeMap()
 */
void InflationLayer::onInitialize()
{
  {
    // 获取互斥锁，确保线程安全
    boost::unique_lock < boost::recursive_mutex > lock(*inflation_access_);

    // 标记图层为当前状态（已更新）
    current_ = true;

    // 清理旧的已访问数组
    if (seen_)
      delete[] seen_;
    seen_ = NULL;
    seen_size_ = 0;

    // 初始化不需要完全重新膨胀
    need_reinflation_ = false;
  }
  // matchSize() 将在 StaticLayer 触发 resizeMap() 时自动调用
}

/**
 * @brief 同步尺寸函数
 *
 * 当主代价地图尺寸改变时调用：
 * 1. 获取当前代价地图分辨率
 * 2. 计算膨胀半径对应的栅格数
 * 3. 重新计算距离和代价缓存
 * 4. 调整已访问标记数组大小
 */
void InflationLayer::matchSize()
{
  // 获取互斥锁
  boost::unique_lock < boost::recursive_mutex > lock(*inflation_access_);

  // 获取主代价地图指针
  costmap2D::Costmap2D* costmap = layered_costmap_->getCostmap();

  // 更新分辨率
  resolution_ = costmap->getResolution();

  // 更新内切圆半径和外接圆半径（从LayeredCostmap获取）
  inscribed_radius_ = layered_costmap_->getInscribedRadius();
  circumscribed_radius_ = layered_costmap_->getCircumscribedRadius();

  // 将膨胀半径（米）转换为栅格数
  cell_inflation_radius_ = costmap->cellDistance(inflation_radius_);

  // 重新计算距离和代价缓存
  computeCaches();

  // 获取代价地图尺寸
  unsigned int size_x = costmap->getSizeInCellsX(), size_y = costmap->getSizeInCellsY();

  // 调整已访问标记数组大小
  if (seen_)
    delete[] seen_;
  seen_size_ = size_x * size_y;
  seen_ = new bool[seen_size_];
}

/**
 * @brief 更新边界函数
 *
 * 根据膨胀半径扩展更新边界，确保膨胀区域被完整覆盖。
 * 如果需要完全重新膨胀（参数改变），则扩展到整个地图。
 *
 * @param robot_x 机器人X坐标（世界坐标）
 * @param robot_y 机器人Y坐标（世界坐标）
 * @param robot_yaw 机器人航向角（弧度）
 * @param min_x 更新区域最小X坐标（输出参数）
 * @param min_y 更新区域最小Y坐标（输出参数）
 * @param max_x 更新区域最大X坐标（输出参数）
 * @param max_y 更新区域最大Y坐标（输出参数）
 */
void InflationLayer::updateBounds(double robot_x, double robot_y, double robot_yaw, double* min_x,
                                           double* min_y, double* max_x, double* max_y)
{
  // 如果需要完全重新膨胀
  if (need_reinflation_)
  {
    // 保存上次边界
    last_min_x_ = *min_x;
    last_min_y_ = *min_y;
    last_max_x_ = *max_x;
    last_max_y_ = *max_y;

    // 扩展到整个地图（使用float的极值）
    *min_x = -std::numeric_limits<float>::max();
    *min_y = -std::numeric_limits<float>::max();
    *max_x = std::numeric_limits<float>::max();
    *max_y = std::numeric_limits<float>::max();

    // 重置标志
    need_reinflation_ = false;
  }
  else
  {
    // 保存上次边界用于比较
    double tmp_min_x = last_min_x_;
    double tmp_min_y = last_min_y_;
    double tmp_max_x = last_max_x_;
    double tmp_max_y = last_max_y_;

    // 更新上次边界为当前边界
    last_min_x_ = *min_x;
    last_min_y_ = *min_y;
    last_max_x_ = *max_x;
    last_max_y_ = *max_y;

    // 扩展边界（加上膨胀半径）
    *min_x = std::min(tmp_min_x, *min_x) - inflation_radius_;
    *min_y = std::min(tmp_min_y, *min_y) - inflation_radius_;
    *max_x = std::max(tmp_max_x, *max_x) + inflation_radius_;
    *max_y = std::max(tmp_max_y, *max_y) + inflation_radius_;
  }
}

/**
 * @brief 足迹改变回调函数
 *
 * 当机器人足迹改变时调用：
 * 1. 更新内切圆半径
 * 2. 重新计算膨胀半径（栅格数）
 * 3. 重新计算距离和代价缓存
 * 4. 标记需要完全重新膨胀
 */
void InflationLayer::onFootprintChanged()
{
  // 获取主代价地图指针
  costmap2D::Costmap2D* costmap = layered_costmap_->getCostmap();
  
  // 更新内切圆半径和外接圆半径（从LayeredCostmap获取）
  inscribed_radius_ = layered_costmap_->getInscribedRadius();
  circumscribed_radius_ = layered_costmap_->getCircumscribedRadius();

  // 重新计算膨胀半径（栅格数）
  cell_inflation_radius_ = costmap->cellDistance(inflation_radius_);

  // 重新计算缓存
  computeCaches();

  // 标记需要完全重新膨胀
  need_reinflation_ = true;
}

/**
 * @brief 更新代价函数 - 核心膨胀算法
 *
 * 对指定区域内的障碍物进行膨胀处理，主要步骤：
 * 1. 扩展更新边界以包含膨胀区域
 * 2. 收集所有致命障碍物作为膨胀起点
 * 3. 按距离递增顺序处理栅格
 * 4. 从缓存获取代价值并写入主代价地图
 * 5. 将相邻栅格加入膨胀队列
 *
 * @param master_grid 主代价地图
 * @param min_i 更新区域最小栅格X索引
 * @param min_j 更新区域最小栅格Y索引
 * @param max_i 更新区域最大栅格X索引
 * @param max_j 更新区域最大栅格Y索引
 */
void InflationLayer::updateCosts(costmap2D::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j)
{
  // 获取互斥锁
  boost::unique_lock < boost::recursive_mutex > lock(*inflation_access_);

  // 如果膨胀半径为0，无需膨胀
  if (cell_inflation_radius_ == 0)
    return;

  // 断言：膨胀队列必须为空（应该在上次处理结束时清空）
  BOOST_ASSERT_MSG(inflation_cells_.empty(), "The inflation list must be empty at the beginning of inflation");

  // 获取主代价地图的底层数组指针
  unsigned char* master_array = master_grid.getCharMap();

  // 获取代价地图尺寸
  unsigned int size_x = master_grid.getSizeInCellsX(), size_y = master_grid.getSizeInCellsY();

  // 检查并初始化已访问数组
  if (seen_ == NULL) {
    seen_size_ = size_x * size_y;
    seen_ = new bool[seen_size_];
  }
  else if (seen_size_ != size_x * size_y)
  {
    // 如果尺寸不匹配，重新分配
    delete[] seen_;
    seen_size_ = size_x * size_y;
    seen_ = new bool[seen_size_];
  }

  // 重置已访问标记（全部设为false）
  memset(seen_, false, size_x * size_y * sizeof(bool));

  // ========== 扩展更新边界 ==========
  // 需要包含膨胀半径范围内的栅格，因为这些栅格会影响边界内栅格的代价
  min_i -= cell_inflation_radius_;
  min_j -= cell_inflation_radius_;
  max_i += cell_inflation_radius_;
  max_j += cell_inflation_radius_;

  // 裁剪到地图边界内
  min_i = std::max(0, min_i);
  min_j = std::max(0, min_j);
  max_i = std::min(int(size_x), max_i);
  max_j = std::min(int(size_y), max_j);

  // ========== 收集致命障碍物 ==========
  // 使用map<distance, vector<CellData>>按距离分组存储待处理栅格
  // 距离为0.0的bin存储所有致命障碍物
  std::vector<CellData>& obs_bin = inflation_cells_[0.0];

  int lethal_count_in_obs_bin = 0;
  for (int j = min_j; j < max_j; j++)
  {
    for (int i = min_i; i < max_i; i++)
    {
      int index = master_grid.getIndex(i, j);
      unsigned char cost = master_array[index];

      // 如果是致命障碍，加入膨胀队列
      if (cost == LETHAL_OBSTACLE)
      {
        // 源坐标 = 当前坐标（自己就是障碍物）
        obs_bin.push_back(CellData(index, i, j, i, j));
        lethal_count_in_obs_bin++;
      }
    }
  }
  printf("[InflationLayer] obs_bin size: %zu, LETHAL in range: %d, inflation_cells_ total size: %zu\n",
         obs_bin.size(), lethal_count_in_obs_bin, inflation_cells_.size());

  // ========== 按距离递增处理栅格 ==========
  // map会自动按key（距离）排序，确保按距离递增处理
  std::map<double, std::vector<CellData> >::iterator bin;
  int processed_cells = 0;
  for (bin = inflation_cells_.begin(); bin != inflation_cells_.end(); ++bin)
  {
    // 处理当前距离bin中的所有栅格
    for (int i = 0; i < bin->second.size(); ++i)
    {
      processed_cells++;
      const CellData& cell = bin->second[i];

      unsigned int index = cell.index_;

      // 如果已经处理过，跳过
      if (seen_[index])
      {
        continue;
      }

      // 标记为已处理
      seen_[index] = true;

      // 获取栅格坐标和源障碍物坐标
      unsigned int mx = cell.x_;
      unsigned int my = cell.y_;
      unsigned int sx = cell.src_x_;
      unsigned int sy = cell.src_y_;

      // ========== 更新代价值 ==========
      // 从缓存获取预计算的代价值
      unsigned char cost = costLookup(mx, my, sx, sy);
      unsigned char old_cost = master_array[index];

      // 膨胀代价写入逻辑
      // 1. LETHAL_OBSTACLE (254) 保持不变
      // 2. NO_INFORMATION (255) 可以被膨胀代价覆盖（如果 inflate_unknown_ 为 true 或 cost >= FREE_SPACE）
      // 3. 其他情况，只有当新代价大于原代价时才写入
      if (old_cost == LETHAL_OBSTACLE)
      {
        // 障碍物保持不变，不降级
        // 但仍然 enqueue 相邻栅格
      }
      else if (old_cost == NO_INFORMATION)
      {
        // 未知区域可以被膨胀覆盖
        if (inflate_unknown_ || cost > FREE_SPACE)
        {
          master_array[index] = cost;
        }
      }
      else if (cost > old_cost)
      {
        // 其他情况，只有当新代价更高时才覆盖
        master_array[index] = cost;
      }

      // ========== 将相邻栅格加入膨胀队列 ==========
      if (mx > 0)
        enqueue(index - 1, mx - 1, my, sx, sy);      // 左
      if (my > 0)
        enqueue(index - size_x, mx, my - 1, sx, sy);  // 上
      if (mx < size_x - 1)
        enqueue(index + 1, mx + 1, my, sx, sy);      // 右
      if (my < size_y - 1)
        enqueue(index + size_x, mx, my + 1, sx, sy);  // 下
    }
  }

  printf("[InflationLayer] 处理完成: processed_cells=%d, inflation_cells_ size after loop: %zu\n",
         processed_cells, inflation_cells_.size());

  // 清空膨胀队列，准备下次处理
  inflation_cells_.clear();
}

/**
 * @brief 将栅格加入膨胀队列
 *
 * 根据栅格到障碍物的距离，将其加入对应距离的处理队列。
 * 如果栅格超出膨胀半径范围或已被访问，则忽略。
 *
 * @param index 栅格线性索引
 * @param mx 栅格X坐标
 * @param my 栅格Y坐标
 * @param src_x 源障碍物X坐标
 * @param src_y 源障碍物Y坐标
 */
inline void InflationLayer::enqueue(unsigned int index, unsigned int mx, unsigned int my,
                                    unsigned int src_x, unsigned int src_y)
{
  // 如果已访问，跳过
  if (!seen_[index])
  {
    // 从缓存获取到障碍物的距离
    double distance = distanceLookup(mx, my, src_x, src_y);

    // 如果超出膨胀半径，忽略
    if (distance > cell_inflation_radius_)
      return;

    // 加入对应距离的队列
    inflation_cells_[distance].push_back(CellData(index, mx, my, src_x, src_y));
  }
}

/**
 * @brief 计算距离和代价缓存表
 *
 * 预计算膨胀半径范围内所有栅格组合的距离和对应代价值：
 * 1. 创建二维数组存储距离和代价
 * 2. 预计算欧氏距离：distance = sqrt(dx² + dy²)
 * 3. 预计算代价值：调用computeCost()
 *
 * 优化效果：避免在膨胀过程中重复计算距离和代价，大幅提升性能。
 */
void InflationLayer::computeCaches()
{
  // 如果膨胀半径为0，无需计算缓存
  if (cell_inflation_radius_ == 0)
    return;

  // 如果膨胀半径改变，重新分配缓存
  if (cell_inflation_radius_ != cached_cell_inflation_radius_)
  {
    // 删除旧缓存
    deleteKernels();

    // 创建新的缓存表
    cached_costs_ = new unsigned char*[cell_inflation_radius_ + 2];
    cached_distances_ = new double*[cell_inflation_radius_ + 2];

    // 初始化距离缓存
    for (unsigned int i = 0; i <= cell_inflation_radius_ + 1; ++i)
    {
      cached_costs_[i] = new unsigned char[cell_inflation_radius_ + 2];
      cached_distances_[i] = new double[cell_inflation_radius_ + 2];

      for (unsigned int j = 0; j <= cell_inflation_radius_ + 1; ++j)
      {
        // 预计算欧氏距离
        cached_distances_[i][j] = hypot(i, j);
      }
    }

    // 更新缓存的膨胀半径
    cached_cell_inflation_radius_ = cell_inflation_radius_;
  }

  // 计算代价值缓存
  for (unsigned int i = 0; i <= cell_inflation_radius_ + 1; ++i)
  {
    for (unsigned int j = 0; j <= cell_inflation_radius_ + 1; ++j)
    {
      cached_costs_[i][j] = computeCost(cached_distances_[i][j]);
    }
  }
}

/**
 * @brief 删除缓存表（释放内存）
 *
 * 释放距离和代价缓存表占用的内存。
 */
void InflationLayer::deleteKernels()
{
  // 删除距离缓存
  if (cached_distances_ != NULL)
  {
    for (unsigned int i = 0; i <= cached_cell_inflation_radius_ + 1; ++i)
    {
      if (cached_distances_[i])
        delete[] cached_distances_[i];
    }
    delete[] cached_distances_;
    cached_distances_ = NULL;
  }

  // 删除代价缓存
  if (cached_costs_ != NULL)
  {
    for (unsigned int i = 0; i <= cached_cell_inflation_radius_ + 1; ++i)
    {
      if (cached_costs_[i])
        delete[] cached_costs_[i];
    }
    delete[] cached_costs_;
    cached_costs_ = NULL;
  }
}

/**
 * @brief 设置膨胀参数
 *
 * 更新膨胀半径和代价衰减权重，并触发重新计算缓存和完全重新膨胀。
 * 使用互斥锁保护缓存访问，避免并发访问问题。
 *
 * @param inflation_radius 膨胀半径（米）
 * @param cost_scaling_factor 代价衰减权重（影响指数衰减速度）
 */
void InflationLayer::setInflationParameters(double inflation_radius, double cost_scaling_factor)
{
  // 如果参数没有改变，无需处理
  if (weight_ != cost_scaling_factor || inflation_radius_ != inflation_radius)
  {
    // 获取互斥锁，保护缓存访问
    boost::unique_lock < boost::recursive_mutex > lock(*inflation_access_);

    // 更新参数（cell_inflation_radius_ 将在 matchSize() 中计算）
    inflation_radius_ = inflation_radius;
    weight_ = cost_scaling_factor;

    // 标记需要完全重新膨胀
    need_reinflation_ = true;

    // 如果分辨率已设置，重新计算缓存
    if (resolution_ > 0) {
      cell_inflation_radius_ = static_cast<unsigned int>(inflation_radius_ / resolution_);
      computeCaches();
    }
  }
}

}  // namespace costmap2D