#include <costmap_2d/layered_costmap.h>
#include <costmap_2d/footprint.h>
#include <cstdio>
#include <string>
#include <algorithm>
#include <vector>

using std::vector;

namespace costmap2D
{

/**
 * @brief 构造函数
 * 
 * 初始化分层代价地图的核心参数和默认值。
 * 
 * @param global_frame 全局坐标系名称（通常为 "map"）
 * @param rolling_window 是否启用滚动窗口模式
 * @param track_unknown 是否跟踪未知空间
 */
LayeredCostmap::LayeredCostmap(std::string global_frame, bool rolling_window, bool track_unknown) :
    costmap_(),
    global_frame_(global_frame),
    rolling_window_(rolling_window),
    current_(false),
    minx_(0.0),
    miny_(0.0),
    maxx_(0.0),
    maxy_(0.0),
    bx0_(0),
    bxn_(0),
    by0_(0),
    byn_(0),
    initialized_(false),
    size_locked_(false),
    circumscribed_radius_(1.0),
    inscribed_radius_(0.3)
{
  // 设置代价地图默认值
  // 如果跟踪未知空间，默认值为 NO_INFORMATION(255)
  // 否则默认值为 FREE_SPACE(0)
  if (track_unknown)
    costmap_.setDefaultValue(NO_INFORMATION);
  else
    costmap_.setDefaultValue(FREE_SPACE);
}

/**
 * @brief 析构函数
 * 
 * 清理所有图层插件。
 */
LayeredCostmap::~LayeredCostmap()
{
  while (plugins_.size() > 0)
  {
    plugins_.pop_back();
  }
}

/**
 * @brief 调整地图尺寸
 * 
 * 调整主代价地图尺寸，并同步所有图层的尺寸。
 * 使用互斥锁保证线程安全。
 * 
 * @param size_x X方向栅格数
 * @param size_y Y方向栅格数
 * @param resolution 分辨率（米/栅格）
 * @param origin_x 原点X坐标（世界坐标，米）
 * @param origin_y 原点Y坐标（世界坐标，米）
 * @param size_locked 是否锁定尺寸
 */
void LayeredCostmap::resizeMap(unsigned int size_x, unsigned int size_y, double resolution, double origin_x,
                               double origin_y, bool size_locked)
{
  // 获取互斥锁，确保线程安全
  boost::unique_lock<Costmap2D::mutex_t> lock(*(costmap_.getMutex()));
  
  // 锁定尺寸标志
  size_locked_ = size_locked;
  
  // 调整主代价地图尺寸
  costmap_.resizeMap(size_x, size_y, resolution, origin_x, origin_y);
  
  // 同步所有图层的尺寸
  for (vector<boost::shared_ptr<Layer> >::iterator plugin = plugins_.begin(); plugin != plugins_.end();
      ++plugin)
  {
    (*plugin)->matchSize();
  }
}

/**
 * @brief 更新代价地图（核心函数）
 * 
 * 这是代价地图更新的主入口，按顺序执行以下步骤：
 * 1. 获取互斥锁保证线程安全
 * 2. 滚动窗口模式下更新地图原点
 * 3. 遍历所有图层收集更新边界
 * 4. 将世界坐标转换为地图坐标并裁剪到边界内
 * 5. 重置更新区域
 * 6. 遍历所有图层融合代价数据
 * 
 * @param robot_x 机器人X坐标（世界坐标，米）
 * @param robot_y 机器人Y坐标（世界坐标，米）
 * @param robot_yaw 机器人航向角（弧度）
 */
void LayeredCostmap::updateMap(double robot_x, double robot_y, double robot_yaw)
{
  // 获取互斥锁，确保线程安全
  // 某些图层（如VoxelLayer）的updateBounds()不是线程安全的
  boost::unique_lock<Costmap2D::mutex_t> lock(*(costmap_.getMutex()));

  // 滚动窗口模式：地图随机器人移动
  // 将地图原点设置为机器人位置减去地图尺寸的一半
  if (rolling_window_)
  {
    double new_origin_x = robot_x - costmap_.getSizeInMetersX() / 2;
    double new_origin_y = robot_y - costmap_.getSizeInMetersY() / 2;
    costmap_.updateOrigin(new_origin_x, new_origin_y);
  }

  // 如果没有图层，直接返回
  if (plugins_.size() == 0)
    return;

  printf("[INFO] LayeredCostmap::updateMap() - 图层数量: %lu\n", plugins_.size());
  
  // 初始化更新边界为极端值
  minx_ = miny_ = 1e30;   // 极大值
  maxx_ = maxy_ = -1e30;   // 极小值

  // 第一遍遍历：收集所有图层的更新边界
  for (vector<boost::shared_ptr<Layer> >::iterator plugin = plugins_.begin(); plugin != plugins_.end();
       ++plugin)
  {
    printf("[INFO] LayeredCostmap::updateMap() - 处理图层: %s, isEnabled: %d\n", 
             (*plugin)->getName().c_str(), (*plugin)->isEnabled());
    
    // 跳过禁用的图层
    if(!(*plugin)->isEnabled())
      continue;
    
    // 保存更新前的边界值用于检测非法变化
    double prev_minx = minx_;
    double prev_miny = miny_;
    double prev_maxx = maxx_;
    double prev_maxy = maxy_;
    
    // 调用图层的updateBounds()收集边界
    (*plugin)->updateBounds(robot_x, robot_y, robot_yaw, &minx_, &miny_, &maxx_, &maxy_);
    
    // 检测边界是否非法变化（边界应该是单调扩展的）
    if (minx_ > prev_minx || miny_ > prev_miny || maxx_ < prev_maxx || maxy_ < prev_maxy)
    {
      printf("[WARN] Illegal bounds change, was [tl: (%f, %f), br: (%f, %f)], but "
                        "is now [tl: (%f, %f), br: (%f, %f)]. The offending layer is %s",
                        prev_minx, prev_miny, prev_maxx , prev_maxy,
                        minx_, miny_, maxx_ , maxy_,
                        (*plugin)->getName().c_str());
    }
  }

  // 将世界坐标转换为地图坐标（强制边界约束）
  int x0, xn, y0, yn;
  costmap_.worldToMapEnforceBounds(minx_, miny_, x0, y0);
  costmap_.worldToMapEnforceBounds(maxx_, maxy_, xn, yn);

  // 裁剪到地图边界内
  x0 = std::max(0, x0);
  xn = std::min(int(costmap_.getSizeInCellsX()), xn + 1);
  y0 = std::max(0, y0);
  yn = std::min(int(costmap_.getSizeInCellsY()), yn + 1);

  printf("[DEBUG] Updating area x: [%d, %d] y: [%d, %d]", x0, xn, y0, yn);

  // 如果边界无效，直接返回
  if (xn < x0 || yn < y0)
    return;

  // 重置更新区域为默认值
  costmap_.resetMap(x0, y0, xn, yn);
  
  // 第二遍遍历：将各图层的代价数据融合到主地图
  for (vector<boost::shared_ptr<Layer> >::iterator plugin = plugins_.begin(); plugin != plugins_.end();
       ++plugin)
  {
    if((*plugin)->isEnabled())
      (*plugin)->updateCosts(costmap_, x0, y0, xn, yn);
  }

  // 保存更新区域边界（地图坐标）
  bx0_ = x0;
  bxn_ = xn;
  by0_ = y0;
  byn_ = yn;

  // 标记为已初始化
  initialized_ = true;
}

/**
 * @brief 检查所有图层是否为最新状态
 * 
 * 遍历所有启用的图层，检查它们的isCurrent()状态。
 * 只有当所有图层都是最新的，返回true。
 * 
 * @return true 表示所有启用的图层都是最新的
 */
bool LayeredCostmap::isCurrent()
{
  current_ = true;
  for (vector<boost::shared_ptr<Layer> >::iterator plugin = plugins_.begin(); plugin != plugins_.end();
      ++plugin)
  {
    if((*plugin)->isEnabled())
      current_ = current_ && (*plugin)->isCurrent();
  }
  return current_;
}

/**
 * @brief 设置机器人足迹
 * 
 * 更新存储的足迹，计算内切圆和外接圆半径，并通知所有图层。
 * 
 * @param footprint_spec 机器人足迹多边形
 */
void LayeredCostmap::setFootprint(const std::vector<Point>& footprint_spec)
{
  // 保存足迹多边形
  footprint_ = footprint_spec;
  
  // 计算内切圆和外接圆半径
  costmap2D::calculateMinAndMaxDistances(footprint_spec, inscribed_radius_, circumscribed_radius_);

  // 通知所有图层足迹已改变
  for (vector<boost::shared_ptr<Layer> >::iterator plugin = plugins_.begin(); plugin != plugins_.end();
      ++plugin)
  {
    (*plugin)->onFootprintChanged();
  }
}

}  // namespace costmap2D
