#include <costmap_2d/observation_buffer.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>  // TF2几何消息转换
#include <tf2_sensor_msgs/tf2_sensor_msgs.h>      // TF2传感器消息转换
#include <sensor_msgs/point_cloud2_iterator.h>    // PointCloud2迭代器

// 使用标准命名空间和TF2命名空间
using namespace std;
using namespace tf2;

namespace costmap_2d
{

/**
 * @brief 构造函数，初始化观测缓冲区的所有成员变量
 * 
 * 初始化列表按顺序初始化成员变量，包括：
 * - TF2缓冲区引用
 * - 观测保留时间和期望更新频率（转换为ros::Duration）
 * - 最后更新时间戳（设为当前时间）
 * - 坐标系名称（全局坐标系和传感器坐标系）
 * - 话题名称（用于日志输出）
 * - 高度阈值（最小/最大障碍物高度）
 * - 传感器范围参数（障碍物范围和射线追踪范围）
 * - TF变换容忍时间
 * 
 * @param topic_name        观测数据的话题名称
 * @param observation_keep_time 观测数据保留时间（秒）
 * @param expected_update_rate 期望更新频率（秒）
 * @param min_obstacle_height 障碍物最小高度（米）
 * @param max_obstacle_height 障碍物最大高度（米）
 * @param obstacle_range    障碍物检测范围（米）
 * @param raytrace_range    射线追踪范围（米）
 * @param tf2_buffer        TF2缓冲区引用
 * @param global_frame      目标全局坐标系
 * @param sensor_frame      传感器坐标系（可为空）
 * @param tf_tolerance      TF变换容忍时间（秒）
 */
ObservationBuffer::ObservationBuffer(string topic_name, double observation_keep_time, double expected_update_rate,
                                     double min_obstacle_height, double max_obstacle_height, double obstacle_range,
                                     double raytrace_range, tf2_ros::Buffer& tf2_buffer, string global_frame,
                                     string sensor_frame, double tf_tolerance) :
    tf2_buffer_(tf2_buffer), 
    observation_keep_time_(observation_keep_time), 
    expected_update_rate_(expected_update_rate),
    last_updated_(ros::Time::now()), 
    global_frame_(global_frame), 
    sensor_frame_(sensor_frame), 
    topic_name_(topic_name),
    min_obstacle_height_(min_obstacle_height), 
    max_obstacle_height_(max_obstacle_height),
    obstacle_range_(obstacle_range), 
    raytrace_range_(raytrace_range), 
    tf_tolerance_(tf_tolerance)
{
}

/**
 * @brief 析构函数，默认实现
 * 
 * 由于没有动态分配的资源需要显式释放，析构函数为空
 */
ObservationBuffer::~ObservationBuffer()
{
}

/**
 * @brief 设置新的全局坐标系，并将所有缓存数据变换到新坐标系
 * 
 * 该函数执行以下步骤：
 * 1. 检查新坐标系与旧坐标系之间的变换是否可用
 * 2. 遍历所有缓存的观测数据
 * 3. 对每个观测的传感器原点进行坐标变换
 * 4. 对每个观测的点云数据进行坐标变换
 * 5. 更新全局坐标系成员变量
 * 
 * @param new_global_frame 新的全局坐标系名称
 * @return 变换成功返回true，失败返回false
 */
bool ObservationBuffer::setGlobalFrame(const std::string new_global_frame)
{
  // 获取当前时间作为变换时间戳
  ros::Time transform_time = ros::Time::now();
  std::string tf_error;

  // 检查新坐标系与旧坐标系之间的变换是否可用
  if (!tf2_buffer_.canTransform(new_global_frame, global_frame_, transform_time, 
                                ros::Duration(tf_tolerance_), &tf_error))
  {
    ROS_ERROR("Transform between %s and %s with tolerance %.2f failed: %s.", 
              new_global_frame.c_str(), global_frame_.c_str(), 
              tf_tolerance_, tf_error.c_str());
    return false;
  }

  // 遍历所有缓存的观测数据，逐一进行坐标变换
  list<Observation>::iterator obs_it;
  for (obs_it = observation_list_.begin(); obs_it != observation_list_.end(); ++obs_it)
  {
    try
    {
      Observation& obs = *obs_it;

      // 构建传感器原点的PointStamped消息
      geometry_msgs::PointStamped origin;
      origin.header.frame_id = global_frame_;
      origin.header.stamp = transform_time;
      origin.point = obs.origin_;

      // 将传感器原点从旧坐标系变换到新坐标系
      tf2_buffer_.transform(origin, origin, new_global_frame);
      obs.origin_ = origin.point;

      // 将点云数据从旧坐标系变换到新坐标系
      tf2_buffer_.transform(*(obs.cloud_), *(obs.cloud_), new_global_frame);
    }
    catch (TransformException& ex)
    {
      ROS_ERROR("TF Error attempting to transform an observation from %s to %s: %s", 
                global_frame_.c_str(), new_global_frame.c_str(), ex.what());
      return false;
    }
  }

  // 更新全局坐标系成员变量
  global_frame_ = new_global_frame;
  return true;
}

/**
 * @brief 接收点云数据，进行坐标变换和高度过滤后缓存
 * 
 * 该函数是观测缓冲区的核心方法，执行以下步骤：
 * 1. 创建新的观测对象并添加到列表头部
 * 2. 确定传感器原点坐标系
 * 3. 将传感器原点变换到全局坐标系
 * 4. 将点云数据变换到全局坐标系
 * 5. 根据高度阈值过滤点云数据
 * 6. 更新最后更新时间戳
 * 7. 清理过期观测数据
 * 
 * @param cloud 需要处理和缓存的点云数据
 */
void ObservationBuffer::bufferCloud(const sensor_msgs::PointCloud2& cloud)
{
  // 存储变换后的传感器原点
  geometry_msgs::PointStamped global_origin;

  // 在列表头部创建新的空观测对象
  observation_list_.push_front(Observation());

  // 确定传感器原点坐标系：如果sensor_frame_为空，则从点云消息头获取
  string origin_frame = sensor_frame_ == "" ? cloud.header.frame_id : sensor_frame_;

  try
  {
    // === 步骤1：变换传感器原点 ===
    geometry_msgs::PointStamped local_origin;
    local_origin.header.stamp = cloud.header.stamp;
    local_origin.header.frame_id = origin_frame;
    local_origin.point.x = 0;  // 传感器原点在自身坐标系中为(0,0,0)
    local_origin.point.y = 0;
    local_origin.point.z = 0;
    
    // 将传感器原点变换到全局坐标系
    tf2_buffer_.transform(local_origin, global_origin, global_frame_);
    tf2::convert(global_origin.point, observation_list_.front().origin_);

    // === 步骤2：设置观测范围参数 ===
    observation_list_.front().raytrace_range_ = raytrace_range_;
    observation_list_.front().obstacle_range_ = obstacle_range_;

    // === 步骤3：变换点云数据 ===
    sensor_msgs::PointCloud2 global_frame_cloud;
    tf2_buffer_.transform(cloud, global_frame_cloud, global_frame_);
    global_frame_cloud.header.stamp = cloud.header.stamp;

    // === 步骤4：高度过滤 ===
    sensor_msgs::PointCloud2& observation_cloud = *(observation_list_.front().cloud_);
    
    // 复制点云元数据（高度、宽度、字段定义等）
    observation_cloud.height = global_frame_cloud.height;
    observation_cloud.width = global_frame_cloud.width;
    observation_cloud.fields = global_frame_cloud.fields;
    observation_cloud.is_bigendian = global_frame_cloud.is_bigendian;
    observation_cloud.point_step = global_frame_cloud.point_step;
    observation_cloud.row_step = global_frame_cloud.row_step;
    observation_cloud.is_dense = global_frame_cloud.is_dense;

    // 初始化点云大小
    unsigned int cloud_size = global_frame_cloud.height * global_frame_cloud.width;
    sensor_msgs::PointCloud2Modifier modifier(observation_cloud);
    modifier.resize(cloud_size);
    unsigned int point_count = 0;

    // 遍历点云，过滤高度不在阈值范围内的点
    sensor_msgs::PointCloud2Iterator<float> iter_z(global_frame_cloud, "z");
    std::vector<unsigned char>::const_iterator iter_global = global_frame_cloud.data.begin();
    std::vector<unsigned char>::const_iterator iter_global_end = global_frame_cloud.data.end();
    std::vector<unsigned char>::iterator iter_obs = observation_cloud.data.begin();

    for (; iter_global != iter_global_end; ++iter_z, iter_global += global_frame_cloud.point_step)
    {
      // 检查点的z坐标是否在有效高度范围内
      if ((*iter_z) <= max_obstacle_height_ && (*iter_z) >= min_obstacle_height_)
      {
        // 复制有效点到输出点云
        std::copy(iter_global, iter_global + global_frame_cloud.point_step, iter_obs);
        iter_obs += global_frame_cloud.point_step;
        ++point_count;
      }
    }

    // 调整输出点云大小为实际有效点数量
    modifier.resize(point_count);
    observation_cloud.header.stamp = cloud.header.stamp;
    observation_cloud.header.frame_id = global_frame_cloud.header.frame_id;
  }
  catch (TransformException& ex)
  {
    // 如果发生变换异常，移除刚创建的空观测对象
    observation_list_.pop_front();
    ROS_ERROR("TF Exception that should never happen for sensor frame: %s, cloud frame: %s, %s", 
              sensor_frame_.c_str(), cloud.header.frame_id.c_str(), ex.what());
    return;
  }

  // 更新最后更新时间戳
  last_updated_ = ros::Time::now();

  // 清理过期观测数据
  purgeStaleObservations();
}

/**
 * @brief 获取所有当前有效的观测数据副本
 * 
 * 该函数先清理过期数据，然后将所有有效观测数据复制到输出向量中。
 * 
 * @param observations 用于接收观测数据的向量引用
 */
void ObservationBuffer::getObservations(vector<Observation>& observations)
{
  // 先清理过期观测数据
  purgeStaleObservations();

  // 将所有有效观测数据复制到输出向量
  list<Observation>::iterator obs_it;
  for (obs_it = observation_list_.begin(); obs_it != observation_list_.end(); ++obs_it)
  {
    observations.push_back(*obs_it);
  }
}

/**
 * @brief 清理过期的观测数据
 * 
 * 根据 observation_keep_time_ 设置的时间窗口清理过期数据：
 * - 如果 observation_keep_time_ 为0，只保留最新的一个观测
 * - 否则遍历列表，移除时间戳超过保留时间的观测
 * 
 * 注意：由于观测数据按时间顺序存储（最新的在列表头部），
 * 一旦找到过期数据，其后的所有数据都必然过期，可以一次性删除。
 */
void ObservationBuffer::purgeStaleObservations()
{
  if (observation_list_.empty())
    return;

  list<Observation>::iterator obs_it = observation_list_.begin();

  // 特殊情况：如果保留时间为0，只保留最新的一个观测
  if (observation_keep_time_ == ros::Duration(0.0))
  {
    observation_list_.erase(++obs_it, observation_list_.end());
    return;
  }

  // 遍历观测列表，查找过期数据
  for (obs_it = observation_list_.begin(); obs_it != observation_list_.end(); ++obs_it)
  {
    Observation& obs = *obs_it;
    
    // 检查观测是否过期：当前时间 - 观测时间戳 > 保留时间
    if ((last_updated_ - obs.cloud_->header.stamp) > observation_keep_time_)
    {
      // 移除当前及之后的所有观测（因为列表按时间排序）
      observation_list_.erase(obs_it, observation_list_.end());
      return;
    }
  }
}

/**
 * @brief 检查观测缓冲区是否按预期频率更新
 * 
 * 如果 expected_update_rate_ 为0，表示不限制更新频率，直接返回true。
 * 否则检查自上次更新以来的时间是否超过了预期更新周期。
 * 
 * @return 如果按预期更新返回true，否则返回false并发出警告
 */
bool ObservationBuffer::isCurrent() const
{
  // 如果不限制更新频率，直接返回true
  if (expected_update_rate_ == ros::Duration(0.0))
    return true;

  // 检查是否超过预期更新周期
  bool current = (ros::Time::now() - last_updated_).toSec() <= expected_update_rate_.toSec();
  
  if (!current)
  {
    ROS_WARN("The %s observation buffer has not been updated for %.2f seconds, "
             "and it should be updated every %.2f seconds.",
             topic_name_.c_str(), 
             (ros::Time::now() - last_updated_).toSec(), 
             expected_update_rate_.toSec());
  }
  
  return current;
}

/**
 * @brief 重置最后更新时间戳为当前时间
 * 
 * 用于在需要时强制标记缓冲区为最新状态，例如在初始化或恢复行为后。
 */
void ObservationBuffer::resetLastUpdated()
{
  last_updated_ = ros::Time::now();
}

}  // namespace costmap_2d

