#include <costmap_2d/costmap_layer.h>

namespace costmap2D
{

/**
 * @brief 触摸检测（扩展边界框）
 * 
 * 将指定点 (x,y) 添加到边界框中，动态扩展更新区域。
 * 通过取最小值/最大值实现边界框的扩展。
 * 
 * @param x X 坐标（世界坐标，米）
 * @param y Y 坐标（世界坐标，米）
 * @param min_x 边界框最小 X（输入/输出）
 * @param min_y 边界框最小 Y（输入/输出）
 * @param max_x 边界框最大 X（输入/输出）
 * @param max_y 边界框最大 Y（输入/输出）
 */
void CostmapLayer::touch(double x, double y, double* min_x, double* min_y, double* max_x, double* max_y)
{
    *min_x = std::min(x, *min_x);
    *min_y = std::min(y, *min_y);
    *max_x = std::max(x, *max_x);
    *max_y = std::max(y, *max_y);
}

/**
 * @brief 匹配父地图尺寸
 * 
 * 将此图层的尺寸、分辨率、原点与父 LayeredCostmap 同步。
 * 由 LayeredCostmap 在尺寸变化时调用。
 */
void CostmapLayer::matchSize()
{
    // 获取父代价地图指针
    Costmap2D* master = layered_costmap_->getCostmap();
    // 调整本图层尺寸以匹配父地图
    resizeMap(master->getSizeInCellsX(), master->getSizeInCellsY(), master->getResolution(),
            master->getOriginX(), master->getOriginY());
}

/**
 * @brief 清除指定区域的代价
 * 
 * 将指定矩形区域内的代价重置为 NO_INFORMATION（未知）。
 * 支持通过 invert_area 参数反转清除区域。
 * 
 * @param start_x 起始 X 坐标（地图坐标）
 * @param start_y 起始 Y 坐标（地图坐标）
 * @param end_x 结束 X 坐标（地图坐标）
 * @param end_y 结束 Y 坐标（地图坐标）
 * @param invert_area 是否反转区域（默认 false）
 */
void CostmapLayer::clearArea(int start_x, int start_y, int end_x, int end_y, bool invert_area)
{
    // 获取代价地图数组指针
    unsigned char* grid = getCharMap();
    
    // 遍历整个地图
    for(int x=0; x<(int)getSizeInCellsX(); x++){
        // 判断当前 x 是否在清除范围内
        bool xrange = x>start_x && x<end_x;

        for(int y=0; y<(int)getSizeInCellsY(); y++){
            // 根据 invert_area 决定是否跳过当前栅格
            if((xrange && y>start_y && y<end_y)!=invert_area)
                continue;
            
            // 计算栅格索引
            int index = getIndex(x,y);
            // 如果当前栅格不是未知，则设置为未知
            if(grid[index]!=NO_INFORMATION){
                grid[index] = NO_INFORMATION;
            }
        }
    }
}

/**
 * @brief 添加扩展边界
 * 
 * 如果外部源修改了代价地图中的某些区域，应调用此方法确保这些区域被包含在更新范围内。
 * 扩展边界会在 useExtraBounds() 被调用时合并到主边界框中。
 * 
 * @param mx0 边界框最小 X 值（世界坐标，米）
 * @param my0 边界框最小 Y 值（世界坐标，米）
 * @param mx1 边界框最大 X 值（世界坐标，米）
 * @param my1 边界框最大 Y 值（世界坐标，米）
 */
void CostmapLayer::addExtraBounds(double mx0, double my0, double mx1, double my1)
{
    // 扩展边界取最小/最大值
    extra_min_x_ = std::min(mx0, extra_min_x_);
    extra_max_x_ = std::max(mx1, extra_max_x_);
    extra_min_y_ = std::min(my0, extra_min_y_);
    extra_max_y_ = std::max(my1, extra_max_y_);
    // 标记存在扩展边界
    has_extra_bounds_ = true;
}

/**
 * @brief 使用扩展边界
 * 
 * 将 addExtraBounds() 设置的扩展边界合并到当前边界框中。
 * 合并后重置扩展边界为无效值，等待下一次添加。
 * 应在 updateBounds() 方法开始时调用。
 * 
 * @param min_x 边界框最小 X（输入/输出）
 * @param min_y 边界框最小 Y（输入/输出）
 * @param max_x 边界框最大 X（输入/输出）
 * @param max_y 边界框最大 Y（输入/输出）
 */
void CostmapLayer::useExtraBounds(double* min_x, double* min_y, double* max_x, double* max_y)
{
    // 如果没有扩展边界，直接返回
    if (!has_extra_bounds_)
        return;

    // 将扩展边界合并到输入的边界框中
    *min_x = std::min(extra_min_x_, *min_x);
    *min_y = std::min(extra_min_y_, *min_y);
    *max_x = std::max(extra_max_x_, *max_x);
    *max_y = std::max(extra_max_y_, *max_y);
    
    // 重置扩展边界为无效值
    extra_min_x_ = 1e6;
    extra_min_y_ = 1e6;
    extra_max_x_ = -1e6;
    extra_max_y_ = -1e6;
    has_extra_bounds_ = false;
}

/**
 * @brief 最大值融合更新
 * 
 * 将主地图值与本图层值取最大值进行融合：
 * - 如果本图层值为 NO_INFORMATION，则跳过
 * - 如果主地图值为 NO_INFORMATION，则用图层值覆盖
 * - 否则取两者中的较大值
 * 
 * 这是最常用的融合策略，确保高代价（障碍物）不会被低代价覆盖。
 * 
 * @param master_grid 主代价地图
 * @param min_i 区域最小列索引
 * @param min_j 区域最小行索引
 * @param max_i 区域最大列索引
 * @param max_j 区域最大行索引
 */
void CostmapLayer::updateWithMax(costmap2D::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j)
{
    // 如果图层未启用，直接返回
    if (!enabled_)
        return;

    // 获取主地图数组和宽度
    unsigned char* master_array = master_grid.getCharMap();
    unsigned int span = master_grid.getSizeInCellsX();

    // 遍历指定区域
    for (int j = min_j; j < max_j; j++)
    {
        unsigned int it = j * span + min_i;
        for (int i = min_i; i < max_i; i++)
        {
            // 如果本图层值为未知，跳过
            if (costmap_[it] == NO_INFORMATION){
                it++;
                continue;
            }

            // 获取主地图当前值
            unsigned char old_cost = master_array[it];
            // 如果主地图值为未知或小于本图层值，则更新
            if (old_cost == NO_INFORMATION || old_cost < costmap_[it])
                master_array[it] = costmap_[it];
            it++;
        }
    }
}

/**
 * @brief 无条件覆盖更新
 * 
 * 将本图层指定区域的所有值（包括 NO_INFORMATION）写入主地图。
 * 不进行任何条件判断，直接覆盖。
 * 
 * @param master_grid 主代价地图
 * @param min_i 区域最小列索引
 * @param min_j 区域最小行索引
 * @param max_i 区域最大列索引
 * @param max_j 区域最大行索引
 */
void CostmapLayer::updateWithTrueOverwrite(costmap2D::Costmap2D& master_grid, int min_i, int min_j,
                                           int max_i, int max_j)
{
    if (!enabled_)
        return;
    
    unsigned char* master = master_grid.getCharMap();
    unsigned int span = master_grid.getSizeInCellsX();

    for (int j = min_j; j < max_j; j++)
    {
        unsigned int it = span*j+min_i;
        for (int i = min_i; i < max_i; i++)
        {
            // 无条件覆盖
            master[it] = costmap_[it];
            it++;
        }
    }
}

/**
 * @brief 有条件覆盖更新
 * 
 * 将本图层指定区域的有效值（不包括 NO_INFORMATION）写入主地图。
 * 只有当本图层值有效时才更新主地图。
 * 
 * @param master_grid 主代价地图
 * @param min_i 区域最小列索引
 * @param min_j 区域最小行索引
 * @param max_i 区域最大列索引
 * @param max_j 区域最大行索引
 */
void CostmapLayer::updateWithOverwrite(costmap2D::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j)
{
    if (!enabled_)
        return;
    
    unsigned char* master = master_grid.getCharMap();
    unsigned int span = master_grid.getSizeInCellsX();

    for (int j = min_j; j < max_j; j++)
    {
        unsigned int it = span*j+min_i;
        for (int i = min_i; i < max_i; i++)
        {
            // 只有当本图层值不为未知时才覆盖
            if (costmap_[it] != NO_INFORMATION)
                master[it] = costmap_[it];
            it++;
        }
    }
}

/**
 * @brief 加法融合更新
 * 
 * 将主地图值与本图层值相加进行融合：
 * - 如果本图层值为 NO_INFORMATION，则跳过
 * - 如果主地图值为 NO_INFORMATION，则用图层值覆盖
 * - 如果相加大于 INSCRIBED_INFLATED_OBSTACLE，则设为 INSCRIBED_INFLATED_OBSTACLE - 1
 * 
 * 适用于需要累积代价的场景，如多传感器融合。
 * 
 * @param master_grid 主代价地图
 * @param min_i 区域最小列索引
 * @param min_j 区域最小行索引
 * @param max_i 区域最大列索引
 * @param max_j 区域最大行索引
 */
void CostmapLayer::updateWithAddition(costmap2D::Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j)
{
    if (!enabled_)
        return;
    
    unsigned char* master_array = master_grid.getCharMap();
    unsigned int span = master_grid.getSizeInCellsX();

    for (int j = min_j; j < max_j; j++)
    {
        unsigned int it = j * span + min_i;
        for (int i = min_i; i < max_i; i++)
        {
            // 如果本图层值为未知，跳过
            if (costmap_[it] == NO_INFORMATION){
                it++;
                continue;
            }

            unsigned char old_cost = master_array[it];
            if (old_cost == NO_INFORMATION)
                // 主地图值为未知，直接覆盖
                master_array[it] = costmap_[it];
            else
            {
                // 代价相加
                int sum = old_cost + costmap_[it];
                // 限制最大值
                if (sum >= costmap2D::INSCRIBED_INFLATED_OBSTACLE)
                    master_array[it] = costmap2D::INSCRIBED_INFLATED_OBSTACLE - 1;
                else
                    master_array[it] = sum;
            }
            it++;
        }
    }
}

}  // namespace costmap2D