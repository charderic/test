/**
 * @file footprint.cpp
 * @brief 机器人足迹处理实现
 *
 * 本模块提供机器人足迹相关的核心功能：
 * 1. 计算内切圆和外接圆半径
 * 2. 坐标变换（局部坐标到世界坐标）
 * 3. 足迹扩展
 * 4. 从半径创建圆形足迹
 */

#include <costmap_2d/costmap_2d.h>
#include <boost/tokenizer.hpp>
#include <boost/foreach.hpp>
#include <boost/algorithm/string.hpp>
#include <costmap_2d/footprint.h>
#include <costmap_2d/array_parser.h>
#include <cmath>

namespace costmap2D
{

/**
 * @brief 计算足迹多边形的内切圆和外接圆半径
 *
 * 算法原理：
 * 1. 遍历足迹的每个顶点和每条边
 * 2. 计算机器人中心(0,0)到每个顶点的距离
 * 3. 计算机器人中心到每条边的垂直距离
 * 4. 最小距离即为内切圆半径，最大距离即为外接圆半径
 *
 * @param footprint 足迹多边形（相对于机器人中心的局部坐标）
 * @param min_dist 输出参数：内切圆半径（机器人中心到足迹边缘的最小距离）
 * @param max_dist 输出参数：外接圆半径（机器人中心到足迹边缘的最大距离）
 */
void calculateMinAndMaxDistances(const std::vector<Point>& footprint, double& min_dist, double& max_dist)
{
  // 初始化：最小距离设为无穷大，最大距离设为0
  min_dist = std::numeric_limits<double>::max();
  max_dist = 0.0;

  // 如果足迹点数少于3个，无法形成多边形，直接返回
  if (footprint.size() <= 2)
  {
    return;
  }

  // 遍历足迹的每条边（从第一个点到倒数第二个点）
  for (unsigned int i = 0; i < footprint.size() - 1; ++i)
  {
    // 计算到当前顶点的距离
    double vertex_dist = distance(0.0, 0.0, footprint[i].x, footprint[i].y);

    // 计算到当前边的垂直距离
    double edge_dist = distanceToLine(0.0, 0.0, footprint[i].x, footprint[i].y,
                                      footprint[i + 1].x, footprint[i + 1].y);

    // 更新最小距离和最大距离
    min_dist = std::min(min_dist, std::min(vertex_dist, edge_dist));
    max_dist = std::max(max_dist, std::max(vertex_dist, edge_dist));
  }

  // 还需要检查最后一条边（从最后一个点到第一个点）
  unsigned int last = footprint.size() - 1;
  double vertex_dist = distance(0.0, 0.0, footprint[last].x, footprint[last].y);
  double edge_dist = distanceToLine(0.0, 0.0, footprint[last].x, footprint[last].y,
                                    footprint[0].x, footprint[0].y);

  // 更新最小距离和最大距离
  min_dist = std::min(min_dist, std::min(vertex_dist, edge_dist));
  max_dist = std::max(max_dist, std::max(vertex_dist, edge_dist));
}

/**
 * @brief 根据机器人位姿计算世界坐标系下的足迹
 *
 * 使用旋转变换将机器人局部坐标系下的足迹转换到世界坐标系
 *
 * 变换公式：
 * x' = x + cos(theta) * x_local - sin(theta) * y_local
 * y' = y + sin(theta) * x_local + cos(theta) * y_local
 *
 * @param x 机器人X坐标（世界坐标，米）
 * @param y 机器人Y坐标（世界坐标，米）
 * @param theta 机器人航向角（弧度）
 * @param footprint_spec 足迹原型（机器人局部坐标）
 * @param oriented_footprint 输出：世界坐标系下的足迹
 */
void transformFootprint(double x, double y, double theta, const std::vector<Point>& footprint_spec,
                        std::vector<Point>& oriented_footprint)
{
  // 清空输出向量并预留空间
  oriented_footprint.clear();
  oriented_footprint.reserve(footprint_spec.size());

  // 预计算三角函数
  double cos_theta = cos(theta);
  double sin_theta = sin(theta);

  // 遍历每个足迹点
  for (unsigned int i = 0; i < footprint_spec.size(); ++i)
  {
    Point new_pt;
    new_pt.x = x + cos_theta * footprint_spec[i].x - sin_theta * footprint_spec[i].y;
    new_pt.y = y + sin_theta * footprint_spec[i].x + cos_theta * footprint_spec[i].y;
    new_pt.z = footprint_spec[i].z;  // 2D地图，z坐标通常为0
    oriented_footprint.push_back(new_pt);
  }
}

/**
 * @brief 为足迹添加padding（就地修改）
 *
 * 沿每个点的方向向外扩展指定的padding距离
 *
 * 注意：这不是简单的均匀扩展，只是为每个点添加一个固定偏移
 *
 * @param footprint 要修改的足迹（输入/输出）
 * @param padding 扩展距离（米）
 */
void padFootprint(std::vector<Point>& footprint, double padding)
{
  // 如果padding为0或负数，不需要修改
  if (padding <= 0.0)
    return;

  // 遍历每个点，沿指向原点的方向偏移
  for (unsigned int i = 0; i < footprint.size(); ++i)
  {
    double dx = footprint[i].x;
    double dy = footprint[i].y;
    double norm = sqrt(dx * dx + dy * dy);

    // 如果点不在原点，则沿指向原点的方向偏移
    if (norm > 1e-6)
    {
      footprint[i].x += padding * dx / norm;
      footprint[i].y += padding * dy / norm;
    }
  }
}

/**
 * @brief 从半径创建圆形足迹
 *
 * 使用16个点近似表示圆形
 *
 * @param radius 圆的半径（米）
 * @return 圆形足迹的点向量
 */
std::vector<Point> makeFootprintFromRadius(double radius)
{
  // 使用16个点近似表示圆形
  const unsigned int num_points = 16;
  std::vector<Point> footprint;

  // 计算每个点之间的角度增量
  double angle_increment = 2.0 * M_PI / num_points;

  // 生成圆形上的点
  for (unsigned int i = 0; i < num_points; ++i)
  {
    double angle = i * angle_increment;
    Point pt;
    pt.x = radius * cos(angle);
    pt.y = radius * sin(angle);
    pt.z = 0.0;  // 2D地图，z坐标设为0
    footprint.push_back(pt);
  }

  return footprint;
}

}  // namespace costmap2D