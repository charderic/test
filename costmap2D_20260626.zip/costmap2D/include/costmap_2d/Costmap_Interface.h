#include <costmap_2d/layered_costmap.h>

class Costmap_Interface
{
    public:
// MapName: global_costmap或 local_costmap,
Costmap_Interface(string MapName);

~Costmap_Interface();

// 初始化代价地图接口:根据CostmapName读取对应的yaml配置文件，进行相应配置，如：RollingWindow
initialize();


protected:
// 构造时先赋值为global_costmap或local_costmap，
// 后续构造layered_costmap_成员时，根据CostmapName读取对应的yaml配置文件，进行相应配置，如：RollingWindow
// 
std::string CostmapName;                    
LayeredCostmap* layered_costmap_;  

}