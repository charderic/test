#ifndef COSTMAP_2D_LAYERED_COSTMAP_H_
#define COSTMAP_2D_LAYERED_COSTMAP_H_

#include <costmap_2d/cost_values.h>
#include <costmap_2d/layer.h>
#include <costmap_2d/costmap_2d.h>
#include <vector>
#include <string>

namespace costmapNS
{
class Layer;

/**
 * @class LayeredCostmap
 * @brief 分层代价地图主控类
 * 
 * 核心职责：
 * 1. 管理多个图层插件（StaticLayer, ObstacleLayer, InflationLayer等）
 * 2. 协调图层更新顺序和数据融合
 * 3. 维护主代价地图作为最终输出
 * 4. 支持滚动窗口模式的局部代价地图
 * 
 * 设计模式：组合模式 + 策略模式
 * - 组合模式：多个图层组合成一个整体
 * - 策略模式：不同图层实现不同的代价计算策略
 */
class LayeredCostmap
{
public:
  /**
   * @brief 构造函数
   * 
   * @param global_frame 全局坐标系名称（通常为 "map"）
   * @param rolling_window 是否启用滚动窗口模式
   * @param track_unknown 是否跟踪未知空间
   */
  LayeredCostmap(std::string global_frame, bool rolling_window, bool track_unknown);

  /**
   * @brief 析构函数
   */
  ~LayeredCostmap();

  /**
   * @brief 更新代价地图
   * 
   * 这是核心更新函数，按顺序执行：
   * 1. 更新滚动窗口原点（如果启用）
   * 2. 调用所有图层的 updateBounds() 收集更新边界
   * 3. 调用所有图层的 updateCosts() 融合代价数据
   * 
   * @param robot_x 机器人X坐标（世界坐标，米）
   * @param robot_y 机器人Y坐标（世界坐标，米）
   * @param robot_yaw 机器人航向角（弧度）
   */
  void updateMap(double robot_x, double robot_y, double robot_yaw);

  /**
   * @brief 获取全局坐标系名称
   * @return 全局坐标系名称
   */
  inline const std::string& getGlobalFrameID() const noexcept
  {
    return global_frame_;
  }

  /**
   * @brief 调整地图尺寸
   * 
   * 调整主代价地图尺寸，并同步所有图层的尺寸。
   * 
   * @param size_x X方向栅格数
   * @param size_y Y方向栅格数
   * @param resolution 分辨率（米/栅格）
   * @param origin_x 原点X坐标（世界坐标，米）
   * @param origin_y 原点Y坐标（世界坐标，米）
   * @param size_locked 是否锁定尺寸（防止动态重配置修改）
   */
  void resizeMap(unsigned int size_x, unsigned int size_y, double resolution, double origin_x, double origin_y,
                 bool size_locked = false);

  /**
   * @brief 获取主代价地图指针
   * @return 主代价地图指针
   */
  Costmap2D* getCostmap()
  {
    return &costmap_;
  }

  /**
   * @brief 是否为滚动窗口模式
   * @return true 表示启用滚动窗口
   */
  bool isRolling()
  {
    return rolling_window_;
  }

  /**
   * @brief 是否跟踪未知空间
   * @return true 表示未知区域用 NO_INFORMATION(255) 表示
   */
  bool isTrackingUnknown()
  {
    return costmap_.getDefaultValue() == costmapNS::NO_INFORMATION;
  }

  /**
   * @brief 添加图层插件
   * @param plugin 图层插件指针
   */
  void addPlugin(boost::shared_ptr<Layer> plugin)
  {
    plugins_.push_back(plugin);
  }

  /**
   * @brief 获取机器人足迹
   * @return 机器人足迹多边形
   */
  const std::vector<Point>& getFootprint() { return footprint_; }

  /**
   * @brief 是否已初始化
   * @return true 表示已完成初始化
   */
  bool isInitialized()
  {
      return initialized_;
  }

  double getInscribedRadius()
  {
      return inscribed_radius_;
  }

  double getCircumscribedRadius()
  {
      return circumscribed_radius_;
  }

private:
  Costmap2D costmap_;                    ///< 主代价地图（最终融合结果）
  std::string global_frame_;             ///< 全局坐标系名称

  bool rolling_window_;                  ///< 是否启用滚动窗口模式
  bool current_;                         ///< 地图是否为最新状态
  double minx_, miny_, maxx_, maxy_;     ///< 更新区域边界（世界坐标）
  unsigned int bx0_, bxn_, by0_, byn_;   ///< 更新区域边界（地图坐标）

  std::vector<boost::shared_ptr<Layer> > plugins_;  ///< 图层插件列表

  bool initialized_;                     ///< 是否已初始化
  bool size_locked_;                     ///< 尺寸是否锁定
  double circumscribed_radius_;          ///< 机器人外接圆半径
  double inscribed_radius_;              ///< 机器人内切圆半径
  std::vector<Point> footprint_;         ///< 机器人足迹多边形
};

}  // namespace costmapNS

#endif  // COSTMAP_2D_LAYERED_COSTMAP_H_
