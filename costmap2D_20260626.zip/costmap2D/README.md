# Costmap2D - 分层代价地图库

一个基于ROS Navigation Stack重构的分层代价地图库，核心功能已去除ROS依赖，可独立使用。

## 特性

- ✅ **核心无ROS依赖**：`Costmap2D`、`LayeredCostmap`及各图层完全独立
- ✅ **分层架构**：支持静态层、障碍物层、膨胀层等多种图层
- ✅ **自定义数据结构**：替代ROS消息类型（`LaserScanData`、`RobotPose`、`OccupancyGridData`）
- ✅ **坐标变换**：内置`TransformBuffer`支持多坐标系转换
- ✅ **条件编译**：Demo程序可选依赖ROS，便于开发和测试

## 项目结构

```
costmap2D/
├── include/costmap_2d/         # 头文件
│   ├── costmap_2d.h           # 核心栅格地图数据结构
│   ├── layered_costmap.h      # 分层代价地图主控类
│   ├── layer.h                # 图层抽象基类
│   ├── costmap_layer.h        # 图层实现基类
│   ├── static_layer.h         # 静态地图层（无ROS依赖）
│   ├── obstacle_layer.h       # 障碍物层（无ROS依赖）
│   ├── inflation_layer.h      # 膨胀层
│   ├── footprint.h            # 机器人底盘足迹
│   ├── cost_values.h          # 代价常量定义
│   ├── costmap_math.h         # 数学工具函数
│   ├── point_cloud.h          # 点云数据结构
│   └── coordinate_transform.h # 坐标变换缓冲区
├── src/                        # 核心源文件
│   ├── costmap_2d.cpp
│   ├── layered_costmap.cpp
│   ├── layer.cpp
│   ├── costmap_layer.cpp
│   ├── costmap_math.cpp
│   └── footprint.cpp
├── plugins/                    # 图层插件实现
│   ├── static_layer.cpp
│   ├── obstacle_layer.cpp
│   └── inflation_layer.cpp
├── examples/                   # 示例程序（依赖ROS）
│   ├── global_costmap_demo.cpp # 全局代价地图演示
│   └── local_costmap_demo.cpp  # 局部代价地图演示
├── CMakeLists.txt             # 构建配置
└── README.md                  # 本文件
```

## 核心组件

### 1. Costmap2D - 栅格地图核心

替代ROS的`costmap2D::Costmap2D`，提供：

- **基础功能**：地图初始化、重置、调整大小
- **坐标转换**：世界坐标 ↔ 栅格索引（支持旋转）
- **代价管理**：自由空间(0)、致命障碍(254)、未知区域(255)
- **多边形操作**：多边形填充、射线追踪清除

### 2. LayeredCostmap - 分层地图管理

管理多个图层，支持动态添加/移除图层：

- **图层管理**：添加、激活、失活图层
- **地图更新**：统一更新所有图层
- **边界管理**：动态调整地图边界

### 3. 图层插件

| 图层 | 功能 | 说明 |
|------|------|------|
| **StaticLayer** | 静态地图层 | 加载静态地图，使用`OccupancyGridData` |
| **ObstacleLayer** | 障碍物层 | 处理激光扫描数据，标记障碍物，射线清除 |
| **InflationLayer** | 膨胀层 | 围绕障碍物生成安全缓冲区，代价指数衰减 |

### 4. 自定义数据结构

| 结构 | 用途 | 替代的ROS消息 |
|------|------|--------------|
| `LaserScanData` | 激光扫描数据 | `sensor_msgs::LaserScan` |
| `RobotPose` | 机器人位姿 | `geometry_msgs::Pose` |
| `OccupancyGridData` | 栅格地图数据 | `nav_msgs::OccupancyGrid` |

## 编译安装

### 依赖

- CMake >= 3.10
- C++11编译器
- Eigen3
- (可选) ROS Noetic（用于编译Demo）

### Ubuntu安装依赖

```bash
sudo apt-get update
sudo apt-get install cmake libeigen3-dev
```

### 编译（无ROS）

```bash
mkdir build && cd build
cmake ..
make
```

### 编译（有ROS）

```bash
source /opt/ros/noetic/setup.bash
mkdir build && cd build
cmake ..
make
```

### 安装

```bash
sudo make install
```

## 使用示例

### 基本使用（无ROS）

```cpp
#include <costmap_2d/layered_costmap.h>
#include <costmap_2d/static_layer.h>
#include <costmap_2d/inflation_layer.h>

using namespace costmap2D;

int main() {
    LayeredCostmap layered_costmap("global", false, true);
    
    StaticLayer* static_layer = new StaticLayer();
    static_layer->initialize(&layered_costmap);
    layered_costmap.addLayer(static_layer);
    
    InflationLayer* inflation_layer = new InflationLayer();
    inflation_layer->initialize(&layered_costmap);
    layered_costmap.addLayer(inflation_layer);
    
    layered_costmap.resizeMap(100, 100, 0.05, 0.0, 0.0);
    
    return 0;
}
```

### 运行Demo程序

```bash
# 全局代价地图（订阅/map话题）
./build/global_costmap_demo [map_topic]

# 局部代价地图（订阅/scan和/amcl_pose话题）
./build/local_costmap_demo
```

## 代价值定义

| 值 | 含义 |
|----|------|
| `0` | 自由空间 |
| `1-252` | 膨胀代价（数值越大越危险） |
| `253` | 致命障碍前的代价 |
| `254` | 致命障碍 |
| `255` | 未知区域 |

## 图层说明

### StaticLayer

- 加载静态地图数据
- 使用`incomingMap()`方法输入`OccupancyGridData`
- 支持三值代价模式和占用阈值配置

### ObstacleLayer

- 使用`incomingLaserScan()`方法输入激光扫描数据
- 线程安全的观测队列
- 时间戳对齐机制
- 射线追踪清除自由空间

### InflationLayer

- 围绕障碍物生成膨胀区域
- 代价指数衰减：`cost = exp(-(distance - radius) / sigma) * cost_factor`
- 支持设置膨胀半径和代价衰减系数

## API参考

### Costmap2D

```cpp
// 构造函数
Costmap2D(unsigned int size_x, unsigned int size_y, double resolution,
          double origin_x, double origin_y, unsigned char default_value = 0);

// 坐标转换
bool worldToMap(double wx, double wy, unsigned int& mx, unsigned int& my) const;
void mapToWorld(unsigned int mx, unsigned int my, double& wx, double& wy) const;

// 代价访问
unsigned char getCost(unsigned int mx, unsigned int my) const;
void setCost(unsigned int mx, unsigned int my, unsigned char cost);

// 地图操作
void resizeMap(unsigned int size_x, unsigned int size_y, double resolution,
               double origin_x, double origin_y);
void raytraceLine(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1);
```

### LayeredCostmap

```cpp
LayeredCostmap(std::string global_frame, bool rolling_window, bool track_unknown);

void addLayer(Layer* layer);
void resizeMap(unsigned int size_x, unsigned int size_y, double resolution,
               double origin_x, double origin_y);
void updateMap(double robot_x, double robot_y, double robot_yaw);
```

### StaticLayer

```cpp
void incomingMap(const OccupancyGridData& new_map);
void initialize(LayeredCostmap* parent);
void updateBounds(double robot_x, double robot_y, double robot_yaw,
                  double* min_x, double* min_y, double* max_x, double* max_y);
void updateCosts(Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);
```

### ObstacleLayer

```cpp
void incomingLaserScan(const LaserScanData& scan, const RobotPose& robot_pose,
                       double sensor_mount_angle = 0.0);
void initialize(LayeredCostmap* parent);
void updateBounds(double robot_x, double robot_y, double robot_yaw,
                  double* min_x, double* min_y, double* max_x, double* max_y);
void updateCosts(Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);
```

### InflationLayer

```cpp
void initialize(LayeredCostmap* parent);
void updateBounds(double robot_x, double robot_y, double robot_yaw,
                  double* min_x, double* min_y, double* max_x, double* max_y);
void updateCosts(Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);
```

## 应用场景

- 机器人导航系统
- 局部路径规划
- 避障算法
- 自主移动机器人

## 许可证

本项目采用BSD许可证，兼容原ROS costmap_2d的许可证。

## 作者

基于ROS Navigation Stack的costmap_2d包重构，移除ROS依赖，提供独立的数据结构和接口。

## 贡献

欢迎提交Issue和Pull Request！
